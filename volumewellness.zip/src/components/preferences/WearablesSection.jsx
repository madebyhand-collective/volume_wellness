import React, { useEffect, useState } from 'react';
import { Check, Copy, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Label } from '@/components/ui/label';

const summarize = (b) => {
  if (!b) return [];
  return [
    b.readiness_score != null && `Readiness ${Math.round(b.readiness_score)}`,
    b.sleep_score != null && `Sleep ${Math.round(b.sleep_score)}`,
    b.sleep_duration_hours != null && `${b.sleep_duration_hours.toFixed(1)}h sleep`,
    b.hrv_ms != null && `HRV ${Math.round(b.hrv_ms)}ms`,
    b.resting_hr != null && `RHR ${Math.round(b.resting_hr)}`,
  ].filter(Boolean).slice(0, 3);
};

function ConnectionRow({ label, description, loading, conn, summary, busy, onConnect, onDisconnect }) {
  return (
    <div className="flex items-center justify-between gap-4 py-2">
      <div>
        <Label className="text-sm font-medium text-foreground">{label}</Label>
        {loading ? (
          <p className="text-xs text-muted-foreground">Checking…</p>
        ) : conn ? (
          <p className="text-xs text-muted-foreground">
            Connected{summary.length > 0 && ` — ${summary.join(' · ')}`}
          </p>
        ) : (
          <p className="text-xs text-muted-foreground">{description}</p>
        )}
      </div>
      {loading ? (
        <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
      ) : conn ? (
        <button
          type="button"
          disabled={busy}
          onClick={onDisconnect}
          className="rounded-full border border-border px-4 py-1.5 text-xs font-medium text-muted-foreground hover:text-foreground disabled:opacity-40"
        >
          {busy ? 'Disconnecting…' : 'Disconnect'}
        </button>
      ) : (
        <button
          type="button"
          disabled={busy}
          onClick={onConnect}
          className="rounded-full bg-primary px-4 py-1.5 text-xs font-medium text-primary-foreground disabled:opacity-40"
        >
          Connect
        </button>
      )}
    </div>
  );
}

// Cloud wearable connections under Units & wearables.
export default function WearablesSection() {
  const [loading, setLoading] = useState(true);
  const [ouraConn, setOuraConn] = useState(null);
  const [googleConn, setGoogleConn] = useState(null);
  const [watchConn, setWatchConn] = useState(null);
  const [latest, setLatest] = useState({});
  const [busy, setBusy] = useState(false);
  const [copied, setCopied] = useState(false);

  const load = async () => {
    const conns = await base44.entities.WearableConnection.list();
    setOuraConn(conns.find((c) => c.provider === 'oura') || null);
    setGoogleConn(conns.find((c) => c.provider === 'google_health') || null);
    setWatchConn(conns.find((c) => c.provider === 'apple_health') || null);
    const bio = await base44.entities.BiometricDaily.list('-date', 30);
    setLatest({
      oura: bio.find((b) => b.provider === 'oura') || null,
      google_health: bio.find((b) => b.provider === 'google_health') || null,
      apple_health: bio.find((b) => b.provider === 'apple_health') || null,
    });
    setLoading(false);
  };

  useEffect(() => {
    let cancelled = false;
    load()
      .catch(() => {})
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, []);

  const disconnect = async (conn, clear) => {
    if (!conn) return;
    setBusy(true);
    try {
      await base44.entities.WearableConnection.delete(conn.id);
      clear(null);
    } finally {
      setBusy(false);
    }
  };

  const connectOura = () => {
    window.location.href = `${window.location.origin}/functions/ouraAuth`;
  };

  const connectGoogle = () => {
    window.location.href = `${window.location.origin}/functions/googleHealthAuth`;
  };

  // Apple Watch: create a personal webhook key the Health Auto Export app posts to.
  const connectWatch = async () => {
    const token = (crypto.randomUUID().replace(/-/g, '') + crypto.randomUUID().replace(/-/g, ''));
    setBusy(true);
    try {
      await base44.entities.WearableConnection.create({ provider: 'apple_health', access_token: token });
      await load();
    } finally {
      setBusy(false);
    }
  };

  const watchUrl = watchConn
    ? `${window.location.origin}/functions/healthBridge?key=${watchConn.access_token}`
    : '';

  const copyUrl = async () => {
    try {
      await navigator.clipboard.writeText(watchUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (e) { /* clipboard unavailable */ }
  };

  return (
    <div className="mt-2 space-y-1 border-t border-border pt-3">
      <ConnectionRow
        label="Oura Ring"
        description="Sync sleep and readiness from your ring"
        loading={loading}
        conn={ouraConn}
        summary={summarize(latest.oura)}
        busy={busy}
        onConnect={connectOura}
        onDisconnect={() => disconnect(ouraConn, setOuraConn)}
      />

      <ConnectionRow
        label="Google Health"
        description="Sync sleep, HRV, and resting heart rate from Fitbit or Pixel Watch"
        loading={loading}
        conn={googleConn}
        summary={summarize(latest.google_health)}
        busy={busy}
        onConnect={connectGoogle}
        onDisconnect={() => disconnect(googleConn, setGoogleConn)}
      />

      <div className="py-2">
        <ConnectionRow
          label="Apple Watch"
          description="Sync sleep, HRV, and resting heart rate via Apple Health"
          loading={loading}
          conn={watchConn}
          summary={summarize(latest.apple_health)}
          busy={busy}
          onConnect={connectWatch}
          onDisconnect={() => disconnect(watchConn, setWatchConn)}
        />
        {watchConn && (
          <div className="mt-2 space-y-2 rounded-2xl bg-accent p-3">
            <div className="flex items-center gap-2">
              <code className="min-w-0 flex-1 truncate rounded-full bg-card px-3 py-1.5 text-xs text-foreground">
                {watchUrl}
              </code>
              <button
                type="button"
                onClick={copyUrl}
                aria-label="Copy webhook URL"
                className="shrink-0 rounded-full border border-border bg-card p-2 text-foreground"
              >
                {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
              </button>
            </div>
            <p className="text-xs text-muted-foreground">
              In the Health Auto Export app, create an Automation (JSON) that POSTs daily to this URL with sleep,
              heart rate variability, and resting heart rate.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}