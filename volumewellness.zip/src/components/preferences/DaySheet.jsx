import React, { useState } from 'react';
import { Check, ChevronDown } from 'lucide-react';
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from '@/components/ui/drawer';

const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

// Bottom-sheet replacement for the native <select> — iOS WebView friendly.
export default function DaySheet({ value, onChange }) {
  const [open, setOpen] = useState(false);

  return (
    <Drawer open={open} onOpenChange={setOpen}>
      <DrawerTrigger asChild>
        <button
          type="button"
          className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1.5 text-sm text-foreground"
        >
          {DAYS[value] || DAYS[0]}
          <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
        </button>
      </DrawerTrigger>
      <DrawerContent>
        <DrawerHeader className="pb-0">
          <DrawerTitle className="text-left">Reflection day</DrawerTitle>
        </DrawerHeader>
        <div className="safe-bottom max-h-72 overflow-y-auto p-4">
          {DAYS.map((day, i) => (
            <button
              key={day}
              type="button"
              onClick={() => {
                onChange(i);
                setOpen(false);
              }}
              className={`flex w-full items-center justify-between rounded-2xl px-4 py-3 text-sm font-medium ${
                i === value ? 'bg-primary text-primary-foreground' : 'text-foreground hover:bg-secondary'
              }`}
            >
              {day}
              {i === value && <Check className="h-4 w-4" />}
            </button>
          ))}
        </div>
      </DrawerContent>
    </Drawer>
  );
}