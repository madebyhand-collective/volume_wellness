import { useEffect, useRef } from 'react';
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { Home, Dumbbell, Library, Lightbulb, NotebookPen, Settings, PersonStanding, ClipboardCheck, ChevronLeft } from 'lucide-react';
import Illustration from '@/components/Illustration';
import MobileTabBar from '@/components/layout/MobileTabBar';

const navItems = [
  { to: '/', label: 'Today', icon: Home },
  { to: '/workout', label: 'Workout', icon: Dumbbell },
  { to: '/plans', label: 'Plans', icon: Library },
  { to: '/insights', label: 'Insights', icon: Lightbulb },
  { to: '/accountability', label: 'Promises', icon: ClipboardCheck },
  { to: '/reflection', label: 'Reflect', icon: NotebookPen },
  { to: '/library', label: 'Movement', icon: PersonStanding },
];

const linkClass = ({ isActive }) =>
  `flex items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold transition-colors ${
    isActive ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-muted'
  }`;

// Child screens get a back chevron + title instead of the brand logo
const CHILD_SCREENS = [
  { isChild: (p) => p === '/preferences', title: 'Settings' },
  { isChild: (p) => p.startsWith('/library/block/'), title: 'Movement' },
  { isChild: (p) => p === '/privacy', title: 'Privacy Policy' },
  { isChild: (p) => p === '/terms', title: 'Terms of Service' },
];
const childOf = (pathname) => CHILD_SCREENS.find((s) => s.isChild(pathname));
const screenDepth = (pathname) => (childOf(pathname) ? 1 : 0);

export default function Layout() {
  const location = useLocation();
  const navigate = useNavigate();
  const child = childOf(location.pathname);

  // Push/pop direction: deeper screens slide in from the right, back from the left
  const depth = screenDepth(location.pathname);
  const prevDepth = useRef(depth);
  const dir = depth > prevDepth.current ? 1 : -1;
  useEffect(() => {
    prevDepth.current = depth;
  }, [depth]);

  return (
    <div
      className="relative min-h-screen bg-background"
      style={{ paddingBottom: 'calc(6rem + env(safe-area-inset-bottom, 16px))' }}
    >
      <header className="safe-top sticky top-0 z-40 bg-background/70 backdrop-blur-md">
        <div className="mx-auto flex max-w-4xl items-center px-4 py-3">
          {child ? (
            <button
              type="button"
              onClick={() => navigate(-1)}
              aria-label="Back"
              className="flex h-9 w-9 items-center justify-center rounded-full text-muted-foreground hover:bg-muted hover:text-foreground"
            >
              <ChevronLeft className="h-6 w-6" />
            </button>
          ) : (
            <NavLink to="/" aria-label="Home" className="flex items-center leading-none">
              <Illustration motif="starburst" color="sunset" className="h-6 w-6" />
            </NavLink>
          )}
          <div className="flex flex-1 justify-center">
            {child ? (
              <span className="font-heading text-lg leading-none text-foreground">{child.title}</span>
            ) : (
              <NavLink to="/" className="flex items-center leading-none">
                <Illustration motif="volumewordmark" color="sunset" className="h-7 md:h-8 w-auto" />
              </NavLink>
            )}
          </div>
          <nav className="hidden items-center gap-1 md:flex" aria-label="Main navigation">
            {navItems.map(({ to, label, icon: Icon }) => (
              <NavLink key={to} to={to} className={linkClass} end={to === '/'}>
                <Icon className="h-4 w-4" />
                {label}
              </NavLink>
            ))}
            <NavLink
              to="/preferences"
              className="ml-2 rounded-full p-2 text-muted-foreground hover:bg-muted"
              aria-label="Settings"
            >
              <Settings className="h-5 w-5" />
            </NavLink>
          </nav>
          <NavLink
            to="/preferences"
            className="rounded-full p-2 text-muted-foreground hover:bg-muted md:hidden"
            aria-label="Settings"
          >
            <Settings className="h-5 w-5" />
          </NavLink>
        </div>
      </header>
      <main className="relative z-10 mx-auto max-w-4xl px-4 py-6">
        <AnimatePresence mode="wait" initial={false}>
          <motion.div
            key={location.pathname}
            initial={{ x: dir * 48, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: dir * -48, opacity: 0 }}
            transition={{ duration: 0.18, ease: 'easeOut' }}
          >
            <Outlet />
          </motion.div>
        </AnimatePresence>
      </main>
      <MobileTabBar />
    </div>
  );
}