import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, Clock } from 'lucide-react';
import Illustration from '@/components/Illustration';
import { base44 } from '@/api/base44Client';
import { useToast } from '@/components/ui/use-toast';
import ScoreDial from '@/components/ScoreDial';
import { TIERS, localTodayStr } from '@/lib/volume';
import { logEvent } from '@/lib/behavioral';

const COMPONENTS = [
  { key: 'vs_body_signal', label: 'Body signal' },
  { key: 'vs_life_load', label: 'Life load' },
  { key: 'vs_mental_readiness', label: 'Mental readiness' },
  { key: 'vs_behavioral_momentum', label: 'Momentum' },
];

export default function ScoreReveal({ assessment }) {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [warmup, setWarmup] = useState(null);
  const [cooldown, setCooldown] = useState(null);
  const [planDay, setPlanDay] = useState(null);
  const [profile, setProfile] = useState(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [blocks, profiles] = await Promise.all([
          base44.entities.SessionBlock.list(),
          base44.entities.Profile.list(),
        ]);
        if (cancelled) return;
        const p = profiles[0] || null;
        setProfile(p);
        setWarmup(blocks.find((b) => b.block_id === assessment.rec_warmup_block_id) || null);
        setCooldown(blocks.find((b) => b.block_id === assessment.rec_cooldown_block_id) || null);
        if (p && p.active_plan_id) {
          const days = await base44.entities.PlanDay.filter({ plan_id: p.active_plan_id });
          if (cancelled) return;
          const weekDays = days
            .filter((d) => d.week_number === p.current_week)
            .sort((x, y) => (x.day_index ?? 0) - (y.day_index ?? 0));
          setPlanDay(weekDays[Math.min(p.day_index ?? 0, Math.max(weekDays.length - 1, 0))] || null);
        }
      } catch (e) {
        // recommendation extras are best-effort
      }
    })();
    return () => { cancelled = true; };
  }, [assessment.id]);

  const tier = TIERS[assessment.volume_score_tier] || TIERS.baseline;

  const startWorkout = async () => {
    await logEvent('workout_started', {
      assessment_id: assessment.id,
      volume_score_at_time: assessment.volume_score_total,
      cycle_phase: assessment.cycle_phase,
      life_load: assessment.self_life_load,
    });
    navigate('/workout');
  };

  const defer = async () => {
    await logEvent('later_tap', {
      assessment_id: assessment.id,
      volume_score_at_time: assessment.volume_score_total,
      life_load: assessment.self_life_load,
    });
    try {
      if (profile && planDay) {
        await base44.entities.WorkoutSession.create({
          plan_id: profile.active_plan_id,
          week_number: profile.current_week,
          day_id: planDay.day_id,
          date: localTodayStr(),
          status: 'deferred',
          volume_score_at_time: assessment.volume_score_total,
          tier_at_time: assessment.volume_score_tier,
          deferred_to: new Date(Date.now() + 6 * 3600e3).toISOString(),
          deferral_outcome: 'never_completed',
        });
      }
      toast({ title: 'Noted. We’ll keep an eye on it.' });
    } catch (e) {
      toast({ title: 'Could not save that — try again.', variant: 'destructive' });
    }
  };

  return (
    <div className="space-y-5">
      <div className="sticker rounded-3xl bg-card p-6">
        <div className="flex flex-col items-center gap-6 text-center sm:flex-row sm:items-start sm:text-left">
          <div className="flex h-44 w-44 shrink-0 items-center justify-center rounded-full bg-bloom">
            <ScoreDial score={assessment.volume_score_total} tier={assessment.volume_score_tier} />
          </div>
          <div className="min-w-0 flex-1">
            <div className={`inline-flex items-center gap-1.5 rounded-full border-2 border-sage px-3 py-1 text-sm font-medium ${tier.chip}`}>
              {tier.label}
            </div>
            <p className="mt-3 font-heading text-xl text-foreground">{assessment.rec_primary_message}</p>
            {assessment.rec_secondary_message && (
              <p className="mt-1.5 text-sm text-muted-foreground">{assessment.rec_secondary_message}</p>
            )}
            <div className="mt-4 space-y-2.5">
              {COMPONENTS.map(({ key, label }) => (
                <div key={key}>
                  <div className="flex items-baseline justify-between text-xs">
                    <span className="text-muted-foreground">{label}</span>
                    <span className="font-medium text-foreground">{assessment[key] ?? '—'}</span>
                  </div>
                  <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-foreground/10">
                    <div className="h-full rounded-full bg-primary" style={{ width: `${assessment[key] ?? 0}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="sticker rounded-3xl bg-card p-5">
        <h3 className="mb-3 flex items-center gap-2 font-heading text-lg text-foreground">
          <Illustration motif="sparkleicon" color="sunset" className="h-5 w-5" /> Today&apos;s recommendation
        </h3>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <div className="flex flex-col items-center rounded-3xl bg-sun p-4 text-center">
            <div className="flex h-7 w-7 items-center justify-center rounded-full bg-primary text-sm font-medium text-primary-foreground">1</div>
            <div className="mt-2 font-medium text-foreground">Warmup</div>
            <div className="text-sm text-foreground">{warmup ? warmup.name : 'General warmup'}</div>
            {warmup && (
              <div className="mt-1 flex items-center gap-1 text-xs text-foreground/70">
                <Clock className="h-3 w-3" /> {warmup.duration_minutes} min · {warmup.intensity_level} intensity
              </div>
            )}
          </div>
          <div className="flex flex-col items-center rounded-3xl bg-bloom p-4 text-center">
            <div className="flex h-7 w-7 items-center justify-center rounded-full bg-primary text-sm font-medium text-primary-foreground">2</div>
            <div className="mt-2 font-medium text-foreground">Core</div>
            <div className="text-sm text-foreground">{planDay ? planDay.label : 'Your active plan'}</div>
            <div className="mt-1 text-xs text-foreground/70">
              {assessment.rec_set_modifier === 1 && 'One extra set per exercise today'}
              {assessment.rec_set_modifier === -1 && 'One less set per exercise today'}
              {assessment.rec_set_modifier === 0 && 'Sets as planned'}
              {` · capped at ${assessment.rec_session_length_cap} min`}
            </div>
          </div>
          <div className="flex flex-col items-center rounded-3xl bg-sage p-4 text-center">
            <div className="flex h-7 w-7 items-center justify-center rounded-full bg-primary text-sm font-medium text-primary-foreground">3</div>
            <div className="mt-2 font-medium text-foreground">Cooldown</div>
            <div className="text-sm text-foreground">{cooldown ? cooldown.name : 'Static stretch'}</div>
            {cooldown && (
              <div className="mt-1 flex items-center gap-1 text-xs text-foreground/70">
                <Clock className="h-3 w-3" /> {cooldown.duration_minutes} min
              </div>
            )}
          </div>
        </div>
        <div className="mt-5 flex flex-col gap-2 sm:flex-row">
          <button
            type="button"
            onClick={startWorkout}
            className="sticker inline-flex flex-1 items-center justify-center gap-2 rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground"
          >
            Start today&apos;s workout <ArrowRight className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={defer}
            className="rounded-full border border-border px-6 py-3 font-medium text-muted-foreground hover:bg-secondary"
          >
            Do it later
          </button>
        </div>
        <p className="mt-3 text-center text-xs text-muted-foreground">
          Need a different plan? <Link to="/plans" className="underline">Browse the plan library</Link>
        </p>
      </div>
    </div>
  );
}