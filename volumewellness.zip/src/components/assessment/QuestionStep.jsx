export default function QuestionStep({ number, total, title, subtitle, children }) {
  return (
    <div className="animate-in fade-in">
      <div className="mb-2 text-sm font-medium text-muted-foreground">
        Question {number} of {total}
      </div>
      <h2 className="font-heading text-2xl text-foreground md:text-3xl">{title}</h2>
      {subtitle && <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>}
      <div className="mt-6">{children}</div>
    </div>
  );
}