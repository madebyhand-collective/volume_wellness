import { Battery, BatteryLow, BatteryMedium, BatteryFull } from 'lucide-react';

const icons = [BatteryLow, BatteryLow, Battery, BatteryMedium, BatteryFull];

export default function EnergyPicker({ value, onChange }) {
  return (
    <div className="grid grid-cols-5 gap-2">
      {[1, 2, 3, 4, 5].map((n) => {
        const Icon = icons[n - 1];
        const active = value === n;
        return (
          <button
            key={n}
            type="button"
            onClick={() => onChange(n)}
            className={`flex flex-col items-center gap-1 rounded-2xl border py-4 transition-all ${
            active ? 'border-primary bg-primary text-primary-foreground' : 'border-border bg-card text-foreground hover:bg-secondary'}`
            }>
            
            <Icon className="h-6 w-6 hidden" />
            <span className="text-sm font-medium">{n}</span>
          </button>);

      })}
    </div>);

}