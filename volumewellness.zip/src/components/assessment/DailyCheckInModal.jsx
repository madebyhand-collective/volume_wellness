import React, { useEffect, useState } from 'react';
import { ArrowLeft, BellRing, Clock } from 'lucide-react';
import Illustration from '@/components/Illustration';
import AssessmentFlow from './AssessmentFlow';
import { logEvent } from '@/lib/behavioral';
import { setStoredReminder, markCheckInDismissed } from '@/lib/checkin-reminder';
import { localTodayStr } from '@/lib/volume';
import { createCommitment } from '@/lib/commitments';

function hhmm(d) {
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

function defaultReminderTime() {
  return hhmm(new Date(Date.now() + 60 * 60 * 1000));
}

// Full-screen daily check-in popup. Shows on first app open of the day until
// the user completes the check-in, or defers to a reminder time they choose.
export default function DailyCheckInModal({ open, prefs, onComplete, onDismiss, onReminderSet }) {
  const [phase, setPhase] = useState('prompt'); // 'prompt' | 'questions' | 'reminder'
  const [time, setTime] = useState(defaultReminderTime());

  useEffect(() => {
    if (open) {
      setPhase('prompt');
      setTime(defaultReminderTime());
    }
  }, [open]);

  if (!open) return null;

  const startCheckIn = async () => {
    await logEvent('assessment_opened');
    setPhase('questions');
  };

  const confirmReminder = async () => {
    const reminder = setStoredReminder(time);
    markCheckInDismissed();
    await logEvent('later_tap');
    await createCommitment({
      kind: 'checkin',
      label: 'Daily check-in',
      due_date: localTodayStr(),
      due_time: time,
      source: 'reminder'
    });
    if (onReminderSet) onReminderSet(reminder);
    if (onDismiss) onDismiss();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto checkin-gradient" role="dialog" aria-modal="true" aria-label="Daily check-in">
      {phase === 'questions' ?
      <div className="mx-auto min-h-full w-full max-w-md px-4 py-10">
          <AssessmentFlow
          prefs={prefs}
          onComplete={(a) => {
            if (onComplete) onComplete(a);
          }} />
        
        </div> :
      phase === 'reminder' ?
      <div className="mx-auto flex min-h-full w-full max-w-md flex-col items-center px-6 py-12">
          <div className="flex flex-1 flex-col items-center justify-center text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-full border-2 border-sage bg-background">
              <BellRing className="h-8 w-8 text-foreground" />
            </div>
            <h1 className="mt-6 font-heading text-3xl leading-tight text-foreground">
              When should we nudge you?
            </h1>
            <p className="mx-auto mt-3 max-w-xs text-sm font-medium text-foreground/70">
              We&apos;ll bring the check-in back at the time you pick.
            </p>
            <input
            type="time"
            value={time}
            onChange={(e) => setTime(e.target.value)}
            aria-label="Reminder time"
            className="mt-8 rounded-full border-2 border-sage bg-background px-6 py-3 text-lg font-bold text-foreground" />
          
            <div className="mt-4 flex flex-wrap justify-center gap-2">
              {[['In 30 min', 30], ['In 1 hour', 60], ['In 2 hours', 120]].map(([label, minutes]) =>
            <button
              key={label}
              type="button"
              onClick={() => setTime(hhmm(new Date(Date.now() + minutes * 60 * 1000)))}
              className="inline-flex items-center gap-1.5 rounded-full border border-sage/30 px-3 py-1.5 text-xs font-semibold text-foreground hover:bg-background">
              
                  <Clock className="h-3.5 w-3.5" />
                  {label}
                </button>
            )}
            </div>
          </div>
          <button
          type="button"
          onClick={confirmReminder}
          className="w-full rounded-full border-2 border-sage bg-foreground px-6 py-4 text-base font-bold text-primary-foreground">
          
            Set reminder
          </button>
          <button
          type="button"
          onClick={() => setPhase('prompt')}
          className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-foreground/70 hover:text-foreground">
          
            <ArrowLeft className="h-4 w-4" /> Back
          </button>
        </div> :

      <div className="mx-auto flex min-h-full w-full max-w-md flex-col items-center px-6 py-12">
          <div className="flex flex-1 flex-col items-center justify-center text-center">
            <Illustration motif="starburst" color="sunset" className="h-16 w-16" />
            <h1 className="mt-6 font-heading text-4xl leading-tight md:text-5xl text-[hsl(var(--foreground))]">
              It&apos;s a new day.
              <br />
              Let&apos;s plan today&apos;s volume.
            </h1>
            <p className="mx-auto mt-4 max-w-xs text-sm font-medium text-foreground/70">
              A quick check-in tunes today&apos;s plan to how you actually feel.
            </p>
          </div>
          <button
          type="button"
          onClick={startCheckIn}
          className="w-full rounded-full border-2 border-sage px-6 py-4 text-base font-bold bg-[hsl(var(--sidebar-accent))] text-[hsl(var(--primary))]">
          
            Do the check-in
          </button>
          <button
          type="button"
          onClick={() => setPhase('reminder')}
          className="text-sm font-semibold text-foreground/70 hover:text-foreground mb-8 mt-4">
          
            Not now, remind me later
          </button>
        </div>
      }
    </div>);

}