import React, { useMemo, useState } from 'react';
import { ChevronLeft, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import QuestionStep from './QuestionStep';
import ChoiceGroup from './ChoiceGroup';
import EnergyPicker from './EnergyPicker';
import ScoreReveal from './ScoreReveal';
import { CYCLE_PHASES, localTodayStr } from '@/lib/volume';
import { logEvent } from '@/lib/behavioral';

const SORENESS = [
{ value: 'none', label: 'None', emoji: '😌' },
{ value: 'mild', label: 'Mild', emoji: '🙃' },
{ value: 'heavy', label: 'Heavy', emoji: '😩' }];

const TIME = [
{ value: 'under20', label: 'Under 20 min' },
{ value: '20to30', label: '20–30 min' },
{ value: '30plus', label: '30+ min' }];

const LIFE_LOAD = [
{ value: 'light', label: 'Light', emoji: '🌤️' },
{ value: 'moderate', label: 'Moderate', emoji: '⛅️' },
{ value: 'heavy', label: 'A lot', emoji: '🌧️' }];

const SLEEP = [
{ value: 'poor', label: 'Poor', emoji: '😞' },
{ value: 'ok', label: 'OK', emoji: '😐' },
{ value: 'great', label: 'Great', emoji: '😄' }];

const MOTIVATION = [
{ value: 'dreading', label: 'Dreading', emoji: '😖' },
{ value: 'neutral', label: 'Neutral', emoji: '😐' },
{ value: 'ready', label: 'Ready', emoji: '🔥' }];

const STRESS = [
{ value: 'low', label: 'Low', emoji: '🍃' },
{ value: 'moderate', label: 'Moderate', emoji: '🌊' },
{ value: 'high', label: 'High', emoji: '🔥' }];

const MOOD = [
{ value: 'rough', label: 'Rough' },
{ value: 'low', label: 'Low' },
{ value: 'okay', label: 'Okay' },
{ value: 'good', label: 'Good' },
{ value: 'great', label: 'Great' }];


export default function AssessmentFlow({ prefs, onComplete }) {
  const steps = useMemo(() => {
    const list = [
    { key: 'soreness', title: 'How sore are you?', type: 'choice', options: SORENESS },
    { key: 'time_available', title: 'How much time do you have today?', type: 'choice', options: TIME },
    { key: 'life_load', title: 'How much is life asking of you?', subtitle: 'Be honest — this is the whole point.', type: 'choice', options: LIFE_LOAD },
    { key: 'energy', title: 'How is your energy?', subtitle: '1 = running on fumes, 5 = fully charged', type: 'energy' },
    { key: 'sleep_quality', title: 'How did you sleep?', type: 'choice', options: SLEEP },
    { key: 'motivation', title: 'How do you feel about moving today?', type: 'choice', options: MOTIVATION },
    { key: 'stress', title: 'How stressed are you?', type: 'choice', options: STRESS },
    { key: 'mood', title: 'How is your mood today?', subtitle: 'Not about working out — just how you feel.', type: 'choice', options: MOOD }];

    if (prefs && prefs.cycle_tracking_enabled) {
      list.push({ key: 'cycle_phase', title: 'Where are you in your cycle?', type: 'choice', options: CYCLE_PHASES, columns: 2 });
    }
    return list;
  }, [prefs]);

  const [idx, setIdx] = useState(0);
  const [answers, setAnswers] = useState({});
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const step = steps[idx];
  const value = step ? answers[step.key] : undefined;

  const setVal = (v) => setAnswers((a) => ({ ...a, [step.key]: v }));

  const submit = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await base44.functions.invoke('calculateVolumeScore', { ...answers, date: localTodayStr() });
      const assessment = res.data && res.data.assessment ? res.data.assessment : null;
      if (!assessment) throw new Error('No assessment returned');
      await logEvent('assessment_completed', {
        assessment_id: assessment.id,
        volume_score_at_time: assessment.volume_score_total,
        cycle_phase: assessment.cycle_phase,
        life_load: assessment.self_life_load
      });
      setResult(assessment);
      if (onComplete) onComplete(assessment);
    } catch (e) {
      const msg = e && e.response && e.response.data && e.response.data.error || e && e.message || 'Something went wrong';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  const next = () => {
    if (idx < steps.length - 1) {
      setIdx(idx + 1);
    } else {
      submit();
    }
  };

  if (result) return <ScoreReveal assessment={result} />;

  return (
    <div>
      <div className="mb-4 h-1.5 overflow-hidden rounded-full bg-secondary">
        <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${(idx + (loading ? 1 : 0)) / steps.length * 100}%` }} />
      </div>
      <div className="rounded-3xl border border-border bg-card p-5 md:p-7 my-10">
        {idx > 0 &&
        <button type="button" onClick={() => setIdx(idx - 1)} className="mb-4 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
            <ChevronLeft className="h-4 w-4" /> Back
          </button>
        }
        <QuestionStep number={idx + 1} total={steps.length} title={step.title} subtitle={step.subtitle}>
          {step.type === 'energy' ?
          <EnergyPicker value={value} onChange={setVal} /> :

          <ChoiceGroup options={step.options} value={value} onChange={setVal} columns={step.columns || 3} />
          }
        </QuestionStep>
        {error && <p className="mt-4 rounded-xl bg-accent px-3 py-2 text-sm text-accent-foreground">{error}</p>}
        <button
          type="button"
          disabled={value === undefined || loading}
          onClick={next}
          className="mt-8 inline-flex w-full items-center justify-center gap-2 rounded-full bg-primary px-6 py-3 font-medium text-primary-foreground transition-opacity disabled:opacity-40">
          
          {loading && <Loader2 className="h-4 w-4 animate-spin" />}
          {loading ? 'Reading your signals…' : idx === steps.length - 1 ? 'Get my Volume Score' : 'Next'}
        </button>
      </div>
    </div>);

}