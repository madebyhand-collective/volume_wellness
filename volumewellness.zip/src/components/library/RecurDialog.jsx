import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export default function RecurDialog({ block, entry, onSave, onClose }) {
  const [type, setType] = useState((entry && entry.type) || 'warmup');
  const [days, setDays] = useState((entry && entry.days) || []);

  if (!block) return null;

  const toggleDay = (i) => setDays((ds) => (ds.includes(i) ? ds.filter((x) => x !== i) : [...ds, i]));

  return (
    <Dialog open onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="font-heading">Repeat “{block.name}”</DialogTitle>
        </DialogHeader>
        <p className="text-sm text-muted-foreground">Use it as a recurring…</p>
        <div className="mt-2 flex gap-2">
          {['warmup', 'cooldown'].map((v) => (
            <button
              key={v}
              type="button"
              onClick={() => setType(v)}
              className={`rounded-full px-4 py-2 text-sm font-medium capitalize ${
                type === v ? 'bg-primary text-primary-foreground' : 'border border-border text-foreground'
              }`}
            >
              {v}
            </button>
          ))}
        </div>
        <p className="mt-4 text-sm text-muted-foreground">On these days</p>
        <div className="mt-2 flex flex-wrap gap-2">
          {DAYS.map((label, i) => (
            <button
              key={label}
              type="button"
              onClick={() => toggleDay(i)}
              aria-pressed={days.includes(i)}
              className={`h-10 w-12 rounded-full text-xs font-semibold ${
                days.includes(i) ? 'bg-primary text-primary-foreground' : 'border border-border text-foreground'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
        <p className="mt-3 text-xs text-muted-foreground">
          On days it&apos;s not set, Volume picks your warmup and cooldown from your preferences.
        </p>
        <button
          type="button"
          onClick={() => onSave({ block_id: block.block_id, type, days })}
          className="mt-4 inline-flex w-full items-center justify-center rounded-full bg-primary px-6 py-3 font-medium text-primary-foreground"
        >
          Save
        </button>
        <button type="button" onClick={onClose} className="mt-2 w-full text-center text-sm text-muted-foreground underline">
          {days.length ? 'Cancel' : 'Cancel — or save with no days to stop it repeating'}
        </button>
      </DialogContent>
    </Dialog>
  );
}