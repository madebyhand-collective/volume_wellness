import React, { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Check, ChevronLeft, Loader2, Pause, Play, SkipBack, SkipForward } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useToast } from '@/components/ui/use-toast';
import { Switch } from '@/components/ui/switch';
import { localTodayStr } from '@/lib/volume';

const parseSeconds = (duration) => {
  const m = /(\d+)\s*min/i.exec(duration || '');
  const mins = m ? Number(m[1]) : 1;
  const perSide = /per side/i.test(duration || '');
  return Math.max(30, mins * 60 * (perSide ? 2 : 1));
};

const fmt = (s) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;

export default function BlockPlayer({ block }) {
  const { toast } = useToast();
  const navigate = useNavigate();
  const exercises = useMemo(
    () => [...(block.exercises || [])].sort((a, b) => (a.order ?? 0) - (b.order ?? 0)),
    [block]
  );

  const [idx, setIdx] = useState(0);
  const [secondsLeft, setSecondsLeft] = useState(() => (exercises[0] ? parseSeconds(exercises[0].duration) : 0));
  const [running, setRunning] = useState(false);
  const [done, setDone] = useState([]);
  const [autoContinue, setAutoContinue] = useState(() => localStorage.getItem('volume-auto-continue') !== 'off');
  const [saving, setSaving] = useState(false);

  const current = exercises[idx];
  const isLast = idx >= exercises.length - 1;
  const total = current ? parseSeconds(current.duration) : 0;
  const pct = total ? ((total - secondsLeft) / total) * 100 : 0;

  const goTo = (nextIdx, keepRunning) => {
    setIdx(nextIdx);
    setSecondsLeft(parseSeconds(exercises[nextIdx].duration));
    setRunning(keepRunning);
  };

  useEffect(() => {
    if (!running) return;
    const t = setInterval(() => setSecondsLeft((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(t);
  }, [running, idx]);

  // Timer hit zero — auto-advance, or pause and wait for a manual choice
  useEffect(() => {
    if (secondsLeft > 0 || !running) return;
    setDone((d) => (d.includes(idx) ? d : [...d, idx]));
    setRunning(false);
    if (autoContinue && !isLast) goTo(idx + 1, true);
  }, [secondsLeft, running]);

  const toggleAuto = (v) => {
    setAutoContinue(v);
    localStorage.setItem('volume-auto-continue', v ? 'on' : 'off');
  };

  const finish = async () => {
    setSaving(true);
    try {
      await base44.entities.WorkoutSession.create({
        date: localTodayStr(),
        status: 'completed',
        duration_minutes: block.duration_minutes,
        session_note: `Standalone: ${block.name}`,
      });
      toast({ title: 'Logged. Nice work.' });
      navigate('/library');
    } catch (e) {
      toast({ title: 'Could not log that — try again.', variant: 'destructive' });
      setSaving(false);
    }
  };

  return (
    <div className="mx-auto max-w-xl space-y-5">
      <div className="flex items-center justify-between">
        <Link to="/library" className="inline-flex items-center gap-1 text-sm font-semibold text-muted-foreground hover:text-foreground">
          <ChevronLeft className="h-4 w-4" /> Library
        </Link>
        <label className="flex items-center gap-2 text-xs font-semibold text-foreground">
          Auto-continue
          <Switch checked={autoContinue} onCheckedChange={toggleAuto} />
        </label>
      </div>

      <div>
        <h1 className="font-heading text-3xl text-foreground">{block.name}</h1>
        <p className="text-xs text-muted-foreground">
          Move {Math.min(idx + 1, exercises.length)} of {exercises.length}
        </p>
      </div>

      <div className="sticker rounded-3xl border-2 border-sage bg-card p-6 text-center">
        <h2 className="font-heading text-2xl text-foreground">{current ? current.name : 'All done'}</h2>
        <p className="text-xs text-muted-foreground">{current ? current.duration : ''}</p>
        <p className="mt-4 font-heading text-6xl text-foreground tabular-nums">{fmt(secondsLeft)}</p>
        <div className="mt-4 h-2 overflow-hidden rounded-full bg-secondary">
          <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${pct}%` }} />
        </div>

        <div className="mt-6 flex items-center justify-center gap-3">
          <button
            type="button"
            disabled={idx === 0}
            onClick={() => goTo(Math.max(0, idx - 1), false)}
            className="rounded-full border-2 border-sage p-3 text-foreground disabled:opacity-30"
            aria-label="Previous move"
          >
            <SkipBack className="h-5 w-5" />
          </button>
          <button
            type="button"
            onClick={() => setRunning((r) => !r)}
            disabled={!current}
            className="rounded-full border-2 border-sage bg-foreground p-4 text-primary-foreground disabled:opacity-40"
            aria-label={running ? 'Pause' : 'Start'}
          >
            {running ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6" />}
          </button>
          <button
            type="button"
            disabled={isLast}
            onClick={() => goTo(idx + 1, false)}
            className="rounded-full border-2 border-sage p-3 text-foreground disabled:opacity-30"
            aria-label="Next move"
          >
            <SkipForward className="h-5 w-5" />
          </button>
        </div>
        {!autoContinue && secondsLeft === 0 && !isLast && (
          <p className="mt-3 text-xs text-muted-foreground">Tap the next button when you&apos;re ready.</p>
        )}
      </div>

      <ul className="space-y-1.5">
        {exercises.map((ex, i) => (
          <li key={i}>
            <button
              type="button"
              onClick={() => goTo(i, false)}
              className={`flex w-full items-center justify-between gap-2 rounded-xl border px-3 py-2 text-left text-sm ${
                i === idx
                  ? 'border-primary bg-primary/10 text-foreground'
                  : done.includes(i)
                    ? 'border-border bg-secondary/50 text-muted-foreground'
                    : 'border-border text-foreground'
              }`}
            >
              <span className="flex items-center gap-2">
                {done.includes(i) && <Check className="h-4 w-4 text-primary" />}
                {ex.name}
              </span>
              <span className="shrink-0 text-xs text-muted-foreground">{ex.duration}</span>
            </button>
          </li>
        ))}
      </ul>

      <button
        type="button"
        disabled={saving}
        onClick={finish}
        className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground disabled:opacity-40"
      >
        {saving && <Loader2 className="h-4 w-4 animate-spin" />}
        Finish & log it
      </button>
    </div>
  );
}