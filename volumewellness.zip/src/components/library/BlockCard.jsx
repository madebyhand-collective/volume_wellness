import React, { useState } from 'react';
import { CalendarCheck, ChevronDown, ChevronUp, Play } from 'lucide-react';

const DAY_ABBR = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export default function BlockCard({ block, recurring, onRecur, onDoNow }) {
  const [open, setOpen] = useState(false);
  const isPT = (block.tags || []).includes('physical therapy');
  const category = isPT ? 'Physical therapy' : 'Mobility flow';

  return (
    <div className="rounded-3xl border border-border bg-card p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="rounded-full bg-bloom px-2.5 py-0.5 text-[11px] font-bold uppercase tracking-wide text-foreground">{category}</span>
            <span className="rounded-full bg-sun px-2.5 py-0.5 text-[11px] font-bold uppercase tracking-wide text-foreground">{block.type}</span>
          </div>
          <h3 className="mt-2 font-heading text-lg text-foreground">{block.name}</h3>
          <p className="text-xs text-muted-foreground">
            {block.duration_minutes} min · {block.intensity_level} intensity · {(block.exercises || []).length} moves
          </p>
        </div>
        <button
          type="button"
          onClick={() => setOpen(!open)}
          aria-label={open ? 'Hide exercises' : 'Show exercises'}
          className="shrink-0 rounded-full p-1.5 text-muted-foreground hover:bg-secondary"
        >
          {open ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
        </button>
      </div>

      {recurring && (
        <p className="mt-2 text-xs font-semibold text-primary">
          Repeats as {recurring.type} on {recurring.days.map((d) => DAY_ABBR[d]).join(', ')}
        </p>
      )}

      {open && (
        <ul className="mt-3 space-y-1.5 border-t border-border pt-3 text-sm">
          {[...(block.exercises || [])]
            .sort((a, b) => (a.order ?? 0) - (b.order ?? 0))
            .map((ex, i) => (
              <li key={i} className="flex items-baseline justify-between gap-2 rounded-xl bg-secondary/50 px-3 py-1.5">
                <span className="text-foreground">{ex.name}</span>
                <span className="shrink-0 text-xs text-muted-foreground">{ex.duration}</span>
              </li>
            ))}
        </ul>
      )}

      <div className="mt-4 flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => onRecur(block)}
          className="inline-flex items-center gap-1.5 rounded-full border border-border px-4 py-2 text-xs font-semibold text-foreground hover:bg-secondary"
        >
          <CalendarCheck className="h-3.5 w-3.5" />
          Make recurring
        </button>
        <button
          type="button"
          onClick={() => onDoNow(block)}
          className="inline-flex items-center gap-1.5 rounded-full bg-primary px-4 py-2 text-xs font-semibold text-primary-foreground"
        >
          <Play className="h-3.5 w-3.5" />
          Do it now
        </button>
      </div>
    </div>
  );
}