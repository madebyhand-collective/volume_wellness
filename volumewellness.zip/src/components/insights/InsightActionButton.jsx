import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CalendarClock, Heart, PersonStanding, Play, SlidersHorizontal } from 'lucide-react';
import { insightActionType } from '@/lib/insight-visual';
import { logEvent } from '@/lib/behavioral';
import ScheduleSessionDialog from '@/components/insights/ScheduleSessionDialog';
import WhatWorksDialog from '@/components/insights/WhatWorksDialog';

// Every suggestion has exactly one concrete action it can lead to — including
// kudos insights, which ask what's working so we can dig into the wins too.
const ACTION_CTAS = {
  schedule_session: { label: 'Schedule it', icon: CalendarClock },
  start_session: { label: 'Start a session', icon: Play },
  movement_library: { label: 'Find a short flow', icon: PersonStanding },
  view_preferences: { label: 'Tune my setup', icon: SlidersHorizontal },
  share_what_works: { label: "Reflect on what's working", icon: Heart },
};

const ACTION_ROUTES = {
  start_session: '/workout',
  movement_library: '/library',
  view_preferences: '/preferences',
};

// The action button for an insight's suggestion — shared by the Insights
// page cards and the home screen cards so they always match.
// Soft variant for the home cards: very light cream fill with a brand-orange
// outline. The text uses a deepened brand orange so it stays readable on cream.
const SOFT_STYLE = {
  backgroundColor: '#FBF0DE',
  color: '#B8430F',
  borderColor: '#F06427',
};

export default function InsightActionButton({ insight, className, variant = 'primary' }) {
  const navigate = useNavigate();
  const [scheduleOpen, setScheduleOpen] = useState(false);
  const [whatWorksOpen, setWhatWorksOpen] = useState(false);
  const actionType = insightActionType(insight);
  const actionCta = actionType && ACTION_CTAS[actionType];

  if (!actionCta) return null;

  const takeAction = async () => {
    await logEvent('insight_acted_on');
    if (actionType === 'schedule_session') {
      setScheduleOpen(true);
    } else if (actionType === 'share_what_works') {
      setWhatWorksOpen(true);
    } else if (ACTION_ROUTES[actionType]) {
      navigate(ACTION_ROUTES[actionType]);
    }
  };

  return (
    <>
      <button
        type="button"
        onClick={takeAction}
        className={`inline-flex items-center gap-2 rounded-full border-2 px-4 py-2 text-sm font-bold ${
          variant === 'soft' ? '' : 'border-sage bg-primary text-primary-foreground'
        } ${className || ''}`}
        style={variant === 'soft' ? SOFT_STYLE : undefined}
      >
        <actionCta.icon className="h-4 w-4" />
        {actionCta.label}
      </button>
      {actionType === 'schedule_session' && (
        <ScheduleSessionDialog open={scheduleOpen} onOpenChange={setScheduleOpen} />
      )}
      {actionType === 'share_what_works' && (
        <WhatWorksDialog open={whatWorksOpen} onOpenChange={setWhatWorksOpen} insight={insight} />
      )}
    </>
  );
}