import React, { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { base44 } from '@/api/base44Client';
import { useToast } from '@/components/ui/use-toast';
import { getProfile, localTodayStr } from '@/lib/volume';
import { logEvent } from '@/lib/behavioral';
import { setWorkoutReminder } from '@/lib/workout-reminder';
import { createCommitment } from '@/lib/commitments';

const TIME_SLOTS = [
  { value: '07:00', label: 'Morning · 7:00 AM' },
  { value: '12:00', label: 'Midday · 12:00 PM' },
  { value: '17:30', label: 'Evening · 5:30 PM' },
];

const DAY_CHOICES = [
  { offset: 0, label: 'Today' },
  { offset: 1, label: 'Tomorrow' },
];

const ordinal = (n) => {
  const v = n % 100;
  return n + (['th', 'st', 'nd', 'rd'][(v - 20) % 10] || ['th', 'st', 'nd', 'rd'][v] || 'th');
};

const formatLongDay = (d) =>
  `${d.toLocaleDateString('en-US', { weekday: 'long' })}, ${d.toLocaleDateString('en-US', { month: 'long' })} ${ordinal(d.getDate())}`;

const prettyTime = (t) =>
  new Date(`2000-01-01T${t}:00`).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });

// Scheduling screen: pulls up the user's next plan day and lets them lock in
// a day + time, stored as a reminder.
export default function ScheduleSessionDialog({ open, onOpenChange }) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [planDay, setPlanDay] = useState(null);
  const [weekNumber, setWeekNumber] = useState(null);
  const [dayOffset, setDayOffset] = useState(1);
  const [time, setTime] = useState('07:00');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!open) return undefined;
    let cancelled = false;
    setLoading(true);
    setPlanDay(null);
    setWeekNumber(null);
    (async () => {
      try {
        const profile = await getProfile();
        if (cancelled) return;
        if (profile && profile.active_plan_id) {
          const days = await base44.entities.PlanDay.filter({ plan_id: profile.active_plan_id });
          if (cancelled) return;
          const weekDays = days
            .filter((d) => d.week_number === profile.current_week)
            .sort((a, b) => (a.day_index ?? 0) - (b.day_index ?? 0));
          setWeekNumber(profile.current_week);
          setPlanDay(weekDays[Math.min(profile.day_index ?? 0, Math.max(weekDays.length - 1, 0))] || null);
        }
      } catch {
        // a scheduling screen never needs to fail loudly
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [open]);

  const targetDate = new Date(Date.now() + dayOffset * 864e5);

  const confirm = async () => {
    setSaving(true);
    setWorkoutReminder(localTodayStr(targetDate), time);
    await logEvent('insight_acted_on');
    await createCommitment({
      kind: 'workout',
      label: planDay ? planDay.label : 'Your next session',
      due_date: localTodayStr(targetDate),
      due_time: time,
      source: 'insight',
    });
    toast({
      title: 'Slot locked in',
      description: `${planDay ? planDay.label : 'Your next session'} — ${formatLongDay(targetDate)} at ${prettyTime(time)}.`,
    });
    setSaving(false);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="rounded-3xl border-2 border-sage bg-background p-6">
        <DialogHeader>
          <DialogTitle className="font-heading text-2xl text-foreground">Lock in your next session</DialogTitle>
          <DialogDescription>
            Pick a slot that actually works — Volume will remind you when it&apos;s time.
          </DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="flex justify-center py-10">
            <Loader2 className="h-6 w-6 animate-spin text-primary" />
          </div>
        ) : (
          <div className="space-y-5">
            {planDay && (
              <div className="sticker rounded-2xl bg-card p-4">
                <p className="text-xs font-bold uppercase tracking-wide text-muted-foreground">
                  Up next{weekNumber ? ` · Week ${weekNumber}` : ''}
                </p>
                <p className="mt-1 font-heading text-lg text-foreground">{planDay.label}</p>
                {planDay.exercises && planDay.exercises.length > 0 && (
                  <p className="mt-1 text-sm text-muted-foreground">
                    {planDay.exercises.length} exercise{planDay.exercises.length > 1 ? 's' : ''} · {Math.max(...planDay.exercises.map((e) => e.sets || 3))} sets max
                  </p>
                )}
              </div>
            )}

            <div>
              <p className="text-xs font-bold uppercase tracking-wide text-muted-foreground">Day</p>
              <div className="mt-2 flex gap-2">
                {DAY_CHOICES.map(({ offset, label }) => (
                  <button
                    key={offset}
                    type="button"
                    onClick={() => setDayOffset(offset)}
                    className={`rounded-full border-2 border-sage px-4 py-1.5 text-sm font-semibold ${
                      dayOffset === offset ? 'bg-foreground text-primary-foreground' : 'bg-card text-foreground'
                    }`}
                  >
                    {label}
                  </button>
                ))}
              </div>
              <p className="mt-2 text-sm text-muted-foreground">{formatLongDay(targetDate)}</p>
            </div>

            <div>
              <p className="text-xs font-bold uppercase tracking-wide text-muted-foreground">Time</p>
              <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-3">
                {TIME_SLOTS.map((slot) => (
                  <button
                    key={slot.value}
                    type="button"
                    onClick={() => setTime(slot.value)}
                    className={`rounded-full border-2 border-sage px-4 py-1.5 text-sm font-semibold ${
                      time === slot.value ? 'bg-foreground text-primary-foreground' : 'bg-card text-foreground'
                    }`}
                  >
                    {slot.label}
                  </button>
                ))}
              </div>
              <div className="mt-2 flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Or pick your own:</span>
                <Input
                  type="time"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="w-32"
                  aria-label="Custom time"
                />
              </div>
            </div>

            <button
              type="button"
              onClick={confirm}
              disabled={saving || !time}
              className="w-full rounded-full border-2 border-sage bg-primary px-6 py-3 text-sm font-bold text-primary-foreground disabled:opacity-40"
            >
              {saving ? 'Locking it in…' : `Lock in ${prettyTime(time)}`}
            </button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}