import React from 'react';
import {
  CATEGORY_LABELS,
  categoryCardStyle,
  categoryChipStyle,
  categoryIcon,
} from '@/lib/insight-visual';
import InsightActionButton from '@/components/insights/InsightActionButton';

// A general starting-point tip, shown only until the first personal insights
// exist. Styled to match real insight cards so the waiting period feels alive.
// Soft variant matches the tinted home cards; default matches the Insights page.
export default function GeneralInsightCard({ tip, variant = 'default' }) {
  const soft = variant === 'soft';
  const Icon = categoryIcon(tip.category);
  return (
    <div
      className={soft ? 'rounded-3xl p-5' : 'rounded-3xl border border-border bg-card p-5'}
      style={soft ? categoryCardStyle(tip.category) : undefined}
    >
      <span
        className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium"
        style={categoryChipStyle(tip.category)}
      >
        <Icon className="h-3.5 w-3.5" />
        {CATEGORY_LABELS[tip.category] || tip.category}
      </span>
      <h3 className="mt-2 font-heading text-lg text-foreground">{tip.title}</h3>
      <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{tip.body}</p>
      {tip.action_suggestion && (
        <p className="mt-2 rounded-xl bg-secondary/60 px-3 py-2 text-sm text-secondary-foreground">
          {tip.action_suggestion}
        </p>
      )}
      <div className="mt-3">
        <InsightActionButton insight={tip} variant={soft ? 'soft' : 'primary'} />
      </div>
    </div>
  );
}