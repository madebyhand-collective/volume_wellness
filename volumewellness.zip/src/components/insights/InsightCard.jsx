import React, { useState } from 'react';
import { Bookmark, ThumbsDown, ThumbsUp, X } from 'lucide-react';
import {
  CATEGORY_LABELS,
  MOOD_STYLES,
  categoryChipStyle,
  categoryIcon,
} from '@/lib/insight-visual';
import { logEvent } from '@/lib/behavioral';
import InsightActionButton from '@/components/insights/InsightActionButton';
import NotHelpfulDialog from '@/components/insights/NotHelpfulDialog';
import { useToast } from '@/components/ui/use-toast';

export default function InsightCard({ insight, onUpdate }) {
  const { toast } = useToast();
  const [notHelpfulOpen, setNotHelpfulOpen] = useState(false);
  const mood = insight.user_rating && MOOD_STYLES[insight.user_rating];
  const Icon = categoryIcon(insight.category);

  const rateNotHelpful = async (reason) => {
    await logEvent('recommendation_rejected');
    onUpdate({ user_rating: 'not_helpful', rating_reason: reason, status: insight.status === 'saved' ? 'saved' : 'seen' });
    setNotHelpfulOpen(false);
    toast({ title: 'Noted — that kind of insight will ease off.' });
  };
  return (
    <div className="rounded-3xl border border-border bg-card p-5" style={mood}>
      <div className="flex items-center justify-between gap-2">
        <span
          className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium"
          style={categoryChipStyle(insight.category)}
        >
          <Icon className="h-3.5 w-3.5" />
          {CATEGORY_LABELS[insight.category] || insight.category}
        </span>
        <span className="flex items-center gap-1.5">
          {insight.status === 'new' && (
            <span className="rounded-full bg-primary px-2.5 py-0.5 text-xs font-bold uppercase tracking-wide text-primary-foreground">
              New
            </span>
          )}
          {insight.status === 'saved' && (
            <span className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-bold text-primary">
              <Bookmark className="h-3 w-3" /> Saved
            </span>
          )}
        </span>
      </div>
      <h3 className="mt-2 font-heading text-lg text-foreground">{insight.title}</h3>
      <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{insight.body}</p>
      {insight.action_suggestion && (
        <p className="mt-2 rounded-xl bg-secondary/60 px-3 py-2 text-sm text-secondary-foreground">{insight.action_suggestion}</p>
      )}
      <InsightActionButton insight={insight} className="mt-3" />
      <div className="mt-3 flex items-center gap-1">
        <button
          type="button"
          onClick={() => onUpdate({ user_rating: 'helpful', status: insight.status === 'saved' ? 'saved' : 'seen' })}
          className={`inline-flex items-center gap-1 rounded-full px-3 py-1.5 text-xs font-medium ${
            insight.user_rating === 'helpful' ? 'bg-primary text-primary-foreground' : 'border border-border text-muted-foreground hover:bg-secondary'
          }`}
        >
          <ThumbsUp className="h-3.5 w-3.5" /> Helpful
        </button>
        <button
          type="button"
          onClick={() => setNotHelpfulOpen(true)}
          className={`inline-flex items-center gap-1 rounded-full px-3 py-1.5 text-xs font-medium ${
            insight.user_rating === 'not_helpful' ? 'bg-accent text-accent-foreground' : 'border border-border text-muted-foreground hover:bg-secondary'
          }`}
        >
          <ThumbsDown className="h-3.5 w-3.5" /> Not helpful
        </button>
        <div className="flex-1" />
        <button
          type="button"
          aria-label="Save insight"
          onClick={() => onUpdate({ status: insight.status === 'saved' ? 'seen' : 'saved' })}
          className={`rounded-full p-1.5 ${insight.status === 'saved' ? 'text-primary' : 'text-muted-foreground hover:bg-secondary'}`}
        >
          <Bookmark className="h-4 w-4" />
        </button>
        <button
          type="button"
          aria-label="Dismiss insight"
          onClick={() => onUpdate({ status: 'dismissed' })}
          className="rounded-full p-1.5 text-muted-foreground hover:bg-secondary"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      <NotHelpfulDialog
        open={notHelpfulOpen}
        onOpenChange={setNotHelpfulOpen}
        currentReason={insight.rating_reason}
        onConfirm={rateNotHelpful}
      />
    </div>
  );
}