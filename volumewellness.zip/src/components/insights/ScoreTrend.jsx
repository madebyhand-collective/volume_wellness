import React, { useEffect, useState } from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts';
import { base44 } from '@/api/base44Client';
import { localTodayStr, daysAgoStr, TIERS } from '@/lib/volume';

const tierColor = (tier) =>
  ({ amplify: '#f06427', baseline: '#bda634', modify: '#5e5220', restore: '#88904f', rest: '#5e5220' }[tier] || '#f06427');

export default function ScoreTrend() {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const list = await base44.entities.DailyAssessment.list('-created_date', 60);
        if (cancelled) return;
        const since = daysAgoStr(30);
        const rows = list
          .filter((a) => a.date && a.date >= since && typeof a.volume_score_total === 'number')
          .sort((a, b) => a.date.localeCompare(b.date))
          .map((a) => ({
            date: a.date,
            label: new Date(`${a.date}T12:00:00`).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
            score: Math.round(a.volume_score_total),
            tier: a.volume_score_tier,
          }));
        setData(rows);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-primary" />
      </div>
    );
  }

  if (data.length === 0) {
    return (
      <div className="sticker rounded-3xl bg-sage p-8 text-center">
        <h2 className="font-heading text-xl text-foreground">No check-ins in the past month</h2>
        <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
          Your daily volume score gets plotted here after you check in. A few days of data is all it takes.
        </p>
      </div>
    );
  }

  const avg = data.reduce((sum, d) => sum + d.score, 0) / data.length;

  return (
    <div className="space-y-4">
      <div className="sticker rounded-3xl bg-card p-5">
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <h2 className="font-heading text-xl text-foreground">Volume score, last 30 days</h2>
          <span className="text-xs font-bold uppercase tracking-wide text-muted-foreground">
            {data.length} check-in{data.length === 1 ? '' : 's'} · avg {Math.round(avg)}
          </span>
        </div>
        <div className="mt-4 -ml-4">
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={data} margin={{ top: 8, right: 12, bottom: 0, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(94,82,32,0.15)" vertical={false} />
              <XAxis
                dataKey="label"
                tick={{ fontSize: 11, fill: '#5e5220' }}
                tickLine={false}
                axisLine={{ stroke: 'rgba(94,82,32,0.3)' }}
                interval="preserveStartEnd"
                minTickGap={24}
              />
              <YAxis
                domain={[0, 100]}
                tick={{ fontSize: 11, fill: '#5e5220' }}
                tickLine={false}
                axisLine={false}
                width={28}
              />
              <Tooltip
                formatter={(value, name, item) => {
                  const tier = item && item.payload && item.payload.tier;
                  const tierLabel = tier && TIERS[tier] ? TIERS[tier].label : '';
                  return [`${value}${tierLabel ? ` (${tierLabel})` : ''}`, 'Volume score'];
                }}
                contentStyle={{
                  borderRadius: 12,
                  border: '2px solid #000',
                  boxShadow: '4px 4px 0 #000',
                  background: '#fff',
                  fontSize: 12,
                }}
              />
              <Line
                type="monotone"
                dataKey="score"
                stroke="#f06427"
                strokeWidth={3}
                dot={{ r: 4, fill: '#f06427' }}
                activeDot={{ r: 6 }}
                isAnimationActive={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        {Object.entries(TIERS).map(([key, tier]) => (
          <span
            key={key}
            className="rounded-full px-3 py-1 text-xs font-bold uppercase tracking-wide text-[#5e5220]"
            style={{ backgroundColor: 'rgba(254,227,197,0.25)' }}
          >
            {tier.label}
          </span>
        ))}
      </div>
    </div>
  );
}