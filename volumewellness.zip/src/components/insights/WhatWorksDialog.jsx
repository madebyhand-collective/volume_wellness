import React, { useEffect, useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { base44 } from '@/api/base44Client';
import { WHAT_WORKS_FACTORS } from '@/lib/insight-visual';

const HEADLINES = {
  positive_reinforcement: {
    title: 'What made this week click?',
    prompt: 'You did the thing — take a moment to notice what carried you.',
  },
  life_load_correlation: {
    title: 'What helps you show up on the hard days?',
    prompt: 'You moved on days when life was heavy. That matters — reflect on what made it possible.',
  },
};

// Kudos insights dig just as deep as the misses: we ask what's working,
// so we can help the user see and protect their own successful patterns.
export default function WhatWorksDialog({ open, onOpenChange, insight }) {
  const [factors, setFactors] = useState([]);
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (open) {
      setFactors([]);
      setNote('');
      setSaving(false);
      setSaved(false);
    }
  }, [open]);

  const headline = HEADLINES[insight.category] || {
    title: "What's going right?",
    prompt: "Reflect on what's working so you can protect it.",
  };

  const toggle = (value) =>
    setFactors((f) => (f.includes(value) ? f.filter((x) => x !== value) : [...f, value]));

  const submit = async () => {
    setSaving(true);
    await base44.entities.Insight.update(insight.id, {
      what_works_factors: factors,
      what_works_note: note.trim() || null,
    }).catch(() => null);
    setSaving(false);
    setSaved(true);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="rounded-3xl border-2 border-sage bg-background p-6">
        {saved ? (
          <div className="py-4 text-center">
            <h2 className="font-heading text-2xl text-foreground">Thank you — really.</h2>
            <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
              This is exactly the kind of connection that helps Volume connect what works for
              you — and what to protect on the days it gets hard.
            </p>
            <button
              type="button"
              onClick={() => onOpenChange(false)}
              className="mt-5 rounded-full border-2 border-sage bg-primary px-6 py-2.5 text-sm font-bold text-primary-foreground"
            >
              Done
            </button>
          </div>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle className="font-heading text-2xl text-foreground">{headline.title}</DialogTitle>
              <DialogDescription>
                {headline.prompt} Pick everything that helped — the more specific, the better.
              </DialogDescription>
            </DialogHeader>
            <div className="flex flex-wrap gap-2">
              {WHAT_WORKS_FACTORS.map(({ value, label }) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => toggle(value)}
                  className={`rounded-full border-2 border-sage px-3 py-1.5 text-xs font-semibold ${
                    factors.includes(value) ? 'bg-foreground text-primary-foreground' : 'bg-card text-foreground'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
            <Textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Anything else worth knowing? (optional)"
              aria-label="What else is working"
              className="min-h-20"
            />
            <button
              type="button"
              disabled={factors.length === 0 || saving}
              onClick={submit}
              className="w-full rounded-full border-2 border-sage bg-primary px-6 py-3 text-sm font-bold text-primary-foreground disabled:opacity-40"
            >
              {saving ? 'Sharing…' : 'Share it'}
            </button>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}