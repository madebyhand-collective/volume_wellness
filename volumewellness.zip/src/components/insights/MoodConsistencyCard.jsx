import React, { useEffect, useState } from 'react';
import { HeartPulse } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { localTodayStr } from '@/lib/volume';

const MOOD_SCORES = { rough: 1, low: 2, okay: 3, good: 4, great: 5 };
const MOOD_LABELS = [null, 'Rough', 'Low', 'Okay', 'Good', 'Great'];
const DONE = ['completed', 'partial'];
const DAYS = 30;

const labelFor = (avg) => MOOD_LABELS[Math.max(1, Math.min(5, Math.round(avg)))];

// How mood from daily check-ins lines up with workout consistency:
// average mood on days a session got done vs days it didn't, last 30 days.
export default function MoodConsistencyCard() {
  const [rows, setRows] = useState(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const [assessments, sessions] = await Promise.all([
        base44.entities.DailyAssessment.list('-created_date', 60).catch(() => []),
        base44.entities.WorkoutSession.list('-created_date', 200).catch(() => []),
      ]);
      if (cancelled) return;

      const moodByDate = {};
      for (const a of assessments) {
        if (a.self_mood && MOOD_SCORES[a.self_mood]) moodByDate[a.date] = a.self_mood;
      }
      const trained = new Set(
        sessions.filter((s) => DONE.includes(s.status) && s.date).map((s) => s.date)
      );

      const dates = [];
      const cursor = new Date();
      for (let i = 0; i < DAYS; i++) {
        dates.unshift(localTodayStr(cursor));
        cursor.setDate(cursor.getDate() - 1);
      }

      const trainedMoods = [];
      const restMoods = [];
      for (const d of dates) {
        const m = moodByDate[d];
        if (!m) continue;
        (trained.has(d) ? trainedMoods : restMoods).push(MOOD_SCORES[m]);
      }
      const avg = (arr) => (arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : null);
      setRows({
        trained: avg(trainedMoods),
        trainedCount: trainedMoods.length,
        rest: avg(restMoods),
        restCount: restMoods.length,
      });
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  if (!rows) return null;

  const total = rows.trainedCount + rows.restCount;

  return (
    <div className="sticker rounded-3xl bg-card p-5">
      <div className="flex items-center gap-2">
        <HeartPulse className="h-5 w-5 text-primary" aria-hidden="true" />
        <h2 className="font-heading text-lg text-foreground">Mood and movement</h2>
      </div>

      {total < 3 ? (
        <p className="mt-3 text-sm text-muted-foreground">
          A few more check-ins with a mood rating will show how feelings and workouts line up.
        </p>
      ) : (
        <div>
          <div className="mt-3 grid grid-cols-2 gap-3 text-center">
            <div className="rounded-2xl bg-accent p-4">
              <p className="font-heading text-2xl text-foreground">{rows.trained !== null ? labelFor(rows.trained) : '—'}</p>
              <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Training days ({rows.trainedCount})</p>
            </div>
            <div className="rounded-2xl bg-muted p-4">
              <p className="font-heading text-2xl text-foreground">{rows.rest !== null ? labelFor(rows.rest) : '—'}</p>
              <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Days without ({rows.restCount})</p>
            </div>
          </div>
          <p className="mt-3 text-sm text-muted-foreground">
            Average mood over the last 30 days, on days a workout happened versus days it didn&apos;t.
          </p>
        </div>
      )}
    </div>
  );
}