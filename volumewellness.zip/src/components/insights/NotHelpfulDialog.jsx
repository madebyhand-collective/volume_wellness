import React, { useEffect, useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { RATING_REASONS } from '@/lib/insight-visual';

// Asks WHY a recommendation wasn't useful, so the app can tailor future ones.
export default function NotHelpfulDialog({ open, onOpenChange, onConfirm, currentReason }) {
  const [reason, setReason] = useState(currentReason || null);

  useEffect(() => {
    if (open) setReason(currentReason || null);
  }, [open, currentReason]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="rounded-3xl border-2 border-sage bg-background p-6">
        <DialogHeader>
          <DialogTitle className="font-heading text-2xl text-foreground">Why wasn&apos;t this one useful?</DialogTitle>
          <DialogDescription>
            No wrong answers — your response shapes what shows up next.
          </DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-1 gap-2">
          {RATING_REASONS.map(({ value, label }) => (
            <button
              key={value}
              type="button"
              onClick={() => setReason(value)}
              className={`rounded-full border-2 border-sage px-4 py-2 text-sm font-semibold ${
                reason === value ? 'bg-foreground text-primary-foreground' : 'bg-card text-foreground'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
        <button
          type="button"
          disabled={!reason}
          onClick={() => onConfirm(reason)}
          className="mt-2 w-full rounded-full border-2 border-sage bg-primary px-6 py-3 text-sm font-bold text-primary-foreground disabled:opacity-40"
        >
          Submit
        </button>
      </DialogContent>
    </Dialog>
  );
}