import { illustrationUrl } from '@/lib/illustrations';

// Decorative brand illustration. Always aria-hidden / empty alt — these are
// visual accents, never informational content.
export default function Illustration({ motif, color = 'sunset', className = '' }) {
  return (
    <img
      src={illustrationUrl(motif, color)}
      alt=""
      aria-hidden="true"
      loading="lazy"
      className={className}
    />
  );
}