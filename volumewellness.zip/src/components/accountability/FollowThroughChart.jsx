import React, { useMemo } from 'react';
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { commitmentDueMs } from '@/lib/commitments';

function weekStartMs(ms) {
  const d = new Date(ms);
  const day = (d.getDay() + 6) % 7; // weeks start Monday
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() - day);
  return d.getTime();
}

// Weekly follow-through rate across resolved commitments — kept / (kept + missed),
// grouped by the week each promise was due.
export default function FollowThroughChart({ commitments }) {
  const data = useMemo(() => {
    const byWeek = {};
    for (const c of commitments) {
      if (c.status === 'pending') continue;
      const due = commitmentDueMs(c);
      if (!Number.isFinite(due)) continue;
      const wk = weekStartMs(due);
      byWeek[wk] = byWeek[wk] || { kept: 0, missed: 0 };
      byWeek[wk][c.status === 'kept' ? 'kept' : 'missed'] += 1;
    }
    return Object.entries(byWeek)
      .map(([wk, { kept, missed }]) => ({
        key: Number(wk),
        week: new Date(Number(wk)).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        rate: Math.round((kept / (kept + missed)) * 100),
        kept,
        missed,
      }))
      .sort((a, b) => a.key - b.key)
      .slice(-8);
  }, [commitments]);

  if (data.length === 0) {
    return (
      <p className="py-10 text-center text-sm text-muted-foreground">
        No promises have come due yet — once they do, your follow-through shows up here.
      </p>
    );
  }

  return (
    <div className="h-56 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 8, right: 12, bottom: 0, left: -18 }}>
          <CartesianGrid stroke="hsl(var(--muted))" strokeDasharray="3 3" vertical={false} />
          <XAxis dataKey="week" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} />
          <YAxis domain={[0, 100]} ticks={[0, 50, 100]} tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} tickFormatter={(v) => `${v}%`} />
          <Tooltip
            formatter={(value, name, entry) =>
              name === 'rate'
                ? [`${value}% kept (${entry.payload.kept} of ${entry.payload.kept + entry.payload.missed})`, 'Follow-through']
                : [value, name]
            }
            labelStyle={{ fontWeight: 700 }}
            contentStyle={{ borderRadius: 12, border: '2px solid hsl(var(--foreground))' }}
          />
          <Line type="monotone" dataKey="rate" stroke="hsl(var(--chart-1))" strokeWidth={3} dot={{ r: 4, fill: 'hsl(var(--chart-1))' }} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}