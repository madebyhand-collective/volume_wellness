import React from 'react';
import { CalendarX2 } from 'lucide-react';
import { OUTCOME_REASONS, dueLabel } from '@/lib/commitments';

const REASON_LABELS = Object.fromEntries(OUTCOME_REASONS.map((r) => [r.value, r.label]));

// Recent missed check-ins — where the follow-through fell short, with the
// reason captured at the time, so patterns are visible at a glance.
export default function MissedList({ commitments }) {
  const missed = commitments
    .filter((c) => c.status === 'missed' && c.kind === 'checkin')
    .sort((a, b) => new Date(b.due_date) - new Date(a.due_date))
    .slice(0, 10);

  if (missed.length === 0) {
    return (
      <div className="flex flex-col items-center py-8 text-center">
        <CalendarX2 className="h-8 w-8 text-primary" />
        <p className="mt-3 max-w-sm text-sm text-muted-foreground">
          No missed check-ins. Every check-in you promised came through — that&apos;s the streak to protect.
        </p>
      </div>
    );
  }

  return (
    <ul className="divide-y divide-border">
      {missed.map((c) => (
        <li key={c.id} className="flex flex-wrap items-center justify-between gap-2 py-3">
          <div>
            <p className="text-sm font-bold text-foreground">{c.label}</p>
            <p className="text-xs text-muted-foreground">Due {dueLabel(c)}</p>
          </div>
          {c.outcome_reason && (
            <span className="rounded-full bg-accent px-3 py-1 text-xs font-semibold text-accent-foreground">
              {REASON_LABELS[c.outcome_reason] || c.outcome_reason}
            </span>
          )}
        </li>
      ))}
    </ul>
  );
}