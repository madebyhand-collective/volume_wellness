export default function ScoreDial({ score, tier, size = 160 }) {
  const radius = (size - 16) / 2;
  const circumference = 2 * Math.PI * radius;
  const pct = Math.max(0, Math.min(100, score || 0)) / 100;
  const stroke = tier === 'amplify' || tier === 'baseline' ? '#f06427' : tier === 'modify' ? '#bda634' : '#5e5220';

  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="#fee3c5" strokeWidth="10" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={stroke}
          strokeWidth="10"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={circumference * (1 - pct)}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-heading text-4xl text-foreground">{Math.round(score ?? 0)}</span>
        <span className="text-xs uppercase tracking-wide text-muted-foreground">Volume Score</span>
      </div>
    </div>
  );
}