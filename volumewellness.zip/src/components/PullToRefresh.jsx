import React, { useRef, useState } from 'react';
import Illustration from '@/components/Illustration';
import { APP_ICON_MOTIFS } from '@/lib/name-style';

const THRESHOLD = 70;
const MAX_PULL = 90;

// Touch-only pull-to-refresh wrapper for the iOS WebView. Desktop is untouched.
export default function PullToRefresh({ onRefresh, children }) {
  const [pull, setPull] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const [motif, setMotif] = useState(APP_ICON_MOTIFS[0]);
  const startY = useRef(null);

  const onTouchStart = (e) => {
    if (refreshing) return;
    if (window.scrollY <= 0) {
      startY.current = e.touches[0].clientY;
      setMotif(APP_ICON_MOTIFS[Math.floor(Math.random() * APP_ICON_MOTIFS.length)]);
    } else {
      startY.current = null;
    }
  };

  const onTouchMove = (e) => {
    if (startY.current === null || refreshing) return;
    const dy = e.touches[0].clientY - startY.current;
    setPull(dy > 0 ? Math.min(dy * 0.5, MAX_PULL) : 0);
  };

  const onTouchEnd = async () => {
    if (startY.current === null) return;
    startY.current = null;
    if (pull >= THRESHOLD) {
      setRefreshing(true);
      try {
        await onRefresh();
      } finally {
        setRefreshing(false);
        setPull(0);
      }
    } else {
      setPull(0);
    }
  };

  return (
    <div onTouchStart={onTouchStart} onTouchMove={onTouchMove} onTouchEnd={onTouchEnd}>
      <div
        className="flex items-center justify-center"
        style={{ height: refreshing ? 44 : Math.max(pull - 24, 0), opacity: pull > 0 || refreshing ? 1 : 0 }}
        aria-hidden="true"
      >
        <span
          className={`inline-flex h-7 w-7 ${refreshing ? 'animate-spin' : ''}`}
          style={{ transform: refreshing ? undefined : `rotate(${Math.min(pull * 3, 270)}deg)` }}
        >
          <Illustration motif={motif} color="sunset" className="h-7 w-7" />
        </span>
      </div>
      <div style={{ transform: pull > 0 ? `translateY(${pull * 0.15}px)` : undefined }} className={refreshing ? 'pointer-events-none' : undefined}>
        {children}
      </div>
    </div>
  );
}