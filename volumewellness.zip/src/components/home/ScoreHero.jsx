import React, { useMemo, useState } from 'react';
import { Activity, Briefcase, Brain, TrendingUp, Info } from 'lucide-react';

const R = 82;
const C = 2 * Math.PI * R;
const GAP = 10; // spacing between ring segments

const DEFAULT_WEIGHTS = {
  weight_body_signal: 0.4,
  weight_life_load: 0.3,
  weight_mental_readiness: 0.2,
  weight_behavioral_momentum: 0.1,
};

const FACTORS = [
  { key: 'weight_body_signal', scoreKey: 'vs_body_signal', label: 'Body signal', icon: Activity, color: 'hsl(var(--sun))' },
  { key: 'weight_life_load', scoreKey: 'vs_life_load', label: 'Life load', icon: Briefcase, color: 'hsl(var(--bloom))' },
  { key: 'weight_mental_readiness', scoreKey: 'vs_mental_readiness', label: 'Mental readiness', icon: Brain, color: 'hsl(var(--sky))' },
  { key: 'weight_behavioral_momentum', scoreKey: 'vs_behavioral_momentum', label: 'Behavioral momentum', icon: TrendingUp, color: 'hsl(var(--sage))' },
];

// Volume score hero: the score (out of 100) centered inside a ring whose
// segments are sized by how much each factor weighs on the score.
export default function ScoreHero({ assessment, prefs }) {
  const [showLegend, setShowLegend] = useState(false);

  const segments = useMemo(() => {
    let acc = 0;
    const built = FACTORS.map((f) => {
      const weight = Number(prefs && prefs[f.key] != null ? prefs[f.key] : DEFAULT_WEIGHTS[f.key]) || 0;
      const span = Math.max(0, weight * C - GAP);
      const seg = { ...f, weight, span, offset: acc };
      acc += span + GAP;
      return seg;
    });
    return built;
  }, [prefs]);

  return (
    <div className="flex flex-col items-center">
      <div className="relative mx-auto aspect-square w-72 max-w-full">
        <svg viewBox="0 0 200 200" className="h-full w-full -rotate-90" aria-hidden="true">
          {segments.map((s) => (
            <circle
              key={s.key}
              cx="100"
              cy="100"
              r={R}
              fill="none"
              stroke={s.color}
              strokeWidth="32"
              strokeLinecap="round"
              strokeDasharray={`${s.span} ${C - s.span}`}
              strokeDashoffset={-s.offset}
            />
          ))}
        </svg>
        {segments.map((s) => {
          const mid = s.offset + s.span / 2;
          const angle = ((mid / C) * 360 - 90) * (Math.PI / 180);
          const left = (100 + R * Math.cos(angle)) / 2;
          const top = (100 + R * Math.sin(angle)) / 2;
          return (
            <span
              key={s.key}
              className="absolute flex -translate-x-1/2 -translate-y-1/2 items-center justify-center"
              style={{ left: `${left}%`, top: `${top}%` }}
              aria-hidden="true"
            >
              <s.icon className="h-4 w-4 text-primary-foreground" />
            </span>
          );
        })}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="font-display text-6xl text-foreground">
            {Math.round(assessment.volume_score_total || 0)}
          </span>
          <button
            type="button"
            onClick={() => setShowLegend((v) => !v)}
            className="mt-1 inline-flex items-center gap-1 text-xs font-semibold text-muted-foreground hover:text-foreground"
          >
            your volume score
            <Info className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {showLegend && (
        <div className="mt-4 w-full rounded-3xl border border-border bg-card p-4">
          {segments.map((s) => (
            <div key={s.key} className="flex items-center justify-between gap-3 py-1.5">
              <span className="flex items-center gap-2 text-sm font-semibold text-foreground">
                <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: s.color }} />
                {s.label}
              </span>
              <span className="text-xs text-muted-foreground">
                {Math.round(s.weight * 100)}% of score
                {assessment[s.scoreKey] != null && ` · scored ${Math.round(assessment[s.scoreKey])}`}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}