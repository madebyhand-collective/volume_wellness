import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogClose } from '@/components/ui/dialog';
import { TIERS } from '@/lib/volume';

const TIER_ORDER = ['amplify', 'baseline', 'modify', 'restore', 'rest'];

// What each tier indicates, and what it actually changes in today's session —
// surfaced by tapping the tier pill on the home screen.
const TIER_DETAILS = {
  amplify: {
    heading: 'You have extra to give',
    body: "Body and life are in a good place, so you'll be challenged more — an extra set on your main work and the full session length.",
    changes: 'Extra set · up to 45 min',
  },
  baseline: {
    heading: 'The plan, as written',
    body: "You're doing well and ready to go — tackle today's session exactly the way your plan lays it out.",
    changes: 'Plan as written · up to 45 min',
  },
  modify: {
    heading: 'Do the plan, listen to your body',
    body: 'Same movements, but something needs adjusting — a shorter cap on the session and room to dial the intensity back if you need to.',
    changes: 'Up to 30 min',
  },
  restore: {
    heading: 'Your body is asking for gentleness',
    body: 'A short restore session counts today — mobility or PT flows from the Movement library are exactly right here.',
    changes: 'One less set · up to 20 min',
  },
  rest: {
    heading: 'Rest is part of the plan',
    body: 'Active rest today. A walk or breathing work is enough — showing up tomorrow matters more than pushing through today.',
    changes: 'No session · walk or breathe',
  },
};

export default function TierDefinitionsDialog({ open, onOpenChange, currentTier }) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="flex max-h-[85dvh] flex-col overflow-hidden rounded-3xl border-2 border-sage bg-background p-0">
        <DialogHeader className="p-6 pb-4 pr-14">
          <DialogTitle className="font-heading text-2xl text-foreground">What your tier means</DialogTitle>
          <DialogDescription>
            Your check-in sets the tier each day. Here&apos;s what each one says about you — and what it changes.
          </DialogDescription>
        </DialogHeader>
        <div className="overflow-y-auto px-6 pb-2">
          <div className="space-y-3">
            {TIER_ORDER.map((key) => {
              const tier = TIERS[key];
              const detail = TIER_DETAILS[key];
              const isCurrent = key === currentTier;
              return (
                <div
                  key={key}
                  className={`rounded-2xl border-2 p-4 ${
                    isCurrent ? 'border-primary bg-card' : 'border-transparent bg-card/60'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className={`inline-flex rounded-full border-2 border-sage px-3 py-1 font-heading text-xs font-bold uppercase tracking-wide ${tier.chip}`}>{tier.label}</span>
                    {isCurrent && (
                      <span className="rounded-full bg-primary px-2.5 py-0.5 text-xs font-bold uppercase tracking-wide text-primary-foreground">
                        Today
                      </span>
                    )}
                  </div>
                  <p className="text-sm font-bold text-foreground">{detail.heading}</p>
                  <p className="mt-1 text-sm text-foreground/80">{detail.body}</p>
                  <p className="mt-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                    {detail.changes}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
        <div className="p-6 pt-4">
          <DialogClose className="w-full rounded-full border-2 border-sage bg-card px-6 py-3 text-sm font-bold text-foreground hover:bg-secondary/30">
            Close
          </DialogClose>
        </div>
      </DialogContent>
    </Dialog>
  );
}