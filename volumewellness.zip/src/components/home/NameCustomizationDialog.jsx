import React, { useEffect, useState } from 'react';
import { Ban, Loader2 } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { base44 } from '@/api/base44Client';
import { useToast } from '@/components/ui/use-toast';
import Illustration from '@/components/Illustration';
import { NAME_MOTIFS, ACCENTS, DEFAULT_NAME_MOTIF, APP_ICON_MOTIFS, DEFAULT_APP_ICON, getAccent, applyAppIcon } from '@/lib/name-style';
import { invalidateVolumeCache } from '@/lib/volume';

// Lets the user pick the illustration beside their name on Today, the accent
// color shared by name and illustration, or no illustration at all.
export default function NameCustomizationDialog({ open, onOpenChange, prefs, name, onSave }) {
  const { toast } = useToast();
  const [motif, setMotif] = useState(DEFAULT_NAME_MOTIF);
  const [accentId, setAccentId] = useState('');
  const [appIcon, setAppIcon] = useState(DEFAULT_APP_ICON);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setMotif((prefs && prefs.home_illustration) || DEFAULT_NAME_MOTIF);
      setAccentId((prefs && prefs.home_accent_color) || '');
      setAppIcon((prefs && prefs.app_icon) || DEFAULT_APP_ICON);
    }
  }, [open, prefs]);

  const accent = getAccent(accentId);

  const save = async () => {
    setSaving(true);
    try {
      const patch = { home_illustration: motif, home_accent_color: accentId, app_icon: appIcon };
      const updated = prefs && prefs.id
        ? await base44.entities.Preferences.update(prefs.id, patch)
        : await base44.entities.Preferences.create(patch);
      invalidateVolumeCache();
      applyAppIcon(appIcon, accentId);
      onSave(updated);
      onOpenChange(false);
    } catch (e) {
      toast({ title: 'Could not save that — try again.', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md rounded-3xl border-2 border-sage bg-card">
        <DialogHeader>
          <DialogTitle className="font-heading text-xl">Your name, your way</DialogTitle>
        </DialogHeader>

        <div
          className="flex items-center gap-2 rounded-2xl bg-muted px-4 py-3 font-heading text-2xl text-foreground"
          style={accent.text ? { color: accent.text } : undefined}
        >
          {name}
          {motif !== 'none' && (
            <Illustration motif={motif} color={accent.id || 'sunset'} className="h-7 w-7" />
          )}
        </div>

        <div>
          <p className="text-sm font-bold text-foreground">Illustration</p>
          <div className="mt-2 grid grid-cols-4 gap-2">
            {NAME_MOTIFS.map((m) => (
              <button
                key={m}
                type="button"
                aria-label={m}
                onClick={() => setMotif(m)}
                className={`flex items-center justify-center rounded-2xl border-2 p-2 ${
                  motif === m ? 'border-primary bg-muted' : 'border-sage bg-card hover:bg-muted'
                }`}
              >
                <Illustration motif={m} color={accent.id || 'sunset'} className="h-10 w-10" />
              </button>
            ))}
            <button
              type="button"
              aria-label="No illustration"
              onClick={() => setMotif('none')}
              className={`flex flex-col items-center justify-center gap-1 rounded-2xl border-2 p-2 text-xs font-semibold ${
                motif === 'none' ? 'border-primary bg-muted' : 'border-sage bg-card hover:bg-muted'
              }`}
            >
              <Ban className="h-5 w-5 text-muted-foreground" />
              None
            </button>
          </div>
        </div>

        <div>
          <p className="text-sm font-bold text-foreground">Color</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {ACCENTS.map((a) => (
              <button
                key={a.id || 'default'}
                type="button"
                onClick={() => setAccentId(a.id)}
                className={`flex items-center gap-2 rounded-full border-2 px-3 py-1.5 text-xs font-semibold ${
                  accentId === a.id ? 'border-primary bg-muted' : 'border-sage bg-card hover:bg-muted'
                }`}
              >
                <span className="h-4 w-4 rounded-full border border-sage" style={{ background: a.swatch }} />
                {a.label}
              </button>
            ))}
          </div>
        </div>

        <div>
          <p className="text-sm font-bold text-foreground">App icon</p>
          <p className="text-xs text-muted-foreground">The little mark in your browser tab.</p>
          <div className="mt-2 grid grid-cols-4 gap-2">
            {APP_ICON_MOTIFS.map((m) => (
              <button
                key={m}
                type="button"
                aria-label={m}
                onClick={() => setAppIcon(m)}
                className={`flex items-center justify-center rounded-2xl border-2 p-2 ${
                  appIcon === m ? 'border-primary bg-muted' : 'border-sage bg-card hover:bg-muted'
                }`}
              >
                <Illustration motif={m} color={accent.id || 'sunset'} className="h-10 w-10" />
              </button>
            ))}
          </div>
        </div>

        <button
          type="button"
          onClick={save}
          disabled={saving}
          className="inline-flex items-center justify-center gap-2 rounded-full bg-foreground px-6 py-3 text-sm font-bold text-primary-foreground disabled:opacity-40"
        >
          {saving && <Loader2 className="h-4 w-4 animate-spin" />}
          Save
        </button>
      </DialogContent>
    </Dialog>
  );
}