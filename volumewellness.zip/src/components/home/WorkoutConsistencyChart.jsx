import React, { useEffect, useState } from 'react';
import { Flame } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { localTodayStr } from '@/lib/volume';

const DAYS = 30;
const DONE = ['completed', 'partial'];
const RANK = { completed: 3, partial: 2, skipped: 1, deferred: 1, abandoned: 1 };
const WEEKDAYS = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];

function buildWindow() {
  const entries = [];
  const cursor = new Date();
  for (let i = 0; i < DAYS; i++) {
    entries.unshift({ str: localTodayStr(cursor), date: new Date(cursor) });
    cursor.setDate(cursor.getDate() - 1);
  }
  return entries;
}

function summarize(sessions) {
  const byDate = {};
  for (const s of sessions) {
    const r = RANK[s.status] || 0;
    if (r && (!byDate[s.date] || (RANK[byDate[s.date]] || 0) < r)) byDate[s.date] = s.status;
  }

  const window = buildWindow();
  const statusOf = (str) => byDate[str] || null;
  const done = (str) => DONE.includes(statusOf(str));

  // Current streak: consecutive done days ending today (or yesterday if today is still open)
  let streak = 0;
  let idx = window.length - 1;
  if (!done(window[idx].str)) idx -= 1;
  while (idx >= 0 && done(window[idx].str)) {
    streak += 1;
    idx -= 1;
  }

  let longest = 0;
  let run = 0;
  const weekdayCounts = [0, 0, 0, 0, 0, 0, 0];
  for (const { str, date } of window) {
    run = done(str) ? run + 1 : 0;
    longest = Math.max(longest, run);
    if (done(str)) weekdayCounts[date.getDay()] += 1;
  }

  return {
    window,
    statusOf,
    streak,
    longest,
    doneCount: window.filter((e) => done(e.str)).length,
    weekdayCounts,
  };
}

const CELL_STYLES = {
  completed: 'bg-primary',
  partial: 'bg-secondary',
  skipped: 'bg-accent',
  deferred: 'bg-accent',
  abandoned: 'bg-accent',
  none: 'bg-card',
};

const STATUS_LABELS = {
  completed: 'Completed',
  partial: 'Partial',
  skipped: 'Skipped or deferred',
  deferred: 'Skipped or deferred',
  abandoned: 'Abandoned',
  none: 'Rest day',
};

export default function WorkoutConsistencyChart() {
  const [data, setData] = useState(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const sessions = await base44.entities.WorkoutSession.list('-created_date', 200).catch(() => []);
      if (!cancelled) setData(summarize(sessions));
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  if (!data) return null;

  const { window, statusOf, streak, longest, doneCount, weekdayCounts } = data;
  const maxWeekday = Math.max(1, ...weekdayCounts);

  return (
    <div className="sticker rounded-3xl bg-card p-5">
      <div className="flex items-center gap-2">
        <Flame className="h-5 w-5 text-primary" aria-hidden="true" />
        <h2 className="font-heading text-lg text-foreground">Last 30 days</h2>
      </div>

      <div className="mt-3 grid grid-cols-3 gap-3 text-center">
        <div>
          <p className="font-heading text-2xl text-foreground">{streak}</p>
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Day streak</p>
        </div>
        <div>
          <p className="font-heading text-2xl text-foreground">{doneCount}<span className="text-sm text-muted-foreground"> / {DAYS}</span></p>
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Sessions done</p>
        </div>
        <div>
          <p className="font-heading text-2xl text-foreground">{longest}</p>
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Best streak</p>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-10 gap-1.5" role="img" aria-label="Workout consistency over the last 30 days">
        {window.map(({ str, date }) => {
          const status = statusOf(str) || 'none';
          return (
            <div
              key={str}
              title={`${date.toLocaleDateString([], { month: 'short', day: 'numeric' })} — ${STATUS_LABELS[status]}`}
              className={`h-6 rounded-md border-2 ${CELL_STYLES[status]} ${status === 'none' ? 'border-sage/20' : 'border-sage'}`}
            />
          );
        })}
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
        <span className="inline-flex items-center gap-1.5"><span className="h-3 w-3 rounded-sm border-2 border-sage bg-primary" /> Done</span>
        <span className="inline-flex items-center gap-1.5"><span className="h-3 w-3 rounded-sm border-2 border-sage bg-secondary" /> Partial</span>
        <span className="inline-flex items-center gap-1.5"><span className="h-3 w-3 rounded-sm border-2 border-sage bg-accent" /> Skipped or deferred</span>
        <span className="inline-flex items-center gap-1.5"><span className="h-3 w-3 rounded-sm border-2 border-sage/20 bg-card" /> Rest day</span>
      </div>

      <div className="mt-4 border-t-2 border-sage/10 pt-4">
        <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Sessions by weekday</p>
        <div className="mt-2 flex items-end justify-between gap-2">
          {[1, 2, 3, 4, 5, 6, 0].map((day) => (
            <div key={day} className="flex flex-1 flex-col items-center gap-1">
              <div className="flex h-14 w-full items-end">
                <div
                  className="w-full rounded-t-sm bg-primary"
                  style={{ height: `${Math.round((weekdayCounts[day] / maxWeekday) * 100)}%` }}
                />
              </div>
              <span className="text-xs font-semibold text-muted-foreground">{WEEKDAYS[[1, 2, 3, 4, 5, 6, 0].indexOf(day)]}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}