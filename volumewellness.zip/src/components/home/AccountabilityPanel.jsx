import React, { useEffect, useState } from 'react';
import { ClipboardCheck } from 'lucide-react';
import { loadCommitments, answerCommitment, OUTCOME_REASONS, dueLabel, commitmentDueMs } from '@/lib/commitments';

// Accountability on the home screen: upcoming promises the user made,
// past-due ones that need an answer, and their follow-through tally.
export default function AccountabilityPanel({ refreshKey }) {
  const [items, setItems] = useState(null);

  const load = async () => {
    setItems(null);
    const list = await loadCommitments().catch(() => []);
    const now = Date.now();
    const pending = list.filter((c) => c.status === 'pending');
    const resolved = list.filter((c) => c.status !== 'pending');
    setItems({
      overdue: pending.filter((c) => commitmentDueMs(c) <= now).slice(0, 3),
      upcoming: pending.filter((c) => commitmentDueMs(c) > now).slice(0, 2),
      kept: resolved.filter((c) => c.status === 'kept').length,
      missed: resolved.filter((c) => c.status === 'missed').length,
    });
  };

  useEffect(() => {
    load();
  }, [refreshKey]);

  if (!items) return null;

  const { overdue, upcoming, kept, missed } = items;
  // Only surface this when there is an active promise — nothing pending, no panel.
  if (overdue.length === 0 && upcoming.length === 0) return null;
  const total = kept + missed;

  const answer = async (id, reason) => {
    await answerCommitment(id, reason).catch(() => null);
    await load();
  };

  return (
    <div className="sticker rounded-3xl bg-card p-5">
      <div className="flex items-center gap-2">
        <ClipboardCheck className="h-5 w-5 text-primary" />
        <h2 className="font-heading text-lg text-foreground">What you said you&apos;d do</h2>
      </div>

      {overdue.map((c) => (
        <div key={c.id} className="mt-4 rounded-2xl bg-accent p-4">
          <p className="text-sm font-bold text-foreground">
            You had {c.label} penciled in for {dueLabel(c)}.
          </p>
          <p className="mt-1 text-sm text-muted-foreground">Life happens. What got in the way?</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {OUTCOME_REASONS.map(({ value, label }) => (
              <button
                key={value}
                type="button"
                onClick={() => answer(c.id, value)}
                className="rounded-full border-2 border-sage bg-card px-3 py-1.5 text-xs font-semibold text-foreground hover:bg-secondary/60"
              >
                {label}
              </button>
            ))}
          </div>
        </div>
      ))}

      {upcoming.map((c) => (
        <p key={c.id} className="mt-3 text-sm text-foreground">
          <span className="font-bold">{c.label}</span> — penciled in for {dueLabel(c)}.
        </p>
      ))}

      {total > 0 && (
        <p className="mt-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          Follow-through so far: {kept} of {total} kept
        </p>
      )}
    </div>
  );
}