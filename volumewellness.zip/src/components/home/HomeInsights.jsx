import React, { useEffect, useState } from 'react';
import { Bookmark } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import InsightActionButton from '@/components/insights/InsightActionButton';
import GeneralInsightCard from '@/components/insights/GeneralInsightCard';
import { GENERAL_INSIGHTS } from '@/lib/general-insights';
import { CATEGORY_LABELS, MOOD_STYLES, categoryCardStyle, categoryChipStyle, categoryIcon } from '@/lib/insight-visual';

function groupRank(insight) {
  if (insight.status === 'new') return 0;
  if (insight.status === 'saved') return 1;
  if (insight.user_rating === 'helpful') return 2;
  return -1; // everything else stays off the home screen
}

function orderInsights(list) {
  return list
    .filter((i) => i.status !== 'dismissed' && groupRank(i) >= 0)
    .sort((a, b) => groupRank(a) - groupRank(b) || new Date(b.created_date) - new Date(a.created_date));
}

// Home insights section: new insights first, then saved, then thumbed-up.
export default function HomeInsights() {
  const [insights, setInsights] = useState(null);

  useEffect(() => {
    let cancelled = false;
    base44.entities.Insight.list('-created_date', 50)
      .then((list) => {
        if (!cancelled) setInsights(orderInsights(list));
      })
      .catch(() => {
        if (!cancelled) setInsights([]);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (!insights) return null;

  // Waiting period: no personal insights yet, so the general starting points
  // stand in. They step aside as soon as real patterns exist.
  if (insights.length === 0) {
    return (
      <div className="space-y-3">
        {GENERAL_INSIGHTS.slice(0, 2).map((tip) => (
          <GeneralInsightCard key={tip.title} tip={tip} variant="soft" />
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {insights.slice(0, 2).map((insight) => {
        const Icon = categoryIcon(insight.category);
        return (
          <div
            key={insight.id}
            className="relative overflow-hidden rounded-3xl p-5"
            style={{
              ...categoryCardStyle(insight.category),
              ...(insight.user_rating ? MOOD_STYLES[insight.user_rating] : undefined),
            }}
          >
            <div className="flex items-center justify-between gap-2">
              <span
                className="inline-flex items-center gap-1.5 rounded-full border border-sage/20 px-2.5 py-0.5 text-xs font-medium"
                style={categoryChipStyle(insight.category)}
              >
                <Icon className="h-3.5 w-3.5" />
                {CATEGORY_LABELS[insight.category] || insight.category}
              </span>
              <span className="flex items-center gap-1.5">
                {insight.status === 'new' && (
                  <span className="rounded-full bg-primary px-2.5 py-0.5 text-xs font-bold uppercase tracking-wide text-primary-foreground">
                    New
                  </span>
                )}
                {insight.status === 'saved' && (
                  <span className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-bold text-primary">
                    <Bookmark className="h-3 w-3" /> Saved
                  </span>
                )}
              </span>
            </div>
            <p className="mt-2 text-sm font-bold text-foreground">{insight.title}</p>
            <p className="mt-1 text-sm text-foreground/80">{insight.body}</p>
            <div className="mt-4">
              <InsightActionButton insight={insight} variant="soft" />
            </div>
          </div>
        );
      })}
    </div>
  );
}