import React, { useEffect, useState } from 'react';
import { Flame } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { localTodayStr } from '@/lib/volume';

function countStreak(dates) {
  const has = new Set(dates);
  const cursor = new Date();
  // If today isn't checked in yet, the streak still counts up to yesterday
  if (!has.has(localTodayStr(cursor))) cursor.setDate(cursor.getDate() - 1);
  let count = 0;
  while (has.has(localTodayStr(cursor))) {
    count += 1;
    cursor.setDate(cursor.getDate() - 1);
  }
  return count;
}

// Compact streak readout for the home header: icon plus plain text, no pill.
export default function StreakBadge() {
  const [streak, setStreak] = useState(null); // null = loading

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const list = await base44.entities.DailyAssessment.list('-created_date', 120);
        if (cancelled) return;
        setStreak(countStreak(list.map((a) => a.date)));
      } catch {
        if (!cancelled) setStreak(0);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  if (streak === null) return null;

  return (
    <span className="inline-flex items-center gap-1 text-xs font-bold uppercase tracking-wide text-foreground">
      <Flame className="h-3.5 w-3.5 text-primary" aria-hidden="true" />
      {streak} {streak === 1 ? 'day' : 'days'} in a row
    </span>
  );
}