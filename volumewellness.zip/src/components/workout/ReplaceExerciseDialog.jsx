import React, { useEffect, useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { BLOCK_FEEDBACK_REASONS } from '@/lib/blocks';

// Swap one exercise inside a warmup/cooldown for an alternative from another
// session. A reason is required — it is logged and the exercise is added to
// the user's avoid list so plans stop including it.
export default function ReplaceExerciseDialog({ open, kind, exercise, options, onClose, onConfirm }) {
  const [choice, setChoice] = useState(null);
  const [reason, setReason] = useState(null);

  useEffect(() => {
    if (open) {
      setChoice(null);
      setReason(null);
    }
  }, [open]);

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Replace “{exercise ? exercise.name : ''}”</DialogTitle>
          <DialogDescription>Swap in something that works better — it applies to this {kind} right away.</DialogDescription>
        </DialogHeader>

        <div>
          <p className="text-xs font-bold uppercase tracking-wide text-muted-foreground">Swap for</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {options.map((name) => (
              <button
                key={name}
                type="button"
                onClick={() => setChoice(name)}
                className={`rounded-full border-2 px-3 py-1.5 text-xs font-semibold ${
                  choice === name ? 'border-primary bg-primary text-primary-foreground' : 'border-sage text-foreground'
                }`}
              >
                {name}
              </button>
            ))}
          </div>
        </div>

        <div>
          <p className="text-xs font-bold uppercase tracking-wide text-muted-foreground">What didn&apos;t work?</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {BLOCK_FEEDBACK_REASONS.map(({ value, label }) => (
              <button
                key={value}
                type="button"
                onClick={() => setReason(value)}
                className={`rounded-full border-2 px-3 py-1.5 text-xs font-semibold ${
                  reason === value ? 'border-primary bg-primary text-primary-foreground' : 'border-sage text-foreground'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Keep it</Button>
          <Button disabled={!choice || !reason} onClick={() => onConfirm(choice, reason)}>
            Swap it out
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}