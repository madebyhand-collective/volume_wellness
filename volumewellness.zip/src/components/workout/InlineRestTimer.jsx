import React, { useEffect, useState } from 'react';

// "90s", "2m", "20 min" → seconds. Defaults to a 90-second rest when unknown.
export function parseRestSecs(rest) {
  const m = /^(\d+)\s*(s|sec|seconds|m|min|minutes)?/i.exec((rest || '').trim());
  if (!m) return 90;
  const n = parseInt(m[1], 10);
  return /^m/i.test(m[2] || '') ? n * 60 : n;
}

// Compact rest countdown that lives inside an exercise card. Bumping `runKey`
// restarts the countdown automatically (auto-continue); otherwise the user
// starts it with one tap.
export default function InlineRestTimer({ restSecs, runKey }) {
  const [remaining, setRemaining] = useState(0);
  const [total, setTotal] = useState(0);
  const [running, setRunning] = useState(false);

  useEffect(() => {
    if (!runKey || !restSecs) return;
    setTotal(restSecs);
    setRemaining(restSecs);
    setRunning(true);
  }, [runKey]);

  useEffect(() => {
    if (!running) return undefined;
    const id = setInterval(() => {
      setRemaining((r) => {
        if (r <= 1) {
          clearInterval(id);
          setRunning(false);
          return 0;
        }
        return r - 1;
      });
    }, 1000);
    return () => clearInterval(id);
  }, [running]);

  const start = (secs) => {
    setTotal(secs);
    setRemaining(secs);
    setRunning(true);
  };

  const mm = String(Math.floor(remaining / 60)).padStart(2, '0');
  const ss = String(remaining % 60).padStart(2, '0');
  const finished = !running && total > 0 && remaining === 0;

  return (
    <div className="flex items-center gap-2">
      <div className="relative h-8 w-8">
        <svg viewBox="0 0 36 36" className="h-8 w-8 -rotate-90">
          <circle cx="18" cy="18" r="15" fill="none" stroke="#fee3c5" strokeWidth="4" />
          {total > 0 && (
            <circle
              cx="18" cy="18" r="15" fill="none" stroke="#f06427" strokeWidth="4" strokeLinecap="round"
              strokeDasharray={2 * Math.PI * 15}
              strokeDashoffset={2 * Math.PI * 15 * (1 - remaining / total)}
            />
          )}
        </svg>
      </div>
      {finished ? (
        <span className="text-sm font-bold text-primary">Go</span>
      ) : (
        <span className="font-mono text-sm tabular-nums text-foreground">{mm}:{ss}</span>
      )}
      {running ? (
        <button
          type="button"
          onClick={() => setRunning(false)}
          className="rounded-full border border-border px-2.5 py-1 text-xs font-medium text-muted-foreground hover:bg-secondary"
        >
          Stop
        </button>
      ) : (
        <div className="flex gap-1.5">
          {remaining > 0 && (
            <button
              type="button"
              onClick={() => setRunning(true)}
              className="rounded-full border border-border px-2.5 py-1 text-xs font-medium text-muted-foreground hover:bg-secondary"
            >
              Resume
            </button>
          )}
          {(restSecs ? [{ label: `${restSecs}s`, secs: restSecs }, { label: '2m', secs: 120 }] : [{ label: '60s', secs: 60 }, { label: '2m', secs: 120 }]).map(({ label, secs }) => (
            <button
              key={label}
              type="button"
              onClick={() => start(secs)}
              className="rounded-full border border-border px-2.5 py-1 text-xs font-medium text-foreground hover:bg-secondary"
            >
              {label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}