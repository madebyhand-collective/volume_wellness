import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { SKIP_REASONS } from '@/lib/volume';

export default function SkipDialog({ open, onChoose, onClose }) {
  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Mind telling us why?</DialogTitle>
        </DialogHeader>
        <p className="-mt-2 text-sm text-muted-foreground">No judgment — this is how Volume learns your patterns.</p>
        <div className="grid grid-cols-2 gap-2">
          {SKIP_REASONS.map((r) => (
            <button
              key={r.value}
              type="button"
              onClick={() => onChoose(r.value)}
              className="rounded-2xl border border-border bg-card px-3 py-3 text-left text-sm font-medium text-foreground hover:bg-secondary"
            >
              {r.label}
            </button>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}