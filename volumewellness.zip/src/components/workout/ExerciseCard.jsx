import React, { useEffect, useState } from 'react';
import { Check, ChevronDown, ChevronUp, Video } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import SetLogger from './SetLogger';
import InlineRestTimer, { parseRestSecs } from './InlineRestTimer';

export default function ExerciseCard({ exercise, setCount, modifier, history, state, onChange, expanded, onToggleExpand, onAutoNext }) {
  const [auto, setAuto] = useState(true);
  const [timerKey, setTimerKey] = useState(0);
  const restSecs = parseRestSecs(exercise.rest);
  const last = history && history[0];

  // Optimistic checkmark: reflect the tap instantly, then reconcile with the
  // parent's saved state once it arrives.
  const [override, setOverride] = useState(null);
  useEffect(() => {
    setOverride(null);
  }, [state]);
  const done = override ? override.done : state.done;

  // With auto-continue on, finishing a set kick-starts the rest countdown,
  // and finishing the last set marks the exercise done and moves to the next.
  const handleSetsChange = (sets) => {
    const before = (state.sets || []).filter((s) => s.completed).length;
    const after = sets.filter((s) => s.completed).length;
    if (auto && after > before) {
      if (sets.every((s) => s.completed)) {
        setOverride({ done: true });
        onChange({ sets, done: true });
        onAutoNext && onAutoNext();
        return;
      }
      if (restSecs > 0) setTimerKey((k) => k + 1);
    }
    onChange({ sets });
  };

  return (
    <div className={`rounded-2xl border bg-card p-4 transition-colors ${state.done ? 'border-primary/40' : 'border-border'}`}>
      <div className="flex items-center gap-3">
        <button
          type="button"
          aria-label={done ? 'Mark incomplete' : 'Mark complete'}
          onClick={() => {
            const next = !done;
            setOverride({ done: next });
            onChange({ done: next });
          }}
          className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full border-2 transition-colors ${
            done ? 'border-primary bg-primary text-primary-foreground' : 'border-border text-transparent hover:border-primary'
          }`}
        >
          <Check className="h-4 w-4" />
        </button>
        <button type="button" onClick={onToggleExpand} className="min-w-0 flex-1 text-left">
          <div className="truncate font-medium text-foreground">{exercise.name}</div>
          <div className="text-sm text-muted-foreground">
            {setCount} sets × {exercise.reps}
            {exercise.rest && <span className="ml-1">· rest {exercise.rest}</span>}
            {modifier !== 0 && (
              <span className="ml-1 font-medium text-primary">({modifier > 0 ? '+1 set' : '−1 set'} today)</span>
            )}
          </div>
        </button>
        {/^https?:\/\//i.test(exercise.video_url || '') && (
          <a href={exercise.video_url} target="_blank" rel="noreferrer" className="shrink-0 rounded-full p-1.5 text-muted-foreground hover:bg-secondary" aria-label="Watch demo">
            <Video className="h-4 w-4" />
          </a>
        )}
        <button type="button" onClick={onToggleExpand} className="shrink-0 rounded-full p-1.5 text-muted-foreground hover:bg-secondary" aria-label="Expand">
          {expanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
        </button>
      </div>

      {expanded && (
        <div className="mt-4 space-y-3 border-t border-border pt-3">
          {last && last.sets && last.sets.length > 0 && (
            <div className="rounded-xl bg-secondary px-3 py-2 text-xs text-secondary-foreground">
              Last time: {last.sets.map((s) => `${s.weight ? `${s.weight} × ` : ''}${s.reps}`).join(', ')}
              {last.note ? ` — "${last.note}"` : ''}
            </div>
          )}
          <SetLogger sets={state.sets} onChange={handleSetsChange} />
          <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-secondary/40 px-3 py-2">
            <InlineRestTimer restSecs={restSecs} runKey={timerKey} />
            <label className="flex items-center gap-2 text-xs font-semibold text-muted-foreground" htmlFor={`auto-continue-${exercise.id}`}>
              Auto-continue
              <Switch id={`auto-continue-${exercise.id}`} checked={auto} onCheckedChange={setAuto} />
            </label>
          </div>
          <Textarea
            placeholder="Note (optional)"
            value={state.note}
            onChange={(e) => onChange({ note: e.target.value })}
            rows={1}
            className="text-sm"
          />
          {state.skipped ? (
            <button
              type="button"
              onClick={() => onChange({ skipped: false })}
              className="text-xs font-medium text-primary underline"
            >
              Undo skip
            </button>
          ) : (
            <button
              type="button"
              onClick={() => onChange({ skipped: true, done: false })}
              className="text-xs font-medium text-muted-foreground underline hover:text-foreground"
            >
              Skip this exercise
            </button>
          )}
        </div>
      )}

      {state.skipped && !expanded && (
        <div className="mt-2 text-xs text-muted-foreground">Skipped</div>
      )}
    </div>
  );
}