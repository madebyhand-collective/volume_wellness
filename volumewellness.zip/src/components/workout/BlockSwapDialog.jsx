import React, { useEffect, useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { BLOCK_FEEDBACK_REASONS } from '@/lib/blocks';

// Choose a different warmup/cooldown/mobility session and say why — the reason
// is required so future recommendations can adapt.
export default function BlockSwapDialog({ open, kind, alternatives, onClose, onConfirm }) {
  const [choice, setChoice] = useState(null);
  const [reason, setReason] = useState(null);

  useEffect(() => {
    if (open) {
      setChoice(null);
      setReason(null);
    }
  }, [open]);

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Change your {kind}</DialogTitle>
          <DialogDescription>Pick any {kind} or mobility session that fits better today.</DialogDescription>
        </DialogHeader>

        <div className="space-y-2">
          {alternatives.map((b) => (
            <button
              key={b.block_id}
              type="button"
              onClick={() => setChoice(b.block_id)}
              className={`w-full rounded-2xl border-2 px-4 py-3 text-left transition-colors ${
                choice === b.block_id ? 'border-primary bg-primary/10' : 'border-border hover:bg-secondary/50'
              }`}
            >
              <span className="block text-sm font-bold text-foreground">{b.name}</span>
              <span className="block text-xs text-muted-foreground">
                {b.duration_minutes} min · {b.intensity_level} intensity
                {(b.tags || []).length > 0 ? ` · ${b.tags.join(', ')}` : ''}
              </span>
            </button>
          ))}
        </div>

        <div>
          <p className="text-xs font-bold uppercase tracking-wide text-muted-foreground">Why the switch?</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {BLOCK_FEEDBACK_REASONS.map(({ value, label }) => (
              <button
                key={value}
                type="button"
                onClick={() => setReason(value)}
                className={`rounded-full border-2 px-3 py-1.5 text-xs font-semibold ${
                  reason === value ? 'border-primary bg-primary text-primary-foreground' : 'border-sage text-foreground'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Not now</Button>
          <Button
            disabled={!choice || !reason}
            onClick={() => onConfirm(alternatives.find((b) => b.block_id === choice), reason)}
          >
            Use this one
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}