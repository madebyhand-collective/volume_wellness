import React from 'react';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';

export default function SetLogger({ sets, onChange }) {
  const update = (i, patch) => onChange(sets.map((s, j) => (i === j ? { ...s, ...patch } : s)));

  return (
    <div>
      <div className="grid grid-cols-[32px_1fr_1fr_56px_32px] gap-2 px-1 text-[10px] uppercase tracking-wide text-muted-foreground">
        <span>Set</span>
        <span>Weight</span>
        <span>Reps</span>
        <span>RPE</span>
        <span className="text-center">✓</span>
      </div>
      <div className="mt-1 space-y-1.5">
        {sets.map((s, i) => (
          <div key={i} className="grid grid-cols-[32px_1fr_1fr_56px_32px] items-center gap-2">
            <span className="text-sm text-muted-foreground">{i + 1}</span>
            <Input
              type="number"
              inputMode="decimal"
              placeholder="0"
              value={s.weight}
              onChange={(e) => update(i, { weight: e.target.value })}
              className="h-9"
            />
            <Input
              placeholder="10"
              value={s.reps}
              onChange={(e) => update(i, { reps: e.target.value })}
              className="h-9"
            />
            <Input
              type="number"
              inputMode="numeric"
              placeholder="—"
              value={s.rpe}
              onChange={(e) => update(i, { rpe: e.target.value })}
              className="h-9"
            />
            <div className="flex justify-center">
              <Checkbox checked={!!s.completed} onCheckedChange={(c) => update(i, { completed: !!c })} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}