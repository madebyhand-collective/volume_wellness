import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { MOODS } from '@/lib/volume';

export default function FinishDialog({ open, saving, onDone, onClose }) {
  const [mood, setMood] = useState(null);
  const [note, setNote] = useState('');
  const [exertion, setExertion] = useState(6);

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>How do you feel now?</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-4 gap-2">
          {MOODS.map((m) => (
            <button
              key={m.value}
              type="button"
              onClick={() => setMood(m.value)}
              className={`rounded-2xl border px-2 py-3 text-center text-xs font-medium ${
                mood === m.value ? 'border-primary bg-primary text-primary-foreground' : 'border-border bg-card text-foreground hover:bg-secondary'
              }`}
            >
              {m.label}
            </button>
          ))}
        </div>
        <div>
          <div className="mb-1 flex items-center justify-between text-xs text-muted-foreground">
            <span>How hard was it?</span>
            <span className="font-medium text-foreground">RPE {exertion}/10</span>
          </div>
          <input
            type="range"
            min="1"
            max="10"
            value={exertion}
            onChange={(e) => setExertion(Number(e.target.value))}
            className="w-full accent-[#f06427]"
          />
        </div>
        <Textarea
          placeholder="Anything worth remembering about this session? (optional)"
          value={note}
          onChange={(e) => setNote(e.target.value)}
          rows={2}
        />
        <button
          type="button"
          disabled={!mood || saving}
          onClick={() => onDone({ mood, note, exertion })}
          className="w-full rounded-full bg-primary py-3 font-medium text-primary-foreground disabled:opacity-40"
        >
          Finish session
        </button>
      </DialogContent>
    </Dialog>
  );
}