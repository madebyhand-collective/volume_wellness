import React, { useMemo, useState } from 'react';
import { Check, Flame, RefreshCw, Snowflake } from 'lucide-react';
import BlockSwapDialog from './BlockSwapDialog';
import ReplaceExerciseDialog from './ReplaceExerciseDialog';
import InlineRestTimer, { parseRestSecs } from './InlineRestTimer';

// Warmup / cooldown card with feedback built in: swap the whole session for
// another one, or replace a single exercise — every choice captures a reason.
// Warmups are color-coded sunset; cooldowns are olive.
export default function SessionBlockCard({ kind, block, alternatives, state, onDone, onSkip, onSwapBlock, onReplaceExercise }) {
  const [swapOpen, setSwapOpen] = useState(false);
  const [replaceTarget, setReplaceTarget] = useState(null);
  const isWarmup = kind === 'warmup';

  const replacementOptions = useMemo(() => {
    const current = new Set((block && block.exercises || []).map((e) => e.name));
    const names = [];
    alternatives.forEach((b) =>
      (b.exercises || []).forEach((e) => {
        if (e.name && !current.has(e.name) && !names.includes(e.name)) names.push(e.name);
      })
    );
    return names;
  }, [block, alternatives]);

  return (
    <div className={`rounded-3xl border-2 bg-card p-5 ${isWarmup ? 'border-sunset' : 'border-secondary'}`}>
      <div className="mb-3 flex items-center justify-between">
        <div>
          <h3 className="font-heading text-lg text-foreground">
            {isWarmup ? <Flame className="mr-1 inline h-4 w-4 text-sunset" /> : <Snowflake className="mr-1 inline h-4 w-4 text-secondary" />}
            {isWarmup ? 'Warmup' : 'Cooldown'} — {block ? block.name : 'General'}
          </h3>
          {block &&
          <p className="text-xs text-muted-foreground">
              {block.duration_minutes} min · {block.intensity_level} intensity
            </p>
          }
        </div>
        {state.done ?
        <span className={`inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs font-medium ${isWarmup ? 'bg-sunset/10 text-sunset' : 'bg-secondary/10 text-secondary'}`}>
            <Check className="h-3.5 w-3.5" /> Done
          </span> :
        state.skipped ?
        <span className="rounded-full bg-accent px-3 py-1 text-xs font-medium text-accent-foreground">Skipped</span> :

        <div className="flex gap-2">
            <button type="button" onClick={onDone} className="rounded-full border border-border px-3 py-1.5 text-xs font-medium text-foreground hover:bg-secondary">
              Done
            </button>
            <button type="button" onClick={onSkip} className="rounded-full border border-border px-3 py-1.5 text-xs font-medium text-muted-foreground hover:bg-secondary">
              Skip
            </button>
          </div>
        }
      </div>

      {block && !state.skipped &&
      <ul className="space-y-1.5 text-sm text-foreground">
          {(block.exercises || []).map((ex) =>
        <li key={ex.order} className={`rounded-xl px-3 py-2 ${isWarmup ? 'bg-sunset/[0.04]' : 'bg-secondary/[0.04]'}`}>
              <div className="flex items-baseline justify-between gap-2">
                <span>{ex.name}</span>
                <span className="flex shrink-0 items-center gap-1 text-xs text-muted-foreground">
                  {ex.duration}
                  {!state.done && replacementOptions.length > 0 &&
              <button
                type="button"
                onClick={() => setReplaceTarget(ex)}
                aria-label={`Replace ${ex.name}`}
                className="rounded-full p-1 hover:bg-secondary hover:text-foreground">

                    <RefreshCw className="h-3.5 w-3.5" />
                  </button>
              }
                </span>
              </div>
              {!state.done && !state.skipped &&
          <div className="mt-1.5">
                  <InlineRestTimer restSecs={parseRestSecs(ex.duration)} />
                </div>
          }
            </li>
        )}
        </ul>
      }

      {!state.done && !state.skipped && alternatives.length > 0 &&
      <button
        type="button"
        onClick={() => setSwapOpen(true)}
        className="mt-3 text-xs font-semibold text-primary underline underline-offset-4">

        Try a different {kind}
      </button>
      }

      <BlockSwapDialog
        open={swapOpen}
        kind={kind}
        alternatives={alternatives}
        onClose={() => setSwapOpen(false)}
        onConfirm={(b, reason) => {
          setSwapOpen(false);
          onSwapBlock(b, reason);
        }} />

      <ReplaceExerciseDialog
        open={!!replaceTarget}
        kind={kind}
        exercise={replaceTarget}
        options={replacementOptions}
        onClose={() => setReplaceTarget(null)}
        onConfirm={(name, reason) => {
          const ex = replaceTarget;
          setReplaceTarget(null);
          onReplaceExercise(ex, name, reason);
        }} />

    </div>);
}