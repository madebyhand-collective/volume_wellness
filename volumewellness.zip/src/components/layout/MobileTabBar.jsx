import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import {
  Home,
  Dumbbell,
  Library,
  Lightbulb,
  MoreHorizontal,
  ClipboardCheck,
  NotebookPen,
  PersonStanding,
  Settings,
} from 'lucide-react';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';

const TABS = [
  { to: '/', label: 'Today', icon: Home },
  { to: '/workout', label: 'Workout', icon: Dumbbell },
  { to: '/plans', label: 'Plans', icon: Library },
  { to: '/insights', label: 'Insights', icon: Lightbulb },
];

const MORE_LINKS = [
  { to: '/accountability', label: 'Promises', icon: ClipboardCheck },
  { to: '/reflection', label: 'Reflect', icon: NotebookPen },
  { to: '/library', label: 'Movement', icon: PersonStanding },
  { to: '/preferences', label: 'Settings', icon: Settings },
];

// Sticky bottom tab bar for mobile (< 768px). Desktop keeps the header nav.
export default function MobileTabBar() {
  const [moreOpen, setMoreOpen] = useState(false);

  return (
    <>
      <nav
        aria-label="Mobile navigation"
        className="safe-bottom fixed inset-x-0 bottom-0 z-40 bg-background/70 backdrop-blur-md md:hidden"
      >
        <div className="mx-auto grid max-w-4xl grid-cols-5">
          {TABS.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              end={to === '/'}
              onClick={() => {
                const active = to === '/' ? window.location.pathname === '/' : window.location.pathname.startsWith(to);
                if (active) window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className={({ isActive }) =>
                `flex flex-col items-center gap-1 py-2 text-[11px] font-medium ${
                  isActive ? 'text-primary' : 'text-muted-foreground'
                }`
              }
            >
              <Icon className="h-5 w-5" />
              {label}
            </NavLink>
          ))}
          <button
            type="button"
            onClick={() => setMoreOpen(true)}
            aria-label="More"
            aria-expanded={moreOpen}
            className="flex flex-col items-center gap-1 py-2 text-[11px] font-medium text-muted-foreground"
          >
            <MoreHorizontal className="h-5 w-5" />
            More
          </button>
        </div>
      </nav>

      <Sheet open={moreOpen} onOpenChange={setMoreOpen}>
        <SheetContent side="bottom" className="safe-bottom rounded-t-3xl">
          <SheetHeader>
            <SheetTitle className="text-left font-heading text-lg">More</SheetTitle>
          </SheetHeader>
          <div className="grid grid-cols-2 gap-3 pb-2">
            {MORE_LINKS.map(({ to, label, icon: Icon }) => (
              <NavLink
                key={to}
                to={to}
                onClick={() => setMoreOpen(false)}
                className={({ isActive }) =>
                  `flex items-center gap-2 rounded-2xl border border-border px-4 py-3 text-sm font-semibold ${
                    isActive ? 'bg-primary text-primary-foreground' : 'bg-card text-foreground'
                  }`
                }
              >
                <Icon className="h-4 w-4" />
                {label}
              </NavLink>
            ))}
          </div>
        </SheetContent>
      </Sheet>
    </>
  );
}