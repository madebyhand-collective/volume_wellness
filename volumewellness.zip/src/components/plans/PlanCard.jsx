import React from 'react';

const TAG_CLASSES = 'rounded-full bg-secondary px-2.5 py-0.5 text-xs text-secondary-foreground';

export default function PlanCard({ plan, inMyPlans, isActive, onSetActive, onAdd, onPreview }) {
  return (
    <div className={`rounded-3xl border bg-card p-5 ${isActive ? 'border-primary' : 'border-border'}`}>
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="font-heading text-lg text-foreground">{plan.name}</h3>
          <p className="mt-1 text-sm text-muted-foreground">{plan.description}</p>
        </div>
        <div className="flex shrink-0 flex-col items-end gap-1">
          <span className="rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-medium text-primary">
            {plan.access === 'free' ? 'Free' : 'Member'}
          </span>
          {isActive && <span className="text-xs font-medium text-primary">Active plan</span>}
        </div>
      </div>
      <div className="mt-3 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
        <span className={TAG_CLASSES}>{plan.difficulty}</span>
        <span className={TAG_CLASSES}>{plan.duration}</span>
        <span className={TAG_CLASSES}>{plan.days_per_week} days/week</span>
        {(plan.tags || []).map((t) => (
          <span key={t} className={TAG_CLASSES}>{t}</span>
        ))}
      </div>
      <div className="mt-4 flex gap-2">
        {onPreview && (
          <button
            type="button"
            onClick={onPreview}
            className="rounded-full border-2 border-sage bg-card px-4 py-2 text-sm font-bold text-foreground hover:bg-secondary/30"
          >
            Preview
          </button>
        )}
        {!isActive && (
          <button
            type="button"
            onClick={onSetActive}
            className="rounded-full bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
          >
            Set as my plan
          </button>
        )}
        {!inMyPlans && (
          <button
            type="button"
            onClick={onAdd}
            className="rounded-full border border-border px-4 py-2 text-sm font-medium text-foreground hover:bg-secondary"
          >
            Save to my plans
          </button>
        )}
      </div>
    </div>
  );
}