import React from 'react';

// Plain-language summary of the user's current plan, shown above the tabs on
// the Plans page. Tapping it opens the full workout-by-workout preview.
export default function ActivePlanCard({ plan, onOpen }) {
  if (!plan) return null;

  const exerciseTags = (plan.tags || []).filter((t) => t !== 'AI plan');

  return (
    <button
      type="button"
      onClick={onOpen}
      className="sticker w-full rounded-3xl border-2 border-sage bg-card p-5 text-left"
    >
      <span className="inline-block rounded-full bg-bloom px-3 py-1 text-xs font-bold uppercase tracking-wide text-foreground">
        Your current plan
      </span>
      <h2 className="mt-2 font-heading text-2xl text-foreground">{plan.name}</h2>
      {plan.description && <p className="mt-1 text-sm text-muted-foreground">{plan.description}</p>}

      <div className="mt-3 flex flex-wrap gap-2 text-xs font-semibold">
        <span className="rounded-full bg-sun px-3 py-1.5 text-foreground">{plan.difficulty}</span>
        <span className="rounded-full bg-sun px-3 py-1.5 text-foreground">{plan.duration}</span>
        <span className="rounded-full bg-sun px-3 py-1.5 text-foreground">{plan.days_per_week} days a week</span>
        {exerciseTags.map((t) => (
          <span key={t} className="rounded-full bg-bloom px-3 py-1.5 text-foreground">{t}</span>
        ))}
      </div>

      {plan.why_it_matters && (
        <p className="mt-4 border-t border-sage/40 pt-3 text-sm text-foreground">
          <span className="font-bold">Why showing up for this matters:</span> {plan.why_it_matters}
        </p>
      )}

      <p className="mt-3 text-xs font-semibold text-muted-foreground">Tap to preview every workout</p>
    </button>
  );
}