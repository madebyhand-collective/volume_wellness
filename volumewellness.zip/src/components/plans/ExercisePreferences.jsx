import React, { useEffect, useState } from 'react';
import { Loader2, Save } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { getPreferences, invalidateVolumeCache } from '@/lib/volume';

const COMMON_EXERCISES = [
  'Burpees', 'Jump squats', 'Jumping lunges', 'Box jumps',
  'Mountain climbers', 'High knees', 'Jumping jacks', 'Jump rope',
  'Sprints', 'Running', 'Planks', 'Sit-ups',
  'Push-ups', 'Pull-ups', 'Dips', 'Pistol squats',
  'Kettlebell swings', 'Deadlifts', 'Barbell squats', 'Overhead press',
  'Lunges', 'Russian twists', 'Battle ropes', 'Wall sits',
];

// Exercises the user would rather avoid. Saved with their preferences and
// always respected when the coach builds a plan.
export default function ExercisePreferences() {
  const [loading, setLoading] = useState(true);
  const [prefId, setPrefId] = useState(null);
  const [excluded, setExcluded] = useState([]);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const prefs = await getPreferences();
      if (cancelled) return;
      if (prefs) {
        setPrefId(prefs.id);
        setExcluded(prefs.excluded_exercises || []);
      }
      setLoading(false);
    })();
    return () => { cancelled = true; };
  }, []);

  const toggle = (name) => {
    setExcluded((list) => (list.includes(name) ? list.filter((x) => x !== name) : [...list, name]));
    setSaved(false);
  };

  const save = async () => {
    setSaving(true);
    try {
      if (prefId) {
        await base44.entities.Preferences.update(prefId, { excluded_exercises: excluded });
      } else {
        const created = await base44.entities.Preferences.create({ excluded_exercises: excluded });
        setPrefId(created.id);
      }
      invalidateVolumeCache();
      setSaved(true);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-10">
        <div className="h-6 w-6 animate-spin rounded-full border-4 border-secondary border-t-primary" />
      </div>
    );
  }

  return (
    <div className="sticker rounded-3xl border-2 border-sage bg-card p-5">
      <h2 className="font-heading text-xl text-foreground">Exercises to avoid</h2>
      <p className="mt-1 text-sm text-muted-foreground">
        Tap anything you&apos;d rather skip. Your coach builds every plan around this list — no exceptions.
      </p>

      <div className="mt-4 flex flex-wrap gap-2">
        {COMMON_EXERCISES.map((name) => {
          const selected = excluded.includes(name);
          return (
            <button
              key={name}
              type="button"
              onClick={() => toggle(name)}
              className={`rounded-full border-2 px-4 py-2 text-sm font-semibold transition-all ${
                selected
                  ? 'border-primary bg-primary text-primary-foreground'
                  : 'border-sage bg-card text-foreground hover:bg-secondary/30'
              }`}
            >
              {name}
            </button>
          );
        })}
      </div>

      <div className="mt-5 flex flex-wrap items-center gap-3">
        <button
          type="button"
          disabled={saving}
          onClick={save}
          className="inline-flex items-center gap-2 rounded-full bg-foreground px-6 py-3 text-sm font-bold text-primary-foreground disabled:opacity-40"
        >
          {saving && <Loader2 className="h-4 w-4 animate-spin" />}
          {!saving && <Save className="h-4 w-4" />}
          Save
        </button>
        <span className="text-sm font-semibold text-muted-foreground">
          {saved ? 'Saved — your coach knows.' : `${excluded.length} on the avoid list`}
        </span>
      </div>
    </div>
  );
}