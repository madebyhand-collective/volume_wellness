import React, { useEffect, useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { localTodayStr } from '@/lib/volume';
import CalendarMonth, { MARKERS } from './CalendarMonth';

const dateStr = (d) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

const STATUS_RANK = { completed: 3, partial: 2, deferred: 1, skipped: 1, abandoned: 1 };

const LEGEND = [
  { key: 'completed', label: 'Completed' },
  { key: 'partial', label: 'Partially done' },
  { key: 'deferred', label: 'Skipped or deferred' },
  { key: 'upcoming', label: 'Upcoming training day' },
];

// Monthly calendar on the Plans page: recorded sessions land on their dates,
// and the remaining sessions of the active plan slide onto the next available
// days — so a missed day just shifts the path forward, never drops a workout.
export default function TrainingCalendar({ profile }) {
  const [month, setMonth] = useState(() => {
    const n = new Date();
    return new Date(n.getFullYear(), n.getMonth(), 1);
  });
  const [loading, setLoading] = useState(true);
  const [sessions, setSessions] = useState([]);
  const [planDays, setPlanDays] = useState([]);

  const activeId = profile && profile.active_plan_id;

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    (async () => {
      try {
        const list = await base44.entities.WorkoutSession.list('-created_date', 200);
        if (cancelled) return;
        setSessions(list);
        const days = activeId ? await base44.entities.PlanDay.filter({ plan_id: activeId }) : [];
        if (cancelled) return;
        setPlanDays(days);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [activeId]);

  // Best session marker per date (a completed session outranks a skipped one).
  const sessionsByDate = useMemo(() => {
    const map = new Map();
    sessions.forEach((s) => {
      if (!s.date) return;
      const rank = STATUS_RANK[s.status] || 1;
      const prev = map.get(s.date);
      if (!prev || rank > prev.rank) map.set(s.date, { status: s.status, rank });
    });
    const statusMap = new Map();
    map.forEach((v, k) => statusMap.set(k, v.status));
    return statusMap;
  }, [sessions]);

  // Remaining plan sessions, laid on consecutive free days starting today.
  const upcomingByDate = useMemo(() => {
    const map = new Map();
    if (!profile || !activeId || planDays.length === 0) return map;
    const curWeek = profile.current_week ?? 1;
    const curIdx = profile.day_index ?? 0;
    const remaining = planDays
      .filter((d) => d.week_number > curWeek || (d.week_number === curWeek && (d.day_index ?? 0) >= curIdx))
      .sort((a, b) => a.week_number - b.week_number || (a.day_index ?? 0) - (b.day_index ?? 0));
    const endStr = dateStr(new Date(month.getFullYear(), month.getMonth() + 1, 0));
    let cursor = new Date(`${localTodayStr()}T12:00:00`);
    for (const day of remaining) {
      let cs = dateStr(cursor);
      while (cs <= endStr && sessionsByDate.has(cs)) {
        cursor.setDate(cursor.getDate() + 1);
        cs = dateStr(cursor);
      }
      if (cs > endStr) break;
      map.set(cs, day);
      cursor.setDate(cursor.getDate() + 1);
    }
    return map;
  }, [profile, activeId, planDays, month, sessionsByDate]);

  const shiftMonth = (delta) => setMonth((m) => new Date(m.getFullYear(), m.getMonth() + delta, 1));
  const monthLabel = month.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  return (
    <div className="sticker rounded-3xl bg-card p-5">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 className="font-heading text-xl text-foreground">Training calendar</h2>
          <p className="text-xs text-muted-foreground">
            Your plan slides to the next free day — nothing gets missed, you just pick back up.
          </p>
        </div>
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => shiftMonth(-1)}
            aria-label="Previous month"
            className="rounded-full p-2 text-foreground hover:bg-muted"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          <span className="min-w-36 text-center text-sm font-bold text-foreground">{monthLabel}</span>
          <button
            type="button"
            onClick={() => shiftMonth(1)}
            aria-label="Next month"
            className="rounded-full p-2 text-foreground hover:bg-muted"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-10">
          <div className="h-6 w-6 animate-spin rounded-full border-4 border-secondary border-t-primary" />
        </div>
      ) : sessions.length === 0 && upcomingByDate.size === 0 ? (
        <p className="py-6 text-center text-sm text-muted-foreground">
          Check in and finish a session — your training days will land here.
        </p>
      ) : (
        <div className="mt-4">
          <CalendarMonth
            month={month}
            todayStr={localTodayStr()}
            sessionsByDate={sessionsByDate}
            upcomingByDate={upcomingByDate}
          />
          <div className="mt-4 flex flex-wrap gap-x-5 gap-y-2">
            {LEGEND.map(({ key, label }) => (
              <span key={key} className="flex items-center gap-1.5 text-xs font-semibold text-muted-foreground">
                <span className={MARKERS[key].className} aria-hidden="true" />
                {label}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}