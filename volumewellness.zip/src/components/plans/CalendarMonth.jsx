import React from 'react';

const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

const MISSED_CLASS = 'h-1.5 w-1.5 rounded-full bg-[#5e5220] opacity-50';

export const MARKERS = {
  completed: { className: 'h-1.5 w-1.5 rounded-full bg-[#f06427]', label: 'Completed' },
  partial: { className: 'h-1.5 w-1.5 rounded-full border-2 border-[#f06427]', label: 'Partially done' },
  deferred: { className: MISSED_CLASS, label: 'Skipped or deferred' },
  skipped: { className: MISSED_CLASS, label: 'Skipped or deferred' },
  abandoned: { className: MISSED_CLASS, label: 'Skipped or deferred' },
  upcoming: { className: 'h-1.5 w-1.5 rounded-full border-2 border-dashed border-[#bda634]', label: 'Upcoming training day' },
};

// One month grid: day cells carry a marker dot for a recorded session or a
// planned (upcoming) training day.
export default function CalendarMonth({ month, todayStr, sessionsByDate, upcomingByDate }) {
  const year = month.getFullYear();
  const m = month.getMonth();
  const firstWeekday = new Date(year, m, 1).getDay();
  const daysInMonth = new Date(year, m + 1, 0).getDate();

  const cells = [];
  for (let i = 0; i < firstWeekday; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);

  const dateStr = (d) => `${year}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;

  return (
    <div>
      <div
        className="mb-2 grid grid-cols-7 gap-1 text-center text-[11px] font-bold uppercase tracking-wide text-[#5e5220]"
        aria-hidden="true"
      >
        {WEEKDAYS.map((w) => (
          <span key={w}>{w}</span>
        ))}
      </div>
      <div className="grid grid-cols-7 gap-1">
        {cells.map((d, i) => {
          if (d === null) return <div key={`blank-${i}`} aria-hidden="true" />;
          const ds = dateStr(d);
          const status = sessionsByDate.get(ds);
          const upcoming = !status && upcomingByDate.get(ds);
          const marker = (status && MARKERS[status]) || (upcoming && MARKERS.upcoming) || null;
          const isToday = ds === todayStr;
          return (
            <div
              key={ds}
              title={marker ? `${ds} — ${marker.label}${upcoming ? ` (${upcoming.label})` : ''}` : ds}
              className={`relative flex aspect-square items-start justify-center rounded-2xl pt-1 ${
                isToday ? 'ring-2 ring-inset ring-sage' : ''
              }`}
              style={marker ? { backgroundColor: 'rgba(254,227,197,0.25)' } : undefined}
            >
              <span className={`text-sm ${isToday ? 'font-bold text-foreground' : 'text-foreground/80'}`}>{d}</span>
              {marker && (
                <span
                  className={`absolute bottom-1.5 left-1/2 -translate-x-1/2 ${marker.className}`}
                  aria-hidden="true"
                />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}