import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogClose } from '@/components/ui/dialog';

// Scrollable preview of every day and exercise in a plan — opened from a plan
// card before the user commits to it.
export default function PlanPreviewDialog({ plan, onClose }) {
  const open = !!plan;
  const [loading, setLoading] = useState(false);
  const [days, setDays] = useState([]);

  useEffect(() => {
    if (!plan) return;
    let cancelled = false;
    setLoading(true);
    (async () => {
      const list = await base44.entities.PlanDay.filter({ plan_id: plan.plan_id }, '-created_date', 500);
      if (cancelled) return;
      setDays(
        [...list].sort((a, b) => (a.week_number || 0) - (b.week_number || 0) || (a.day_index || 0) - (b.day_index || 0))
      );
      setLoading(false);
    })();
    return () => { cancelled = true; };
  }, [plan && plan.plan_id]);

  const weeks = [];
  for (const day of days) {
    let week = weeks[weeks.length - 1];
    if (!week || week.number !== day.week_number) {
      week = { number: day.week_number, days: [] };
      weeks.push(week);
    }
    week.days.push(day);
  }

  return (
    <Dialog open={open} onOpenChange={(next) => { if (!next) onClose(); }}>
      <DialogContent className="flex max-h-[85dvh] flex-col overflow-hidden rounded-3xl border-2 border-sage bg-background p-0">
        <DialogHeader className="p-6 pb-4 pr-14">
          <DialogTitle className="font-heading text-2xl text-foreground">{plan ? plan.name : ''}</DialogTitle>
          <DialogDescription>
            Every day of the plan, week by week — scan it through before starting.
          </DialogDescription>
        </DialogHeader>
        <div className="overflow-y-auto px-6 pb-2">
          {loading ? (
            <div className="flex justify-center py-12">
              <div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-primary" />
            </div>
          ) : days.length === 0 ? (
            <p className="rounded-3xl border border-border bg-card p-6 text-center text-sm text-muted-foreground">
              No training days found for this plan yet.
            </p>
          ) : (
            <div className="space-y-5">
              {weeks.map((week) => (
                <section key={week.number} className="space-y-3">
                  <h3 className="font-heading text-lg text-foreground">
                    Week {week.number}
                  </h3>
                  {week.days.map((day) => (
                    <div key={day.id} className="rounded-2xl border-2 border-transparent bg-card/60 p-4">
                      <p className="font-heading text-base text-foreground">
                        {day.emoji ? `${day.emoji} ` : ''}{day.label}
                      </p>
                      <ul className="mt-2 space-y-1.5">
                        {(day.exercises || []).map((ex, i) => (
                          <li key={i} className="flex items-baseline justify-between gap-3 text-sm">
                            <span className="text-foreground">{ex.name}</span>
                            <span className="shrink-0 text-xs font-semibold text-muted-foreground">
                              {[ex.sets && ex.reps ? `${ex.sets} × ${ex.reps}` : ex.sets ? `${ex.sets} sets` : ex.reps, ex.rest && `rest ${ex.rest}`]
                                .filter(Boolean)
                                .join(' · ')}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </section>
              ))}
            </div>
          )}
        </div>
        <div className="p-6 pt-4">
          <DialogClose className="w-full rounded-full border-2 border-sage bg-card px-6 py-3 text-sm font-bold text-foreground hover:bg-secondary/30">
            Close
          </DialogClose>
        </div>
      </DialogContent>
    </Dialog>
  );
}