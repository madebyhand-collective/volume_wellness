import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Play, CalendarClock } from 'lucide-react';
import ScheduleSessionDialog from '@/components/insights/ScheduleSessionDialog';

// Today's prescribed workout, with one-tap start-now and schedule-for-later
// actions. When no plan exists yet, it points the user at the coach instead.
export default function NextWorkoutCard({ planDay, weekNumber, onBuildClick }) {
  const [scheduling, setScheduling] = useState(false);

  if (!planDay) {
    return (
      <div className="sticker rounded-3xl border-2 border-sage bg-card p-5">
        <p className="text-xs font-bold uppercase tracking-wide text-muted-foreground">Your next workout</p>
        <p className="mt-1 text-sm text-foreground">
          No plan yet — build one with your coach and today&apos;s workout will land here.
        </p>
        <button type="button" onClick={onBuildClick} className="vb-btn-primary mt-4 w-full sm:w-auto">
          Build my plan
        </button>
      </div>
    );
  }

  const exercises = planDay.exercises || [];

  return (
    <div className="sticker rounded-3xl border-2 border-sage bg-card p-5">
      <p className="text-xs font-bold uppercase tracking-wide text-muted-foreground">
        Your next workout{weekNumber ? ` · Week ${weekNumber}` : ''}
      </p>
      <h2 className="mt-1 font-heading text-2xl text-foreground">{planDay.label}</h2>
      {exercises.length > 0 && (
        <p className="mt-1 text-sm text-muted-foreground">
          {exercises.length} exercise{exercises.length > 1 ? 's' : ''} · {Math.max(...exercises.map((e) => e.sets || 3))} sets max
        </p>
      )}

      <div className="mt-4 flex flex-col gap-2 sm:flex-row">
        <Link to="/workout" className="vb-btn-primary w-full sm:w-auto">
          <Play className="h-4 w-4" />
          Start now
        </Link>
        <button type="button" onClick={() => setScheduling(true)} className="vb-btn-outline w-full sm:w-auto">
          <CalendarClock className="h-4 w-4" />
          Schedule for later
        </button>
      </div>

      <ScheduleSessionDialog open={scheduling} onOpenChange={setScheduling} />
    </div>
  );
}