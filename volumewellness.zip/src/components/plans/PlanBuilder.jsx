import React, { useState } from 'react';
import { ChevronLeft, Loader2, RefreshCw, Sparkles } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useToast } from '@/components/ui/use-toast';
import { GOALS, EQUIPMENT, WORKOUT_TYPES, SESSION_LENGTHS, DAYS_PER_WEEK } from '@/lib/volume';
import { Textarea } from '@/components/ui/textarea';

const STEPS = [
  { key: 'goals', title: 'What are you working toward?', subtitle: 'Pick all that apply.', options: GOALS, required: true },
  { key: 'workout_types', title: 'What kind of movement do you enjoy?', subtitle: 'Your coach blends this with your goals.', options: WORKOUT_TYPES },
  { key: 'days_per_week', title: 'How many days a week?', subtitle: 'Realistic beats ambitious.', options: DAYS_PER_WEEK },
  { key: 'session_length', title: 'How long is a good session?', options: SESSION_LENGTHS },
  { key: 'equipment', title: 'What do you have to work with?', subtitle: 'Your coach only picks from this list.', options: EQUIPMENT, required: true },
  { key: 'why_it_matters', title: 'Why does showing up for this matter to you?', subtitle: 'The real-world win you\u2019re after \u2014 \u201ckeeping up with the boys\u201d, \u201cclimbing stairs without getting winded\u201d. This anchors your plan.', text: true, required: true },
];

export default function PlanBuilder({ profile, onProfileUpdate, onDone }) {
  const { toast } = useToast();
  const [phase, setPhase] = useState('questions');
  const [stepIdx, setStepIdx] = useState(0);
  const [answers, setAnswers] = useState({
    goals: (profile && profile.goals) || [],
    workout_types: [],
    days_per_week: 3,
    session_length: '20to30',
    equipment: (profile && profile.equipment) || [],
    why_it_matters: '',
  });
  const [plan, setPlan] = useState(null);
  const [weekOne, setWeekOne] = useState(null);
  const [error, setError] = useState(null);
  const [activating, setActivating] = useState(false);

  const step = STEPS[stepIdx];
  const value = answers[step.key];
  const isSingle = step.key === 'days_per_week' || step.key === 'session_length';

  const toggle = (v) =>
    setAnswers((a) => ({
      ...a,
      [step.key]: a[step.key].includes(v) ? a[step.key].filter((x) => x !== v) : [...a[step.key], v],
    }));

  const canNext = !step.required
    ? true
    : step.text
      ? typeof value === 'string' && value.trim().length > 0
      : Array.isArray(value)
        ? value.length > 0
        : value !== null && value !== undefined;

  const generate = async () => {
    setPhase('generating');
    setError(null);
    try {
      const res = await base44.functions.invoke('generateWorkoutPlan', answers);
      const p = res.data && res.data.plan;
      if (!p) throw new Error('No plan returned');
      setPlan(p);
      const days = await base44.entities.PlanDay.filter({ plan_id: p.plan_id, week_number: 1 });
      setWeekOne([...days].sort((a, b) => (a.day_index ?? 0) - (b.day_index ?? 0)));
      setPhase('preview');
    } catch (e) {
      setError('Your coach hit a snag — give it another go.');
      setPhase('questions');
    }
  };

  const rebuild = async () => {
    try {
      if (plan) {
        await base44.entities.PlanDay.deleteMany({ plan_id: plan.plan_id });
        await base44.entities.PlanSummary.delete(plan.id);
      }
    } catch (e) {
      // If cleanup fails, still rebuild — the old plan just stays in My Plans.
    }
    setPlan(null);
    setWeekOne(null);
    generate();
  };

  const activate = async () => {
    setActivating(true);
    try {
      const myIds = [...new Set([...((profile && profile.my_plan_ids) || []), plan.plan_id])];
      await onProfileUpdate({ my_plan_ids: myIds, active_plan_id: plan.plan_id, current_week: 1, day_index: 0 });
      toast({ title: `${plan.name} is now your active plan.` });
      if (onDone) onDone();
    } finally {
      setActivating(false);
    }
  };

  if (phase === 'generating') {
    return (
      <div className="rounded-3xl border border-border bg-card p-8 text-center">
        <Sparkles className="mx-auto h-10 w-10 text-primary" />
        <h2 className="mt-4 font-heading text-2xl text-foreground">Your coach is building your plan</h2>
        <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
          Choosing exercises, sets, reps, and rest periods that fit your goals, your gear, and your week. This usually takes under a minute.
        </p>
        <div className="mt-6 flex justify-center">
          <Loader2 className="h-6 w-6 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  if (phase === 'preview' && plan) {
    return (
      <div className="space-y-4">
        <div className="rounded-3xl border border-border bg-card p-6">
          <span className="inline-block rounded-full bg-bloom px-3 py-1 text-xs font-bold uppercase tracking-wide text-foreground">
            Built for you
          </span>
          <h2 className="mt-3 font-heading text-3xl text-foreground">{plan.name}</h2>
          {plan.description && <p className="mt-2 text-sm text-muted-foreground">{plan.description}</p>}
          <div className="mt-4 flex flex-wrap gap-2 text-xs font-semibold">
            <span className="rounded-full bg-sun px-3 py-1.5 text-foreground">{plan.duration}</span>
            <span className="rounded-full bg-sun px-3 py-1.5 text-foreground">{plan.days_per_week} days a week</span>
            {(plan.tags || []).map((t) => (
              <span key={t} className="rounded-full bg-bloom px-3 py-1.5 text-foreground">{t}</span>
            ))}
          </div>
        </div>

        <div className="rounded-3xl border border-border bg-card p-5">
          <h3 className="mb-3 font-heading text-lg text-foreground">Week 1 preview</h3>
          {weekOne === null ? (
            <div className="flex justify-center py-6">
              <Loader2 className="h-6 w-6 animate-spin text-primary" />
            </div>
          ) : weekOne.length === 0 ? (
            <p className="text-sm text-muted-foreground">Preview coming soon — your plan is saved.</p>
          ) : (
            <div className="space-y-3">
              {weekOne.map((d) => (
                <div key={d.day_id} className="rounded-2xl border border-border p-4">
                  <p className="font-heading text-base text-foreground">{d.label}</p>
                  <ul className="mt-2 space-y-1 text-sm">
                    {(d.exercises || []).map((ex) => (
                      <li key={ex.id} className="flex items-baseline justify-between gap-2">
                        <span className="text-foreground">{ex.name}</span>
                        <span className="shrink-0 text-xs text-muted-foreground">
                          {ex.sets} × {ex.reps}{ex.rest ? ` · rest ${ex.rest}` : ''}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="flex flex-wrap gap-3">
          <button
            type="button"
            disabled={activating}
            onClick={activate}
            className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 font-medium text-primary-foreground disabled:opacity-40"
          >
            {activating && <Loader2 className="h-4 w-4 animate-spin" />}
            Make this my plan
          </button>
          <button
            type="button"
            disabled={activating}
            onClick={rebuild}
            className="inline-flex items-center gap-2 rounded-full border border-border px-6 py-3 font-medium text-foreground hover:bg-secondary disabled:opacity-40"
          >
            <RefreshCw className="h-4 w-4" />
            Rebuild it
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-3xl border border-border bg-card p-5 md:p-7">
      <div className="mb-4 flex items-center gap-2 text-sm font-semibold text-primary">
        <Sparkles className="h-4 w-4" />
        Build with your coach
      </div>
      {stepIdx > 0 && (
        <button
          type="button"
          onClick={() => setStepIdx(stepIdx - 1)}
          className="mb-3 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
        >
          <ChevronLeft className="h-4 w-4" /> Back
        </button>
      )}
      <h2 className="font-heading text-2xl text-foreground">{step.title}</h2>
      {step.subtitle && <p className="mt-1 text-sm text-muted-foreground">{step.subtitle}</p>}
      {step.text ? (
        <Textarea
          className="mt-5 min-h-[110px] rounded-2xl border-2 border-sage bg-card px-4 py-3 text-sm text-foreground"
          placeholder="In your own words\u2026"
          value={value}
          onChange={(e) => setAnswers((a) => ({ ...a, [step.key]: e.target.value }))}
        />
      ) : (
      <div className="mt-5 grid grid-cols-2 gap-2 sm:grid-cols-3">
        {step.options.map((opt) => {
          const selected = isSingle ? value === opt.value : value.includes(opt.value);
          return (
            <button
              key={opt.value}
              type="button"
              onClick={() => (isSingle ? setAnswers((a) => ({ ...a, [step.key]: opt.value })) : toggle(opt.value))}
              className={`rounded-2xl border px-3 py-4 text-center text-sm font-medium transition-all ${
                selected ? 'border-primary bg-primary text-primary-foreground' : 'border-border bg-card text-foreground hover:bg-secondary'
              }`}
            >
              {opt.label}
            </button>
          );
        })}
      </div>
      )}
      {error && <p className="mt-4 rounded-xl bg-accent px-3 py-2 text-sm text-accent-foreground">{error}</p>}
      <div className="mt-6 flex items-center gap-1.5">
        {STEPS.map((_, i) => (
          <span key={i} className={`h-1.5 w-6 rounded-full ${i <= stepIdx ? 'bg-primary' : 'bg-secondary'}`} />
        ))}
      </div>
      <button
        type="button"
        disabled={!canNext}
        onClick={() => (stepIdx === STEPS.length - 1 ? generate() : setStepIdx(stepIdx + 1))}
        className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full bg-primary px-6 py-3 font-medium text-primary-foreground disabled:opacity-40"
      >
        {stepIdx === STEPS.length - 1 ? 'Build my plan' : 'Next'}
      </button>
    </div>
  );
}