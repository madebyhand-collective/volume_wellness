import React from 'react';

export default function LazyPageFallback() {
  return (
    <div className="flex justify-center py-20">
      <div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-primary" />
    </div>
  );
}