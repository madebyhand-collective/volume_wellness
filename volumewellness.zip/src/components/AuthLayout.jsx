import React from "react";
import Illustration from "@/components/Illustration";

export default function AuthLayout({ title, subtitle, footer, children }) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4 py-10">
      <div className="w-full max-w-md">
        <div className="mb-8 flex flex-col items-center text-center">
          <Illustration motif="starburst" color="sunset" className="h-10 w-10" />
          <Illustration motif="volumewordmark" color="sunset" className="mt-2 h-8 w-auto" />
          <h1 className="font-heading text-3xl text-foreground mt-4">{title}</h1>
          {subtitle && <p className="mt-2 text-sm text-muted-foreground">{subtitle}</p>}
        </div>
        <div className="sticker rounded-3xl bg-card p-8">{children}</div>
        {footer && (
          <p className="mt-6 text-center text-sm text-muted-foreground">{footer}</p>
        )}
      </div>
    </div>
  );
}