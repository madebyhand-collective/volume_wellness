import React, { Suspense, lazy } from 'react';
import { ThemeProvider } from 'next-themes';
import { Toaster } from "@/components/ui/toaster"
import LazyPageFallback from '@/components/LazyPageFallback';
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import Layout from '@/components/Layout';
import Home from '@/pages/Home';
import Workout from '@/pages/Workout';
import Plans from '@/pages/Plans';
import Insights from '@/pages/Insights';
import Reflection from '@/pages/Reflection';
import Accountability from '@/pages/Accountability';
import Library from '@/pages/Library';
import BlockWorkout from '@/pages/BlockWorkout';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';
// Add page imports here

// Auxiliary pages load on demand as separate chunks
const Onboarding = lazy(() => import('@/pages/Onboarding'));
const Privacy = lazy(() => import('@/pages/Privacy'));
const Terms = lazy(() => import('@/pages/Terms'));
const Preferences = lazy(() => import('@/pages/Preferences'));

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route path="/onboarding" element={<Suspense fallback={<LazyPageFallback />}><Onboarding /></Suspense>} />
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/workout" element={<Workout />} />
        <Route path="/plans" element={<Plans />} />
        <Route path="/insights" element={<Insights />} />
        <Route path="/accountability" element={<Accountability />} />
        <Route path="/library" element={<Library />} />
        <Route path="/library/block/:blockId" element={<BlockWorkout />} />
        <Route path="/reflection" element={<Reflection />} />
        <Route path="/preferences" element={<Suspense fallback={<LazyPageFallback />}><Preferences /></Suspense>} />
        <Route path="/privacy" element={<Suspense fallback={<LazyPageFallback />}><Privacy /></Suspense>} />
        <Route path="/terms" element={<Suspense fallback={<LazyPageFallback />}><Terms /></Suspense>} />
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
      <AuthProvider>
        <QueryClientProvider client={queryClientInstance}>
          <Router>
            <ScrollToTop />
            <AuthenticatedApp />
          </Router>
          <Toaster />
        </QueryClientProvider>
      </AuthProvider>
    </ThemeProvider>
  )
}

export default App