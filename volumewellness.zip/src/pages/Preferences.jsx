import React, { useEffect, useState } from 'react';
import { Loader2, X } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useToast } from '@/components/ui/use-toast';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import DaySheet from '@/components/preferences/DaySheet';
import WearablesSection from '@/components/preferences/WearablesSection';
import NameCustomizationDialog from '@/components/home/NameCustomizationDialog';
import { DEFAULT_PREFERENCES, invalidateVolumeCache } from '@/lib/volume';

const INSIGHT_TOGGLES = [
  ['insight_timing_patterns', 'Timing patterns'],
  ['insight_deferral_patterns', 'Deferral patterns'],
  ['insight_cycle_performance', 'Cycle performance'],
  ['insight_warmup_signal', 'Warmup signals'],
  ['insight_cooldown_skip', 'Cooldown skips'],
  ['insight_streak_protection', 'Streak protection'],
  ['insight_life_load_correlation', 'Life load correlations'],
  ['insight_positive_reinforcement', 'Positive reinforcement'],
];

function Section({ title, children }) {
  return (
    <div className="rounded-3xl border border-border bg-card p-5">
      <h2 className="mb-4 font-heading text-lg text-foreground">{title}</h2>
      {children}
    </div>
  );
}

function Row({ label, hint, children }) {
  return (
    <div className="flex items-center justify-between gap-4 py-2">
      <div>
        <Label className="text-sm font-medium text-foreground">{label}</Label>
        {hint && <p className="text-xs text-muted-foreground">{hint}</p>}
      </div>
      {children}
    </div>
  );
}

export default function Preferences() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [recordId, setRecordId] = useState(null);
  const [prefs, setPrefs] = useState(DEFAULT_PREFERENCES);
  const [saving, setSaving] = useState(false);
  const [newExclusion, setNewExclusion] = useState('');
  const [deleting, setDeleting] = useState(false);
  const [nameStyleOpen, setNameStyleOpen] = useState(false);
  const [displayName, setDisplayName] = useState('');

  useEffect(() => {
    (async () => {
      const [list, profiles] = await Promise.all([
        base44.entities.Preferences.list(),
        base44.entities.Profile.list(),
      ]);
      if (list[0]) {
        setPrefs({ ...DEFAULT_PREFERENCES, ...list[0] });
        setRecordId(list[0].id);
      }
      if (profiles[0] && profiles[0].display_name) setDisplayName(profiles[0].display_name);
      setLoading(false);
    })();
  }, []);

  const set = (k, v) => setPrefs((p) => ({ ...p, [k]: v }));

  const addExclusion = () => {
    const name = newExclusion.trim();
    if (!name) return;
    if (!(prefs.excluded_exercises || []).some((n) => n.toLowerCase() === name.toLowerCase())) {
      set('excluded_exercises', [...(prefs.excluded_exercises || []), name]);
    }
    setNewExclusion('');
  };

  // App Store compliance: permanently erase the user's data and sign out.
  const deleteAccount = async () => {
    setDeleting(true);
    try {
      const me = await base44.auth.me();
      const own = { created_by_id: me.id };
      await Promise.all([
        base44.entities.Profile.deleteMany({ ...own }),
        base44.entities.Preferences.deleteMany({ ...own }),
        base44.entities.DailyAssessment.deleteMany({ ...own }),
        base44.entities.WorkoutSession.deleteMany({ ...own }),
        base44.entities.ExerciseLog.deleteMany({ ...own }),
        base44.entities.BehavioralEvent.deleteMany({ ...own }),
        base44.entities.Insight.deleteMany({ ...own }),
        base44.entities.Commitment.deleteMany({ ...own }),
        base44.entities.WeeklyReflection.deleteMany({ ...own }),
        base44.entities.WearableConnection.deleteMany({ ...own }),
        base44.entities.BiometricDaily.deleteMany({ ...own }),
        base44.entities.PlanSummary.deleteMany({ ...own }),
        base44.entities.PlanDay.deleteMany({ ...own }),
      ]);
      invalidateVolumeCache();
      await base44.auth.logout();
    } catch (e) {
      toast({ title: 'Could not delete your account — try again.', variant: 'destructive' });
      setDeleting(false);
    }
  };

  const save = async () => {
    const weights = ['weight_body_signal', 'weight_life_load', 'weight_mental_readiness', 'weight_behavioral_momentum'];
    const sum = weights.reduce((a, k) => a + Number(prefs[k] || 0), 0);
    if (Math.abs(sum - 1) > 0.01) {
      toast({ title: 'Score weights must add up to 100%.', description: `Right now they add up to ${Math.round(sum * 100)}%.`, variant: 'destructive' });
      return;
    }
    setSaving(true);
    try {
      const payload = { ...prefs };
      delete payload.id;
      delete payload.created_date;
      delete payload.updated_date;
      delete payload.created_by_id;
      if (recordId) await base44.entities.Preferences.update(recordId, payload);
      else {
        const created = await base44.entities.Preferences.create(payload);
        setRecordId(created.id);
      }
      invalidateVolumeCache();
      toast({ title: 'Preferences saved.' });
    } catch (e) {
      toast({ title: 'Could not save — try again.', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-4 pb-20">
      <h1 className="font-heading text-3xl text-foreground">Preferences</h1>

      <Section title="Name & app icon">
        <Row label="Name style" hint="The illustration and color beside your name on Today">
          <button
            type="button"
            onClick={() => setNameStyleOpen(true)}
            className="rounded-full border border-border px-4 py-1.5 text-xs font-medium text-muted-foreground"
          >
            Customize
          </button>
        </Row>
      </Section>

      <Section title="Daily check-in">
        <Row label="How should we prompt you?">
          <div className="flex gap-1">
            {['notification', 'in_app', 'both'].map((v) => (
              <button
                key={v}
                type="button"
                onClick={() => set('assessment_trigger', v)}
                className={`rounded-full px-3 py-1.5 text-xs font-medium capitalize ${
                  prefs.assessment_trigger === v ? 'bg-primary text-primary-foreground' : 'border border-border text-muted-foreground'
                }`}
              >
                {v.replace('_', '-')}
              </button>
            ))}
          </div>
        </Row>
        <Row label="Check-in time">
          <Input type="time" value={prefs.assessment_time} onChange={(e) => set('assessment_time', e.target.value)} className="w-32" />
        </Row>
      </Section>

      <Section title="Weekly reflection">
        <Row label="Reflection day">
          <DaySheet value={prefs.weekly_reflection_day ?? 0} onChange={(v) => set('weekly_reflection_day', v)} />
        </Row>
        <Row label="Reflection time">
          <Input type="time" value={prefs.weekly_reflection_time} onChange={(e) => set('weekly_reflection_time', e.target.value)} className="w-32" />
        </Row>
        <div className="mt-2 space-y-1 border-t border-border pt-3">
          {[
            ['reflection_conversational', 'Conversational prompt'],
            ['reflection_structured', 'Structured check-in'],
            ['reflection_cycle', 'Cycle reflection'],
            ['reflection_ai_question', 'AI-generated question'],
          ].map(([key, label]) => (
            <Row key={key} label={label}>
              <Switch checked={!!prefs[key]} onCheckedChange={(c) => set(key, c)} />
            </Row>
          ))}
        </div>
      </Section>

      <Section title="Cycle tracking">
        <Row label="Enable cycle tracking" hint="Adjusts your score by cycle phase">
          <Switch checked={!!prefs.cycle_tracking_enabled} onCheckedChange={(c) => set('cycle_tracking_enabled', c)} />
        </Row>
        {prefs.cycle_tracking_enabled && (
          <>
            <div className="py-2">
              <div className="mb-1 flex items-center justify-between text-sm">
                <Label className="font-medium text-foreground">Phase influence</Label>
                <span className="font-medium text-primary">{Math.round((prefs.cycle_tracking_weight ?? 1) * 100)}%</span>
              </div>
              <Slider
                value={[prefs.cycle_tracking_weight ?? 1]}
                min={0}
                max={1}
                step={0.05}
                onValueChange={([v]) => set('cycle_tracking_weight', v)}
              />
            </div>
            <Row label="Turn off phase influence entirely">
              <Switch checked={!!prefs.cycle_tracking_override} onCheckedChange={(c) => set('cycle_tracking_override', c)} />
            </Row>
          </>
        )}
      </Section>

      <Section title="Score weights (advanced)">
        <p className="mb-2 text-xs text-muted-foreground">How much each signal counts toward your Volume Score. Must add up to 100%.</p>
        {[
          ['weight_body_signal', 'Body signal'],
          ['weight_life_load', 'Life load'],
          ['weight_mental_readiness', 'Mental readiness'],
          ['weight_behavioral_momentum', 'Behavioral momentum'],
        ].map(([key, label]) => (
          <Row key={key} label={label}>
            <div className="flex items-center gap-2">
              <Input
                type="number"
                min="0"
                max="1"
                step="0.05"
                value={prefs[key]}
                onChange={(e) => set(key, Number(e.target.value))}
                className="w-20"
              />
              <span className="text-xs text-muted-foreground">{Math.round((prefs[key] || 0) * 100)}%</span>
            </div>
          </Row>
        ))}
      </Section>

      <Section title="Insights">
        {INSIGHT_TOGGLES.map(([key, label]) => (
          <Row key={key} label={label}>
            <Switch checked={!!prefs[key]} onCheckedChange={(c) => set(key, c)} />
          </Row>
        ))}
      </Section>

      <Section title="Warmups & cooldowns">
        <Row label="Warmup style" hint="What Volume picks when no recurring warmup is set">
          <div className="flex gap-1">
            {[['recommended', 'Volume picks'], ['mobility', 'Mobility'], ['physical_therapy', 'PT']].map(([v, label]) => (
              <button
                key={v}
                type="button"
                onClick={() => set('warmup_style', v)}
                className={`rounded-full px-3 py-1.5 text-xs font-medium ${
                  (prefs.warmup_style || 'recommended') === v ? 'bg-primary text-primary-foreground' : 'border border-border text-muted-foreground'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </Row>
        <Row label="Cooldown style" hint="Same idea for the way you wind down">
          <div className="flex gap-1">
            {[['recommended', 'Volume picks'], ['mobility', 'Mobility'], ['physical_therapy', 'PT']].map(([v, label]) => (
              <button
                key={v}
                type="button"
                onClick={() => set('cooldown_style', v)}
                className={`rounded-full px-3 py-1.5 text-xs font-medium ${
                  (prefs.cooldown_style || 'recommended') === v ? 'bg-primary text-primary-foreground' : 'border border-border text-muted-foreground'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </Row>
        <p className="mt-2 text-xs text-muted-foreground">
          To make a specific warmup or cooldown repeat on chosen days, open the Movement library and pick it.
        </p>
      </Section>

      <Section title="Excluded exercises">
        <p className="mb-3 text-xs text-muted-foreground">
          Your coach will never include these in plans it builds for you.
        </p>
        <div className="flex gap-2">
          <Input
            placeholder="Add an exercise (e.g. burpees)"
            value={newExclusion}
            onChange={(e) => setNewExclusion(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') addExclusion(); }}
          />
          <button
            type="button"
            onClick={addExclusion}
            className="shrink-0 rounded-full bg-primary px-4 text-sm font-medium text-primary-foreground"
          >
            Exclude
          </button>
        </div>
        {(prefs.excluded_exercises || []).length > 0 && (
          <div className="mt-3 flex flex-wrap gap-2">
            {(prefs.excluded_exercises || []).map((name) => (
              <span key={name} className="inline-flex items-center gap-1.5 rounded-full bg-accent px-3 py-1.5 text-sm text-accent-foreground">
                {name}
                <button
                  type="button"
                  onClick={() => set('excluded_exercises', (prefs.excluded_exercises || []).filter((n) => n !== name))}
                  aria-label={`Remove ${name}`}
                  className="text-muted-foreground hover:text-foreground"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </span>
            ))}
          </div>
        )}
      </Section>

      <Section title="Units & wearables">
        <Row label="Units">
          <div className="flex gap-1">
            {['imperial', 'metric'].map((v) => (
              <button
                key={v}
                type="button"
                onClick={() => set('units', v)}
                className={`rounded-full px-3 py-1.5 text-xs font-medium capitalize ${
                  prefs.units === v ? 'bg-primary text-primary-foreground' : 'border border-border text-muted-foreground'
                }`}
              >
                {v}
              </button>
            ))}
          </div>
        </Row>
        <p className="mt-2 text-xs text-muted-foreground">
          Wearable connections (HealthKit, Health Connect) apply to the native mobile app. Toggle what you use:
        </p>
        {[
          ['wearable_healthkit', 'Apple Health (HealthKit)'],
          ['wearable_health_connect', 'Health Connect (Android)'],
        ].map(([key, label]) => (
          <Row key={key} label={label}>
            <Switch checked={!!prefs[key]} onCheckedChange={(c) => set(key, c)} />
          </Row>
        ))}
        <WearablesSection />
      </Section>

      <button
        type="button"
        disabled={saving}
        onClick={save}
        className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-primary px-6 py-3 font-medium text-primary-foreground disabled:opacity-40"
      >
        {saving && <Loader2 className="h-4 w-4 animate-spin" />}
        Save preferences
      </button>

      <NameCustomizationDialog
        open={nameStyleOpen}
        onOpenChange={setNameStyleOpen}
        prefs={prefs}
        name={displayName}
        onSave={(updated) => {
          setPrefs((p) => ({ ...p, ...updated }));
          setRecordId(updated.id);
        }}
      />

      <Section title="Account">
        <p className="mb-3 text-xs text-muted-foreground">
          Deleting your account permanently erases everything — check-ins, workouts, insights, preferences, and custom plans — and signs you out. This can't be undone.
        </p>
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <button
              type="button"
              disabled={deleting}
              className="w-full rounded-full border-2 border-destructive px-6 py-3 font-medium text-destructive disabled:opacity-40"
            >
              {deleting ? 'Deleting…' : 'Delete account'}
            </button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete your account?</AlertDialogTitle>
              <AlertDialogDescription>
                This permanently erases all your Volume data — check-ins, workouts, insights, preferences, and custom plans — and signs you out. This can't be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Keep my account</AlertDialogCancel>
              <AlertDialogAction
                onClick={deleteAccount}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                Delete everything
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </Section>
    </div>
  );
}