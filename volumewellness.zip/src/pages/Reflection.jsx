import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useToast } from '@/components/ui/use-toast';
import { Slider } from '@/components/ui/slider';
import { Textarea } from '@/components/ui/textarea';
import { getPreferences } from '@/lib/volume';
import Illustration from '@/components/Illustration';

function StructuredSlider({ label, value, onChange }) {
  return (
    <div>
      <div className="mb-1 flex items-center justify-between text-sm">
        <span className="text-foreground">{label}</span>
        <span className="font-medium text-primary">{value}/5</span>
      </div>
      <Slider value={[value]} min={1} max={5} step={1} onValueChange={([v]) => onChange(v)} />
    </div>
  );
}

export default function Reflection() {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [prefs, setPrefs] = useState(null);
  const [gen, setGen] = useState(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    conversational_response: '',
    overall: 3,
    stress: 3,
    nutrition: 3,
    social: 3,
    highlight: '',
    one_change: '',
    cycle_accurate: null,
    cycle_notes: '',
    ai_response: '',
  });

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const pr = await getPreferences();
        if (cancelled) return;
        setPrefs(pr);
        if (!pr || pr.reflection_conversational || pr.reflection_ai_question) {
          try {
            const res = await base44.functions.invoke('generateReflectionPrompts', {});
            if (!cancelled) setGen(res.data || null);
          } catch (e) {
            // prompts are best-effort; the page still works
          }
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const save = async () => {
    setSaving(true);
    try {
      const stats = (gen && gen.stats) || {};
      await base44.entities.WeeklyReflection.create({
        week_start_date: stats.week_start_date || null,
        completed_at: new Date().toISOString(),
        avg_volume_score: stats.avg_volume_score ?? null,
        sessions_completed: stats.sessions_completed ?? null,
        sessions_attempted: stats.sessions_attempted ?? null,
        dominant_life_load: stats.dominant_life_load || null,
        conversational_prompt_text: (gen && gen.conversational_prompt) || null,
        conversational_response: form.conversational_response || null,
        structured_overall_feeling: prefs && prefs.reflection_structured ? form.overall : null,
        structured_stress: prefs && prefs.reflection_structured ? form.stress : null,
        structured_nutrition: prefs && prefs.reflection_structured ? form.nutrition : null,
        structured_social: prefs && prefs.reflection_structured ? form.social : null,
        structured_highlight: form.highlight || null,
        structured_one_change: form.one_change || null,
        cycle_felt_accurate: form.cycle_accurate === null ? null : form.cycle_accurate,
        cycle_notes: form.cycle_notes || null,
        ai_question: (gen && gen.ai_question) || null,
        ai_response: form.ai_response || null,
      });
      toast({ title: 'Reflection saved. See you next week.' });
      navigate('/');
    } catch (e) {
      toast({ title: 'Could not save — try again.', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-primary" />
      </div>
    );
  }

  const showConversational = !prefs || prefs.reflection_conversational;
  const showStructured = !prefs || prefs.reflection_structured;
  const showCycle = prefs && prefs.reflection_cycle;
  const showAi = !prefs || prefs.reflection_ai_question;
  const stats = (gen && gen.stats) || {};

  return (
    <div className="space-y-5">
      <div>
        <h1 className="flex items-center gap-3 font-heading text-3xl text-foreground">
          Weekly reflection
          <Illustration motif="sparkleicon" color="sunset" className="h-9 w-9" />
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">A quiet minute to look back at the week.</p>
      </div>

      {stats.sessions_attempted !== null && stats.sessions_attempted !== undefined && (
        <div className="rounded-3xl border border-border bg-card p-5">
          <div className="grid grid-cols-3 gap-3 text-center">
            <div>
              <div className="font-heading text-2xl text-primary">{stats.sessions_completed ?? 0}/{stats.sessions_attempted ?? 0}</div>
              <div className="text-xs text-muted-foreground">Sessions done</div>
            </div>
            <div>
              <div className="font-heading text-2xl text-primary">{stats.avg_volume_score ?? '—'}</div>
              <div className="text-xs text-muted-foreground">Avg Volume Score</div>
            </div>
            <div>
              <div className="font-heading text-2xl text-primary capitalize">{stats.dominant_life_load || '—'}</div>
              <div className="text-xs text-muted-foreground">Life load</div>
            </div>
          </div>
        </div>
      )}

      {showConversational && (
        <div className="rounded-3xl border border-border bg-card p-5">
          <h2 className="font-heading text-lg text-foreground">One honest question</h2>
          <p className="mt-2 text-sm italic text-muted-foreground">
            {gen && gen.conversational_prompt ? gen.conversational_prompt : 'What mattered most in your week of movement?'}
          </p>
          <Textarea
            className="mt-3"
            rows={3}
            placeholder="Write as little or as much as you want…"
            value={form.conversational_response}
            onChange={(e) => set('conversational_response', e.target.value)}
          />
        </div>
      )}

      {showStructured && (
        <div className="space-y-4 rounded-3xl border border-border bg-card p-5">
          <h2 className="font-heading text-lg text-foreground">Quick check-in</h2>
          <StructuredSlider label="Overall feeling" value={form.overall} onChange={(v) => set('overall', v)} />
          <StructuredSlider label="Stress" value={form.stress} onChange={(v) => set('stress', v)} />
          <StructuredSlider label="Nutrition" value={form.nutrition} onChange={(v) => set('nutrition', v)} />
          <StructuredSlider label="Social connection" value={form.social} onChange={(v) => set('social', v)} />
          <div>
            <p className="mb-1 text-sm text-foreground">One highlight</p>
            <Textarea rows={1} value={form.highlight} onChange={(e) => set('highlight', e.target.value)} placeholder="Went for…" />
          </div>
          <div>
            <p className="mb-1 text-sm text-foreground">One thing to change</p>
            <Textarea rows={1} value={form.one_change} onChange={(e) => set('one_change', e.target.value)} placeholder="Next week I'll…" />
          </div>
        </div>
      )}

      {showCycle && (
        <div className="rounded-3xl border border-border bg-card p-5">
          <h2 className="font-heading text-lg text-foreground">Cycle reflection</h2>
          <p className="mt-1 text-sm text-muted-foreground">Did this week&apos;s phase predictions match how it actually felt?</p>
          <div className="mt-3 grid grid-cols-3 gap-2 text-sm">
            {[
              { value: true, label: 'Yes, matched' },
              { value: false, label: 'Not quite' },
              { value: null, label: 'Not sure' },
            ].map((opt) => (
              <button
                key={opt.label}
                type="button"
                onClick={() => set('cycle_accurate', opt.value)}
                className={`rounded-2xl border px-3 py-2 font-medium ${
                  form.cycle_accurate === opt.value
                    ? 'border-primary bg-primary text-primary-foreground'
                    : 'border-border bg-card text-foreground hover:bg-secondary'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
          <Textarea
            className="mt-3"
            rows={2}
            placeholder="Notes on your cycle phases this week…"
            value={form.cycle_notes}
            onChange={(e) => set('cycle_notes', e.target.value)}
          />
        </div>
      )}

      {showAi && (
        <div className="rounded-3xl border border-[#bda634]/40 bg-[#fee3c5]/40 p-5">
          <h2 className="font-heading text-lg text-foreground">Volume asks</h2>
          <p className="mt-2 text-sm text-foreground">
            {gen && gen.ai_question ? gen.ai_question : 'What is one thing that would make next week easier?'}
          </p>
          <Textarea
            className="mt-3 bg-card"
            rows={3}
            placeholder="Your answer…"
            value={form.ai_response}
            onChange={(e) => set('ai_response', e.target.value)}
          />
        </div>
      )}

      <button
        type="button"
        disabled={saving}
        onClick={save}
        className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-primary px-6 py-3 font-medium text-primary-foreground disabled:opacity-40"
      >
        {saving && <Loader2 className="h-4 w-4 animate-spin" />}
        Save reflection
      </button>
    </div>
  );
}