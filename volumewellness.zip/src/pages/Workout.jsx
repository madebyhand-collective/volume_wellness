import React, { useEffect, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useToast } from '@/components/ui/use-toast';
import { localTodayStr, TIERS, getProfile, getPreferences, invalidateVolumeCache } from '@/lib/volume';
import { logEvent } from '@/lib/behavioral';
import { createCommitment } from '@/lib/commitments';
import SkipDialog from '@/components/workout/SkipDialog';
import FinishDialog from '@/components/workout/FinishDialog';
import SessionBlockCard from '@/components/workout/SessionBlockCard';
import ExerciseCard from '@/components/workout/ExerciseCard';

export default function Workout() {
  const { toast } = useToast();
  const navigate = useNavigate();
  const startedAt = useRef(new Date().toISOString());
  const [loading, setLoading] = useState(true);
  const [assessment, setAssessment] = useState(null);
  const [profile, setProfile] = useState(null);
  const [prefs, setPrefs] = useState(null);
  const [planDay, setPlanDay] = useState(null);
  const [weekDayCount, setWeekDayCount] = useState(0);
  const [maxWeek, setMaxWeek] = useState(1);
  const [warmupBlock, setWarmupBlock] = useState(null);
  const [cooldownBlock, setCooldownBlock] = useState(null);
  const [blocks, setBlocks] = useState([]);
  const [expandedId, setExpandedId] = useState(null);
  const [history, setHistory] = useState({});
  const [exStates, setExStates] = useState({});
  const [warmup, setWarmup] = useState({ done: false, skipped: false, reason: null });
  const [cooldown, setCooldown] = useState({ done: false, skipped: false, reason: null });
  const [skipTarget, setSkipTarget] = useState(null);
  const [finishOpen, setFinishOpen] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const today = localTodayStr();
        const [assessments, p, pref] = await Promise.all([
          base44.entities.DailyAssessment.list('-created_date', 30),
          getProfile(),
          getPreferences(),
        ]);
        if (cancelled) return;
        const a = assessments.find((x) => x.date === today) || null;
        setAssessment(a);
        setProfile(p);
        setPrefs(pref);
        if (a && p && p.active_plan_id) {
          const days = await base44.entities.PlanDay.filter({ plan_id: p.active_plan_id });
          if (cancelled) return;
          setMaxWeek(Math.max(1, ...days.map((d) => d.week_number)));
          const weekDays = days
            .filter((d) => d.week_number === p.current_week)
            .sort((x, y) => (x.day_index ?? 0) - (y.day_index ?? 0));
          setWeekDayCount(weekDays.length);
          const day = weekDays[Math.min(p.day_index ?? 0, Math.max(weekDays.length - 1, 0))] || null;
          setPlanDay(day);
          const blocks = await base44.entities.SessionBlock.list();
          if (cancelled) return;
          setBlocks(blocks);
          setWarmupBlock(blocks.find((b) => b.block_id === a.rec_warmup_block_id) || null);
          setCooldownBlock(blocks.find((b) => b.block_id === a.rec_cooldown_block_id) || null);
          if (day && day.exercises) {
            const ids = new Set(day.exercises.map((e) => e.id));
            const logs = await base44.entities.ExerciseLog.list('-created_date', 100);
            if (cancelled) return;
            const hist = {};
            logs
              .filter((l) => ids.has(l.exercise_id))
              .sort((x, y) => new Date(y.created_date) - new Date(x.created_date))
              .forEach((l) => {
                if (!hist[l.exercise_id] && hist[l.exercise_id] !== []) hist[l.exercise_id] = [];
                if (hist[l.exercise_id].length < 3) hist[l.exercise_id].push(l);
              });
            setHistory(hist);
            const mod = a.rec_set_modifier || 0;
            const states = {};
            day.exercises.forEach((ex) => {
              const n = Math.max(1, (ex.sets || 3) + mod);
              const lastLog = hist[ex.id] && hist[ex.id][0];
              const lastSets = (lastLog && lastLog.sets) || [];
              states[ex.id] = {
                done: false,
                skipped: false,
                note: '',
                sets: Array.from({ length: n }, (_, i) => ({
                  weight: (lastSets[i] && lastSets[i].weight) ?? (lastSets[0] && lastSets[0].weight) ?? '',
                  reps: (lastSets[i] && lastSets[i].reps) || ex.reps || '',
                  rpe: '',
                  completed: false,
                })),
              };
            });
            setExStates(states);
          }
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  const setEx = (id, patch) => setExStates((s) => ({ ...s, [id]: { ...s[id], ...patch } }));

  const chooseSkip = async (reason) => {
    const which = skipTarget;
    setSkipTarget(null);
    if (which === 'warmup') setWarmup({ done: false, skipped: true, reason });
    else setCooldown({ done: false, skipped: true, reason });
    await logEvent(which === 'warmup' ? 'warmup_skipped' : 'cooldown_skipped', {
      volume_score_at_time: assessment ? assessment.volume_score_total : null,
    });
  };

  // Swap the whole warmup/cooldown session — logs the rejected one with a reason.
  const swapBlock = async (kind, newBlock, reason) => {
    const current = kind === 'warmup' ? warmupBlock : cooldownBlock;
    if (kind === 'warmup') setWarmupBlock(newBlock);
    else setCooldownBlock(newBlock);
    await logEvent('recommendation_rejected', {
      volume_score_at_time: assessment ? assessment.volume_score_total : null,
      block_type: kind,
      item_name: current ? current.name : 'General',
      reason,
    });
  };

  // Replace one exercise inside a block: logs the rejection, swaps it in here,
  // and adds it to the avoid list so future plans skip it entirely.
  const replaceBlockExercise = async (kind, exercise, replacementName, reason) => {
    const block = kind === 'warmup' ? warmupBlock : cooldownBlock;
    if (block) {
      const exercises = (block.exercises || []).map((e) =>
        e.name === exercise.name ? { ...e, name: replacementName } : e
      );
      if (kind === 'warmup') setWarmupBlock({ ...block, exercises });
      else setCooldownBlock({ ...block, exercises });
    }
    await logEvent('recommendation_rejected', {
      volume_score_at_time: assessment ? assessment.volume_score_total : null,
      block_type: kind,
      item_name: exercise.name,
      reason,
    });
    const excluded = [...new Set([...((prefs && prefs.excluded_exercises) || []), exercise.name])];
    if (prefs && prefs.id) {
      await base44.entities.Preferences.update(prefs.id, { excluded_exercises: excluded });
      setPrefs({ ...prefs, excluded_exercises: excluded });
    } else {
      const created = await base44.entities.Preferences.create({ excluded_exercises: excluded });
      setPrefs(created);
    }
    invalidateVolumeCache();
  };

  // Auto-continue: once an exercise is finished, open the next one.
  const autoAdvance = (exId) => {
    const list = (planDay && planDay.exercises) || [];
    const i = list.findIndex((e) => e.id === exId);
    const next = list[i + 1];
    setExpandedId(next ? next.id : null);
  };

  const defer = async () => {
    await logEvent('later_tap', { volume_score_at_time: assessment ? assessment.volume_score_total : null });
    await logEvent('workout_deferred', { volume_score_at_time: assessment ? assessment.volume_score_total : null });
    try {
      if (profile && planDay) {
        const due = new Date(Date.now() + 6 * 3600e3);
        await base44.entities.WorkoutSession.create({
          plan_id: profile.active_plan_id,
          week_number: profile.current_week,
          day_id: planDay.day_id,
          date: localTodayStr(),
          status: 'deferred',
          volume_score_at_time: assessment ? assessment.volume_score_total : null,
          tier_at_time: assessment ? assessment.volume_score_tier : null,
          deferred_to: due.toISOString(),
          deferral_outcome: 'never_completed',
        });
        await createCommitment({
          kind: 'workout',
          label: planDay.label || 'Your workout',
          due_date: localTodayStr(),
          due_time: `${String(due.getHours()).padStart(2, '0')}:${String(due.getMinutes()).padStart(2, '0')}`,
          source: 'defer',
        });
      }
      toast({ title: 'No problem. It’ll be here when you’re ready.' });
      navigate('/');
    } catch (e) {
      toast({ title: 'Could not save that — try again.', variant: 'destructive' });
    }
  };

  const finish = async ({ mood, note, exertion }) => {
    setSaving(true);
    try {
      const exercises = (planDay && planDay.exercises) || [];
      const anyLogged = exercises.some((ex) => (exStates[ex.id] ? exStates[ex.id].sets.some((s) => s.completed) : false));
      const allDone = exercises.every((ex) => {
        const st = exStates[ex.id];
        return st && (st.skipped || st.done);
      });
      const anySkipped = exercises.some((ex) => exStates[ex.id] && exStates[ex.id].skipped);
      const status = allDone && !anySkipped ? 'completed' : anyLogged || allDone ? 'partial' : 'skipped';
      const unit = prefs && prefs.units === 'metric' ? 'kg' : 'lbs';
      const session = await base44.entities.WorkoutSession.create({
        plan_id: profile.active_plan_id,
        week_number: profile.current_week,
        day_id: planDay.day_id,
        date: localTodayStr(),
        status,
        started_at: startedAt.current,
        completed_at: new Date().toISOString(),
        volume_score_at_time: assessment ? assessment.volume_score_total : null,
        tier_at_time: assessment ? assessment.volume_score_tier : null,
        warmup_completed: warmup.done,
        warmup_skipped: warmup.skipped,
        warmup_skip_reason: warmup.reason,
        cooldown_completed: cooldown.done,
        cooldown_skipped: cooldown.skipped,
        cooldown_skip_reason: cooldown.reason,
        session_note: note || '',
        perceived_exertion: exertion,
        post_session_mood: mood,
      });
      const logs = exercises.map((ex, i) => {
        const st = exStates[ex.id] || {};
        const doneSets = (st.sets || []).filter((s) => s.completed);
        return {
          session_id: session.id,
          exercise_id: ex.id,
          exercise_name: ex.name,
          set_modifier_applied: assessment ? assessment.rec_set_modifier || 0 : 0,
          skipped: !!st.skipped,
          note: st.note || '',
          order: i + 1,
          sets: doneSets.map((s, j) => ({
            set_number: j + 1,
            weight: Number(s.weight) || 0,
            weight_unit: unit,
            reps: String(s.reps),
            rpe: s.rpe === '' || s.rpe === null ? null : Number(s.rpe),
            completed: true,
          })),
        };
      });
      await base44.entities.ExerciseLog.bulkCreate(logs);
      let nextIndex = (profile.day_index ?? 0) + 1;
      let nextWeek = profile.current_week;
      if (nextIndex >= weekDayCount) {
        nextWeek = Math.min(nextWeek + 1, maxWeek);
        nextIndex = 0;
      }
      await base44.entities.Profile.update(profile.id, { day_index: nextIndex, current_week: nextWeek });
      invalidateVolumeCache();
      toast({ title: status === 'completed' ? 'Session complete — nice work.' : 'Logged. Every bit counts.' });
      navigate('/');
    } catch (e) {
      toast({ title: 'Could not save the session — try again.', variant: 'destructive' });
    } finally {
      setSaving(false);
      setFinishOpen(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-primary" />
      </div>
    );
  }

  if (!assessment) {
    return (
      <div className="rounded-3xl border border-border bg-card p-8 text-center">
        <h2 className="font-heading text-2xl text-foreground">Check in first</h2>
        <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
          Volume tunes today&apos;s session to how you&apos;re actually doing. Take the 30-second check-in, then come back.
        </p>
        <Link to="/" className="mt-6 inline-block rounded-full bg-primary px-8 py-3 font-medium text-primary-foreground">
          Do today&apos;s check-in
        </Link>
      </div>
    );
  }

  const tier = TIERS[assessment.volume_score_tier] || TIERS.baseline;
  const setModifier = assessment.rec_set_modifier || 0;

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted-foreground">Today&apos;s workout</p>
          <h1 className="font-heading text-2xl text-foreground">
            {planDay ? planDay.label : 'Not selected'}
          </h1>
        </div>
        <div className={`rounded-full px-3 py-1.5 text-xs font-medium ${tier.chip}`}>
          {tier.label} · Score {assessment.volume_score_total}
        </div>
      </div>

      <SessionBlockCard
        kind="warmup"
        block={warmupBlock}
        alternatives={blocks.filter((b) => b.type === 'warmup' && (!warmupBlock || b.block_id !== warmupBlock.block_id))}
        state={warmup}
        onDone={() => setWarmup({ done: true, skipped: false, reason: null })}
        onSkip={() => setSkipTarget('warmup')}
        onSwapBlock={(b, reason) => swapBlock('warmup', b, reason)}
        onReplaceExercise={(ex, name, reason) => replaceBlockExercise('warmup', ex, name, reason)}
      />

      <div className="rounded-3xl border border-border bg-card p-5">
        <div className="mb-3 flex items-baseline justify-between">
          <h3 className="font-heading text-lg text-foreground">Core block</h3>
          <span className="text-xs text-muted-foreground">Week {profile.current_week} · {assessment.rec_session_length_cap} min cap</span>
        </div>
        {planDay ? (
          <div className="space-y-2">
            {(planDay.exercises || []).map((ex) => (
              <ExerciseCard
                key={ex.id}
                exercise={ex}
                setCount={Math.max(1, (ex.sets || 3) + setModifier)}
                modifier={setModifier}
                history={history[ex.id]}
                state={exStates[ex.id] || { done: false, skipped: false, note: '', sets: [] }}
                onChange={(patch) => setEx(ex.id, patch)}
                expanded={expandedId === ex.id}
                onToggleExpand={() => setExpandedId(expandedId === ex.id ? null : ex.id)}
                onAutoNext={() => autoAdvance(ex.id)}
              />
            ))}
          </div>
        ) : (
          <p className="text-sm text-muted-foreground">
            No plan day found. <Link to="/plans" className="underline">Set an active plan</Link> to get today&apos;s exercises.
          </p>
        )}
      </div>

      <SessionBlockCard
        kind="cooldown"
        block={cooldownBlock}
        alternatives={blocks.filter((b) => b.type === 'cooldown' && (!cooldownBlock || b.block_id !== cooldownBlock.block_id))}
        state={cooldown}
        onDone={() => setCooldown({ done: true, skipped: false, reason: null })}
        onSkip={() => setSkipTarget('cooldown')}
        onSwapBlock={(b, reason) => swapBlock('cooldown', b, reason)}
        onReplaceExercise={(ex, name, reason) => replaceBlockExercise('cooldown', ex, name, reason)}
      />

      <div className="flex flex-col gap-2 pt-2 sm:flex-row sm:justify-end">
        <button type="button" onClick={defer} className="rounded-full border border-border px-6 py-3 text-sm font-medium text-muted-foreground hover:bg-secondary">
          Do it later
        </button>
        <button type="button" onClick={() => setFinishOpen(true)} className="rounded-full bg-primary px-8 py-3 text-sm font-medium text-primary-foreground">
          Finish session
        </button>
      </div>

      <SkipDialog open={!!skipTarget} onChoose={chooseSkip} onClose={() => setSkipTarget(null)} />
      <FinishDialog open={finishOpen} saving={saving} onDone={finish} onClose={() => setFinishOpen(false)} />
    </div>
  );
}