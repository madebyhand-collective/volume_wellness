import React, { useEffect, useState } from 'react';
import { Loader2, Sparkles } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useToast } from '@/components/ui/use-toast';
import InsightCard from '@/components/insights/InsightCard';
import WorkoutConsistencyChart from '@/components/home/WorkoutConsistencyChart';
import MoodConsistencyCard from '@/components/insights/MoodConsistencyCard';
import ScoreTrend from '@/components/insights/ScoreTrend';
import GeneralInsightCard from '@/components/insights/GeneralInsightCard';
import { GENERAL_INSIGHTS } from '@/lib/general-insights';
import { logEvent } from '@/lib/behavioral';
import PullToRefresh from '@/components/PullToRefresh';
import { invalidateVolumeCache } from '@/lib/volume';
import Illustration from '@/components/Illustration';

export default function Insights() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [insights, setInsights] = useState([]);
  const [generating, setGenerating] = useState(false);
  const [view, setView] = useState('patterns');

  const load = async () => {
    const list = await base44.entities.Insight.list('-created_date', 50);
    setInsights(list.filter((i) => i.status !== 'dismissed'));
    setLoading(false);
  };

  useEffect(() => {
    load();
    logEvent('insight_seen');
  }, []);

  const update = async (id, patch) => {
    const updated = await base44.entities.Insight.update(id, patch);
    setInsights((list) => list.map((i) => (i.id === id ? updated : i)));
  };

  const generate = async () => {
    setGenerating(true);
    try {
      const res = await base44.functions.invoke('generateInsights', {});
      const created = res.data && res.data.total_created ? res.data.total_created : 0;
      toast({
        title: created > 0 ? `${created} new insight${created > 1 ? 's' : ''} found` : 'No new patterns yet',
        description: created > 0 ? undefined : 'Keep checking in — Volume needs a few days of data to spot your patterns.',
      });
      await load();
    } catch (e) {
      toast({ title: 'Could not generate insights — try again.', variant: 'destructive' });
    } finally {
      setGenerating(false);
    }
  };

  return (
    <PullToRefresh onRefresh={async () => { invalidateVolumeCache(); await load(); }}>
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="flex items-center gap-3 font-heading text-3xl text-foreground">
            Insights
            <Illustration motif="sparkleicon" color="sunset" className="h-8 w-8" />
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">Patterns from your actual behavior — not generic advice.</p>
        </div>
        {view === 'patterns' && (
          <button
            type="button"
            onClick={generate}
            disabled={generating}
            className="sticker inline-flex items-center gap-2 self-start whitespace-nowrap rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-40"
          >
            {generating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
            {generating ? 'Reading…' : 'Find patterns'}
          </button>
        )}
      </div>

      <div className="flex gap-2" role="tablist" aria-label="Insights views">
        {[
          { id: 'patterns', label: 'Patterns' },
          { id: 'trend', label: 'Score trend' },
        ].map(({ id, label }) => (
          <button
            key={id}
            type="button"
            role="tab"
            aria-selected={view === id}
            onClick={() => setView(id)}
            className={`rounded-full px-4 py-1.5 text-sm font-semibold ${
              view === id ? 'bg-primary text-primary-foreground' : 'bg-muted text-foreground'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {view === 'trend' ? (
        <ScoreTrend />
      ) : loading ? (
        <div className="flex justify-center py-20">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-primary" />
        </div>
      ) : insights.length === 0 ? (
        <div className="space-y-3">
          <p className="text-sm text-muted-foreground">
            General starting points for now — your own patterns start replacing these after a few days of check-ins, workouts, and skips.
          </p>
          {GENERAL_INSIGHTS.map((tip) => (
            <GeneralInsightCard key={tip.title} tip={tip} />
          ))}
        </div>
      ) : (
        <div className="space-y-3">
          {insights.map((insight) => (
            <InsightCard key={insight.id} insight={insight} onUpdate={(patch) => update(insight.id, patch)} />
          ))}
        </div>
      )}

      <WorkoutConsistencyChart />

      <MoodConsistencyCard />
    </div>
    </PullToRefresh>
  );
}