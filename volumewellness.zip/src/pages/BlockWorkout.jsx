import React, { useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import BlockPlayer from '@/components/library/BlockPlayer';

export default function BlockWorkout() {
  const { blockId } = useParams();
  const [block, setBlock] = useState(null);
  const [notFound, setNotFound] = useState(false);

  React.useEffect(() => {
    let cancelled = false;
    (async () => {
      const blocks = await base44.entities.SessionBlock.list();
      if (cancelled) return;
      const found = blocks.find((b) => b.block_id === blockId);
      if (found) setBlock(found);
      else setNotFound(true);
    })();
    return () => { cancelled = true; };
  }, [blockId]);

  if (notFound) {
    return (
      <div className="rounded-3xl border border-border bg-card p-8 text-center">
        <h1 className="font-heading text-2xl text-foreground">Can&apos;t find that routine</h1>
        <p className="mt-2 text-sm text-muted-foreground">It may have been removed.</p>
        <Link to="/library" className="mt-4 inline-block font-semibold text-primary underline">
          Back to the library
        </Link>
      </div>
    );
  }

  if (!block) {
    return (
      <div className="flex justify-center py-20">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-primary" />
      </div>
    );
  }

  return <BlockPlayer block={block} />;
}