import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useToast } from '@/components/ui/use-toast';
import ActivePlanCard from '@/components/plans/ActivePlanCard';
import NextWorkoutCard from '@/components/plans/NextWorkoutCard';
import PlanCard from '@/components/plans/PlanCard';
import TrainingCalendar from '@/components/plans/TrainingCalendar';
import PlanBuilder from '@/components/plans/PlanBuilder';
import PlanPreviewDialog from '@/components/plans/PlanPreviewDialog';
import ExercisePreferences from '@/components/plans/ExercisePreferences';
import { getProfile, invalidateVolumeCache } from '@/lib/volume';
import Illustration from '@/components/Illustration';

const TABS = [
{ value: 'calendar', label: 'Calendar' },
{ value: 'build', label: 'Coach' },
{ value: 'exercises', label: 'Exercises' },
{ value: 'mine', label: 'My Plans' }];


export default function Plans() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [plans, setPlans] = useState([]);
  const [profile, setProfile] = useState(null);
  const [previewPlan, setPreviewPlan] = useState(null);
  const [tab, setTab] = useState('calendar');
  const [nextDay, setNextDay] = useState(null);

  const load = async () => {
    const [summaries, p] = await Promise.all([
    base44.entities.PlanSummary.list(),
    getProfile()]
    );
    setPlans(summaries);
    setProfile(p);
    let nextDay = null;
    if (p && p.active_plan_id) {
      const days = await base44.entities.PlanDay.filter({ plan_id: p.active_plan_id });
      const weekDays = days.
      filter((d) => d.week_number === p.current_week).
      sort((a, b) => (a.day_index ?? 0) - (b.day_index ?? 0));
      nextDay = weekDays[Math.min(p.day_index ?? 0, Math.max(weekDays.length - 1, 0))] || null;
    }
    setNextDay(nextDay);
    setLoading(false);
  };

  useEffect(() => {load();}, []);

  const myPlanIds = profile && profile.my_plan_ids || [];
  const activeId = profile && profile.active_plan_id;
  const activePlan = plans.find((p) => p.plan_id === activeId) || null;

  const updateProfile = async (patch) => {
    const updated = await base44.entities.Profile.update(profile.id, patch);
    invalidateVolumeCache();
    setProfile(updated);
  };

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-primary" />
      </div>);

  }

  const mine = plans.filter((p) => myPlanIds.includes(p.plan_id));

  return (
    <div className="space-y-4">
      <h1 className="flex items-center gap-3 font-heading text-3xl text-foreground">
        Plans
        <Illustration motif="fillingcup" color="sunset" className="h-9 w-9" />
      </h1>

      <ActivePlanCard plan={activePlan} onOpen={() => setPreviewPlan(activePlan)} />
      <NextWorkoutCard planDay={nextDay} weekNumber={profile && profile.current_week} onBuildClick={() => setTab('build')} />

      <div className="grid w-full grid-cols-4 gap-1.5 rounded-full border-2 border-sage p-1.5 shadow-[4px_4px_0_hsl(var(--sage))] bg-[hsl(var(--accent))]">
        {TABS.map(({ value, label }) =>
        <button
          key={value}
          type="button"
          onClick={() => setTab(value)}
          className={`rounded-full px-2 py-2.5 text-xs font-bold sm:text-sm ${
          tab === value ? 'bg-primary text-primary-foreground' : 'bg-bloom text-foreground'}`
          }>
          
            {label}
          </button>
        )}
      </div>

      {tab === 'calendar' &&
      <div className="mt-4"><TrainingCalendar profile={profile} /></div>
      }

      {tab === 'build' &&
      <div className="mt-4"><PlanBuilder profile={profile} onProfileUpdate={updateProfile} onDone={load} /></div>
      }

      {tab === 'exercises' &&
      <div className="mt-4"><ExercisePreferences /></div>
      }

      {tab === 'mine' &&
      <div className="mt-4 space-y-4">
          {mine.length === 0 ?
        <p className="rounded-3xl border border-border bg-card p-6 text-center text-sm text-muted-foreground">
              You haven&apos;t saved any plans yet. Build one with your coach — it takes about a minute.
            </p> :

        mine.map((plan) =>
        <PlanCard
          key={plan.id}
          plan={plan}
          inMyPlans
          isActive={plan.plan_id === activeId}
          onSetActive={() => updateProfile({ active_plan_id: plan.plan_id, current_week: 1, day_index: 0 }).then(() => toast({ title: `${plan.name} is now your active plan.` }))}
          onAdd={() => {}}
          onPreview={() => setPreviewPlan(plan)} />

        )
        }
        </div>
      }

      <PlanPreviewDialog plan={previewPlan} onClose={() => setPreviewPlan(null)} />
    </div>);

}