import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, Heart, Lock, Share2, Trash2, Bell, Eye, ShieldCheck } from 'lucide-react';
import Illustration from '@/components/Illustration';

const SECTIONS = [
  {
    icon: Eye,
    title: 'What Volume collects',
    points: [
      'Your name and how you want to be addressed',
      'Daily check-in answers — soreness, energy, sleep, stress, life load, and time available',
      'Workout logs, warmups and cooldowns you complete, and notes you write about them',
      'Your goals, equipment, and schedule preferences',
      'Cycle phase, only if you turn cycle tracking on — it stays off by default',
    ],
  },
  {
    icon: Heart,
    title: 'How your data is used',
    points: [
      'Your check-ins power your daily Volume Score and the workout tier it recommends',
      'Patterns in your sessions and check-ins shape the insights and reflections you receive',
      'Everything stays tied to your account and is never used to profile you elsewhere',
    ],
  },
  {
    icon: Share2,
    title: 'What never happens',
    points: [
      'Your data is never sold, rented, or traded',
      'Your check-ins and workout logs are never shared with advertisers',
      'No third party receives your personal information for marketing',
    ],
  },
  {
    icon: Lock,
    title: 'How your data is protected',
    points: [
      'Your records are isolated to your account — other users cannot see them',
      'Sign-in is handled through secure, standard authentication (email, password, or Google)',
      'Access is limited to what the app needs to personalize your experience',
    ],
  },
  {
    icon: Bell,
    title: 'Email and notifications',
    points: [
      'If you enable reminders, Volume sends check-in nudges and weekly reflection prompts to your email',
      'You can change reminder times or turn them off any time in Preferences',
      'Transactional email (like password resets) is only sent when you request it',
    ],
  },
  {
    icon: Trash2,
    title: 'Your control',
    points: [
      'You can edit or delete your check-ins, sessions, and notes whenever you want',
      'Deleting your account removes your profile, preferences, and history',
      'Export questions or deletion requests can be sent to the support contact below',
    ],
  },
];

export default function Privacy() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto max-w-2xl px-5 py-8">
        <div className="mb-6 flex items-center gap-3">
          <button
            type="button"
            onClick={() => navigate(-1)}
            className="rounded-full p-1.5 text-muted-foreground hover:bg-secondary"
            aria-label="Back"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <Illustration motif="volumewordmark" color="sunset" className="h-7 md:h-8 w-auto" />
        </div>

        <div className="rounded-3xl border-2 border-sage bg-card p-6 md:p-8 sticker">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-primary/10 px-3 py-1 text-xs font-bold uppercase tracking-wide text-primary">
            <ShieldCheck className="h-3.5 w-3.5" aria-hidden="true" />
            Privacy
          </span>
          <h1 className="mt-3 font-heading text-3xl text-foreground md:text-4xl">
            Your body, your data
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Volume asks personal questions because honest answers build better training days.
            Here is exactly where those answers go — and where they never go.
          </p>
          <p className="mt-3 text-xs uppercase tracking-wide text-muted-foreground">
            Last updated: September 25, 2026
          </p>
        </div>

        <div className="mt-5 space-y-4">
          {SECTIONS.map(({ icon: Icon, title, points }) => (
            <section key={title} className="rounded-3xl border-2 border-sage bg-card p-6">
              <h2 className="flex items-center gap-2.5 font-heading text-xl text-foreground">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                  <Icon className="h-4 w-4" aria-hidden="true" />
                </span>
                {title}
              </h2>
              <ul className="mt-3 space-y-2">
                {points.map((point) => (
                  <li key={point} className="flex gap-2.5 text-sm text-foreground/80">
                    <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" aria-hidden="true" />
                    {point}
                  </li>
                ))}
              </ul>
            </section>
          ))}

          <section className="rounded-3xl border-2 border-sage bg-card p-6">
            <h2 className="font-heading text-xl text-foreground">Questions or requests</h2>
            <p className="mt-2 text-sm text-foreground/80">
              Anything unclear, or want something changed or deleted? Reach out through the app's
              support contact and it will be handled directly.
            </p>
            <p className="mt-2 text-sm text-muted-foreground">
              Changes to this page will be posted here with a new date. Using Volume after a change
              means the updated policy applies.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}