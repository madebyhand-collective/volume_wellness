import React, { useEffect, useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { ChevronLeft, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Input } from '@/components/ui/input';
import Illustration from '@/components/Illustration';
import { useAuth } from '@/lib/AuthContext';
import { getProfile, DEFAULT_PREFERENCES, GOALS, EQUIPMENT, WORKOUT_TYPES, SESSION_LENGTHS, DAYS_PER_WEEK, invalidateVolumeCache } from '@/lib/volume';

export default function Onboarding() {
  const navigate = useNavigate();
  const { isAuthenticated, authChecked } = useAuth();
  const [checking, setChecking] = useState(true);
  const [hasProfile, setHasProfile] = useState(false);
  const [step, setStep] = useState(0);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);
  const [data, setData] = useState({
    name: '',
    goals: [],
    equipment: [],
    workout_types: [],
    days_per_week: 3,
    session_length: '20to30',
    cycle_tracking_enabled: false,
    assessment_time: '07:00',
    reflection_formats: { conversational: true, structured: true, cycle: false, ai_question: true },
  });

  useEffect(() => {
    getProfile().then((p) => {
      setHasProfile(!!p);
      setChecking(false);
    });
  }, []);

  if (checking) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-primary" />
      </div>
    );
  }
  // Setup can't be saved without an account — send anonymous visitors to
  // register first, then bring them right back to finish their setup.
  if (authChecked && !isAuthenticated) {
    return <Navigate to="/register?returnTo=%2Fonboarding" replace />;
  }
  if (hasProfile) return <Navigate to="/" replace />;

  const set = (k, v) => setData((d) => ({ ...d, [k]: v }));
  const steps = [
    {
      title: `First — what should we call you?`,
      canNext: data.name.trim().length > 0,
      render: () => (
        <Input
          autoFocus
          placeholder="Your name"
          value={data.name}
          onChange={(e) => set('name', e.target.value)}
          className="h-12 rounded-2xl text-lg"
        />
      ),
    },
    {
      title: 'What are you here for?',
      subtitle: 'Pick all that apply.',
      canNext: data.goals.length > 0,
      render: () => <MultiPicker list={GOALS} selected={data.goals} onToggle={(v) => set('goals', toggle(data.goals, v))} />,
    },
    {
      title: 'What do you have to work with?',
      subtitle: 'Equipment at home or the gym.',
      canNext: data.equipment.length > 0,
      render: () => <MultiPicker list={EQUIPMENT} selected={data.equipment} onToggle={(v) => set('equipment', toggle(data.equipment, v))} />,
    },
    {
      title: 'What kind of movement do you enjoy?',
      subtitle: 'Optional — your coach will blend it with your goals.',
      canNext: true,
      render: () => <MultiPicker list={WORKOUT_TYPES} selected={data.workout_types} onToggle={(v) => set('workout_types', toggle(data.workout_types, v))} />,
    },
    {
      title: 'How many days a week feel realistic?',
      subtitle: 'Honest answers make better plans.',
      canNext: true,
      render: () => (
        <div className="grid grid-cols-4 gap-2">
          {DAYS_PER_WEEK.map((opt) => (
            <button
              key={opt.value}
              type="button"
              onClick={() => set('days_per_week', opt.value)}
              className={`rounded-2xl border px-2 py-4 text-center text-xs font-medium transition-all ${
                data.days_per_week === opt.value ? 'border-primary bg-primary text-primary-foreground' : 'border-border bg-card text-foreground hover:bg-secondary'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      ),
    },
    {
      title: 'How long is a good session for you?',
      canNext: true,
      render: () => (
        <div className="grid grid-cols-3 gap-2">
          {SESSION_LENGTHS.map((opt) => (
            <button
              key={opt.value}
              type="button"
              onClick={() => set('session_length', opt.value)}
              className={`rounded-2xl border px-2 py-4 text-center text-xs font-medium transition-all ${
                data.session_length === opt.value ? 'border-primary bg-primary text-primary-foreground' : 'border-border bg-card text-foreground hover:bg-secondary'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      ),
    },
    {
      title: 'Wearables',
      subtitle: 'Connect a wearable later in Preferences — your check-in works fine without one.',
      canNext: true,
      render: () => (
        <p className="rounded-2xl bg-secondary p-4 text-sm text-secondary-foreground">
          In the mobile app, Volume can read heart rate, sleep, and HRV automatically. For now, your daily check-in covers it — skip this step.
        </p>
      ),
    },
    {
      title: 'Cycle tracking',
      subtitle: 'Optional. Volume can gently adjust your score by cycle phase — your call, your dial.',
      canNext: true,
      render: () => (
        <div className="flex items-center justify-between rounded-2xl bg-secondary p-4">
          <span className="text-sm font-medium text-secondary-foreground">Track my cycle</span>
          <button
            type="button"
            onClick={() => set('cycle_tracking_enabled', !data.cycle_tracking_enabled)}
            className={`h-7 w-12 rounded-full transition-colors ${data.cycle_tracking_enabled ? 'bg-primary' : 'bg-background border border-border'}`}
          >
            <span className={`block h-5 w-5 rounded-full bg-white shadow transition-transform ${data.cycle_tracking_enabled ? 'translate-x-6' : 'translate-x-1'}`} />
          </button>
        </div>
      ),
    },
    {
      title: 'When should your daily check-in land?',
      canNext: true,
      render: () => (
        <Input type="time" value={data.assessment_time} onChange={(e) => set('assessment_time', e.target.value)} className="h-12 rounded-2xl text-lg" />
      ),
    },
    {
      title: 'How do you want to reflect each week?',
      subtitle: 'Pick any combination — you can change this later.',
      canNext: true,
      render: () => (
        <div className="space-y-2">
          {[
            ['conversational', 'One honest question'],
            ['structured', 'Quick sliders + highlight'],
            ['cycle', 'Cycle phase reflection'],
            ['ai_question', 'AI question from my week'],
          ].map(([key, label]) => (
            <button
              key={key}
              type="button"
              onClick={() => set('reflection_formats', { ...data.reflection_formats, [key]: !data.reflection_formats[key] })}
              className={`flex w-full items-center justify-between rounded-2xl border px-4 py-3 text-sm font-medium ${
                data.reflection_formats[key] ? 'border-primary bg-primary text-primary-foreground' : 'border-border bg-card text-foreground'
              }`}
            >
              {label}
              <span>{data.reflection_formats[key] ? '✓' : ''}</span>
            </button>
          ))}
        </div>
      ),
    },
    {
      title: `Ready, ${data.name.trim().split(' ')[0]}.`,
      subtitle: 'Your coach will build your first plan around your answers — takes about a minute.',
      canNext: true,
      isFinal: true,
      render: () => null,
    },
  ];

  const cur = steps[step];

  const finish = async () => {
    setSaving(true);
    setError(null);
    try {
      const profile = await base44.entities.Profile.create({
        display_name: data.name.trim(),
        goals: data.goals,
        equipment: data.equipment,
        tier: 'free',
        active_plan_id: '',
        my_plan_ids: [],
        current_week: 1,
        day_index: 0,
        onboarding_completed: true,
      });
      await base44.entities.Preferences.create({
        ...DEFAULT_PREFERENCES,
        assessment_time: data.assessment_time,
        cycle_tracking_enabled: data.cycle_tracking_enabled,
        reflection_conversational: data.reflection_formats.conversational,
        reflection_structured: data.reflection_formats.structured,
        reflection_cycle: data.reflection_formats.cycle,
        reflection_ai_question: data.reflection_formats.ai_question,
      });
      try {
        const res = await base44.functions.invoke('generateWorkoutPlan', {
          goals: data.goals,
          workout_types: data.workout_types,
          days_per_week: data.days_per_week,
          session_length: data.session_length,
          equipment: data.equipment,
        });
        const plan = res.data && res.data.plan;
        if (plan) {
          await base44.entities.Profile.update(profile.id, {
            active_plan_id: plan.plan_id,
            my_plan_ids: [plan.plan_id],
          });
        }
        invalidateVolumeCache();
        navigate('/');
      } catch (genError) {
        invalidateVolumeCache();
        navigate('/plans');
      }
    } catch (e) {
      const detail = (e && (e.response?.data?.error || e.message)) || '';
      setError(
        detail
          ? `Something went wrong saving your setup — ${detail}`
          : 'Something went wrong saving your setup — try again.'
      );
      setSaving(false);
    }
  };

  const next = () => {
    if (cur.isFinal) { finish(); return; }
    setStep(step + 1);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto flex min-h-screen max-w-lg flex-col px-5 py-8">
        <div className="mb-6 flex items-center gap-3">
          {step > 0 && (
            <button type="button" onClick={() => setStep(step - 1)} className="rounded-full p-1.5 text-muted-foreground hover:bg-secondary">
              <ChevronLeft className="h-5 w-5" />
            </button>
          )}
          <Illustration motif="volumewordmark" color="sunset" className="h-7 md:h-8 w-auto" />
          <div className="ml-auto flex items-center gap-1.5" aria-hidden="true">
            {steps.map((_, i) => (
              <Illustration
                key={i}
                motif="starburst"
                color="sunset"
                className={`h-3.5 w-3.5 ${i <= step ? 'opacity-100' : 'opacity-30'}`}
              />
            ))}
          </div>
        </div>

        <div className="rounded-3xl border border-border bg-card p-6">
          <h1 className="font-heading text-2xl text-foreground md:text-3xl">{cur.title}</h1>
          {cur.subtitle && <p className="mt-1 text-sm text-muted-foreground">{cur.subtitle}</p>}
          <div className="mt-5">{cur.render()}</div>
          {error && <p className="mt-3 rounded-xl bg-accent px-3 py-2 text-sm text-accent-foreground">{error}</p>}
        </div>

        <div className="mt-auto pt-6">
          <button
            type="button"
            disabled={!cur.canNext || saving}
            onClick={next}
            className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-primary px-6 py-3.5 font-medium text-primary-foreground disabled:opacity-40"
          >
            {saving && <Loader2 className="h-4 w-4 animate-spin" />}
            {cur.isFinal ? (saving ? 'Setting things up…' : 'Start moving') : 'Continue'}
          </button>
        </div>
      </div>
    </div>
  );
}

function toggle(list, v) {
  return list.includes(v) ? list.filter((x) => x !== v) : [...list, v];
}

function MultiPicker({ list, selected, onToggle }) {
  return (
    <div className="grid grid-cols-3 gap-2">
      {list.map((opt) => (
        <button
          key={opt.value}
          type="button"
          onClick={() => onToggle(opt.value)}
          className={`rounded-2xl border px-2 py-4 text-center text-xs font-medium transition-all ${
            selected.includes(opt.value)
              ? 'border-primary bg-primary text-primary-foreground'
              : 'border-border bg-card text-foreground hover:bg-secondary'
          }`}
        >
          {opt.label}
        </button>
      ))}
    </div>
  );
}