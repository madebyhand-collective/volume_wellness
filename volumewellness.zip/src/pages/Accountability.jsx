import React, { useEffect, useState } from 'react';
import { ClipboardCheck, CalendarCheck2, CalendarX2, Hourglass } from 'lucide-react';
import { loadCommitments } from '@/lib/commitments';
import FollowThroughChart from '@/components/accountability/FollowThroughChart';
import MissedList from '@/components/accountability/MissedList';
import Illustration from '@/components/Illustration';

// Dedicated accountability dashboard: follow-through rate over time, a tally
// of kept vs missed promises, and the recent missed check-ins that show
// where things are falling short.
export default function Accountability() {
  const [items, setItems] = useState(null);
  const [loadError, setLoadError] = useState(false);

  useEffect(() => {
    let cancelled = false;
    loadCommitments()
      .then((list) => {
        if (!cancelled) setItems(list);
      })
      .catch(() => {
        if (!cancelled) setLoadError(true);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (loadError) {
    return (
      <div className="rounded-3xl border-2 border-sage bg-card p-8 text-center sticker">
        <h1 className="font-heading text-2xl text-foreground">Hold on a sec</h1>
        <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
          We couldn&apos;t load your promises. Give it a beat and try again.
        </p>
        <button
          type="button"
          onClick={() => window.location.reload()}
          className="mt-5 rounded-full border-2 border-sage bg-foreground px-6 py-3 text-sm font-bold text-primary-foreground"
        >
          Try again
        </button>
      </div>
    );
  }

  if (!items) {
    return (
      <div className="flex justify-center py-20">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-primary" />
      </div>
    );
  }

  const resolved = items.filter((c) => c.status !== 'pending');
  const kept = resolved.filter((c) => c.status === 'kept').length;
  const missed = resolved.filter((c) => c.status === 'missed').length;
  const pending = items.filter((c) => c.status === 'pending').length;
  const rate = kept + missed > 0 ? Math.round((kept / (kept + missed)) * 100) : null;

  const stats = [
    {
      label: 'Follow-through',
      value: rate === null ? '—' : `${rate}%`,
      icon: ClipboardCheck,
    },
    { label: 'Kept', value: kept, icon: CalendarCheck2 },
    { label: 'Missed', value: missed, icon: CalendarX2 },
    { label: 'Open promises', value: pending, icon: Hourglass },
  ];

  return (
    <div className="space-y-5">
      <div>
        <h1 className="flex items-center gap-3 font-heading text-3xl text-foreground">
          Accountability
          <Illustration motif="flowerpoticon" color="sunset" className="h-8 w-8" />
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Your word, tracked — how often the promises you made yourself actually happened.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {stats.map(({ label, value, icon: Icon }) => (
          <div key={label} className="sticker rounded-3xl bg-card p-4">
            <Icon className="h-5 w-5 text-primary" />
            <p className="mt-2 font-heading text-2xl text-foreground">{value}</p>
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{label}</p>
          </div>
        ))}
      </div>

      <div className="sticker rounded-3xl bg-card p-5">
        <h2 className="font-heading text-lg text-foreground">Follow-through by week</h2>
        <p className="mb-2 text-sm text-muted-foreground">
          The share of promises you kept, week by week.
        </p>
        <FollowThroughChart commitments={items} />
      </div>

      <div className="sticker rounded-3xl bg-card p-5">
        <h2 className="font-heading text-lg text-foreground">Recent missed check-ins</h2>
        <p className="mb-1 text-sm text-muted-foreground">
          Where things fell short — with the reason you gave at the time.
        </p>
        <MissedList commitments={items} />
      </div>
    </div>
  );
}