import React, { useEffect, useState } from 'react';
import { Navigate } from 'react-router-dom';

import ScoreHero from '@/components/home/ScoreHero';
import HomeInsights from '@/components/home/HomeInsights';
import StreakBadge from '@/components/home/StreakBadge';
import DailyCheckInModal from '@/components/assessment/DailyCheckInModal';
import TierDefinitionsDialog from '@/components/home/TierDefinitionsDialog';
import AccountabilityPanel from '@/components/home/AccountabilityPanel';
import PullToRefresh from '@/components/PullToRefresh';
import Illustration from '@/components/Illustration';
import { DEFAULT_NAME_MOTIF, getAccent, applyAppIcon } from '@/lib/name-style';
import { getProfile, getPreferences, getTodayAssessment, invalidateVolumeCache, TIERS } from '@/lib/volume';
import { logEvent } from '@/lib/behavioral';
import {
  isCheckInDismissed,
  getStoredReminder,
  clearStoredReminder,
} from '@/lib/checkin-reminder';

export default function Home() {
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState(null);
  const [prefs, setPrefs] = useState(null);
  const [assessment, setAssessment] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [loadError, setLoadError] = useState(false);
  const [reminder, setReminder] = useState(null);
  const [tierInfoOpen, setTierInfoOpen] = useState(false);

  const reload = () => {
    let cancelled = false;
    setLoadError(false);
    setLoading(true);
    (async () => {
      try {
        const [p, pr, a] = await Promise.all([getProfile(), getPreferences(), getTodayAssessment()]);
        if (cancelled) return;
        setProfile(p);
        setPrefs(pr);
        setAssessment(a);
        setReminder(getStoredReminder());
      } catch (e) {
        if (!cancelled) setLoadError(true);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  };

  useEffect(() => {
    reload();
  }, []);

  // Swap the browser-tab icon to the user's chosen mark once preferences load
  useEffect(() => {
    if (prefs) applyAppIcon(prefs.app_icon, prefs.home_accent_color);
  }, [prefs]);

  // Show the full-screen check-in popup on the first app open of the day
  useEffect(() => {
    if (!loading && profile && !assessment && !isCheckInDismissed()) {
      setModalOpen(true);
    }
  }, [loading, profile, assessment]);

  // Re-open the popup when the chosen reminder time passes
  useEffect(() => {
    const timer = setInterval(() => {
      const stored = getStoredReminder();
      if (stored && stored.due <= Date.now() && !assessment) {
        clearStoredReminder();
        setReminder(null);
        setModalOpen(true);
      }
    }, 15000);
    return () => clearInterval(timer);
  }, [assessment]);

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-primary" />
      </div>
    );
  }

  if (loadError) {
    return (
      <div className="rounded-3xl border-2 border-sage bg-card p-8 text-center sticker">
        <h2 className="font-heading text-2xl text-foreground">Hold on a sec</h2>
        <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
          We moved too fast and hit a limit. Give it a beat and try again.
        </p>
        <button
          type="button"
          onClick={() => reload()}
          className="mt-5 rounded-full border-2 border-sage bg-foreground px-6 py-3 text-sm font-bold text-primary-foreground"
        >
          Try again
        </button>
      </div>
    );
  }

  if (!profile) return <Navigate to="/onboarding" replace />;

  const reminderLabel = reminder
    ? new Date(reminder.due).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })
    : null;
  const nameMotif = (prefs && prefs.home_illustration) || DEFAULT_NAME_MOTIF;
  const accent = getAccent(prefs && prefs.home_accent_color);

  return (
    <PullToRefresh onRefresh={() => { invalidateVolumeCache(); reload(); }}>
    <div className="space-y-5">
      <DailyCheckInModal
        open={modalOpen}
        prefs={prefs}
        onComplete={(a) => {
          setAssessment(a);
          setModalOpen(false);
        }}
        onDismiss={() => setModalOpen(false)}
        onReminderSet={setReminder}
      />


      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <StreakBadge />
          <h1
            className="mt-2 flex items-center gap-3 font-heading text-4xl text-foreground"
            style={accent.text ? { color: accent.text } : undefined}
          >
            {profile.display_name}
            {nameMotif !== 'none' && (
              <Illustration motif={nameMotif} color={accent.id || 'sunset'} className="h-9 w-9" />
            )}

          </h1>
        </div>
        {assessment && TIERS[assessment.volume_score_tier] && (
          <button
            type="button"
            onClick={() => setTierInfoOpen(true)}
            aria-label={`Today's tier: ${TIERS[assessment.volume_score_tier].label}. Tap to see what each tier means.`}
            className={`rounded-full border-2 border-sage px-3 py-1.5 text-xs font-bold uppercase tracking-wide ${TIERS[assessment.volume_score_tier].chip} hover:opacity-90`}
          >
            {TIERS[assessment.volume_score_tier].label}
          </button>
        )}
      </div>

      <TierDefinitionsDialog
        open={tierInfoOpen}
        onOpenChange={setTierInfoOpen}
        currentTier={assessment ? assessment.volume_score_tier : null}
      />

      <AccountabilityPanel refreshKey={assessment ? assessment.id : 'none'} />

      {assessment ? (
        <div className="space-y-5">
          <ScoreHero assessment={assessment} prefs={prefs} />
          <HomeInsights />
        </div>
      ) : (
        <div className="space-y-5">
          <div className="rounded-3xl border-2 border-sage bg-card p-8 text-center sticker">
            <Illustration motif="facevase" color="sunset" className="mx-auto h-16 w-16" />
            <h2 className="mt-2 font-heading text-2xl text-foreground">Today&apos;s check-in is waiting</h2>
            <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
              Tell us how you&apos;re doing and we&apos;ll tune today&apos;s plan to how you actually feel.
            </p>
            {reminderLabel && (
              <p className="mt-3 text-sm font-semibold text-foreground">
                We&apos;ll nudge you at {reminderLabel}
              </p>
            )}
            <button
              type="button"
              onClick={async () => {
                await logEvent('assessment_opened');
                setModalOpen(true);
              }}
              className="mt-5 rounded-full border-2 border-sage bg-foreground px-6 py-3 text-sm font-bold text-primary-foreground"
            >
              Do the check-in
            </button>
          </div>
        </div>
      )}
    </div>
    </PullToRefresh>
  );
}