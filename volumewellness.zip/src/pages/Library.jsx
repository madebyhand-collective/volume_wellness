import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useToast } from '@/components/ui/use-toast';
import { getPreferences, DEFAULT_PREFERENCES, invalidateVolumeCache } from '@/lib/volume';
import { BLOCK_CATEGORIES, categorizeBlock } from '@/lib/blocks';
import BlockCard from '@/components/library/BlockCard';
import RecurDialog from '@/components/library/RecurDialog';
import Illustration from '@/components/Illustration';

export default function Library() {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [blocks, setBlocks] = useState([]);
  const [prefs, setPrefs] = useState(null);
  const [recurTarget, setRecurTarget] = useState(null);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const [b, p] = await Promise.all([base44.entities.SessionBlock.list(), getPreferences()]);
      if (cancelled) return;
      setBlocks(b);
      setPrefs(p || { ...DEFAULT_PREFERENCES, recurring_blocks: [] });
      setLoading(false);
    })();
    return () => { cancelled = true; };
  }, []);

  const recurringByBlock = {};
  (((prefs && prefs.recurring_blocks) || []).filter(Boolean)).forEach((r) => { recurringByBlock[r.block_id] = r; });

  const saveRecurring = async (entry) => {
    const list = ((prefs.recurring_blocks) || []).filter(Boolean);
    const idx = list.findIndex((r) => r.block_id === entry.block_id);
    let next;
    if (!entry.days.length) {
      next = list.filter((r) => r.block_id !== entry.block_id);
    } else if (idx >= 0) {
      next = list.map((r, i) => (i === idx ? entry : r));
    } else {
      next = [...list, entry];
    }
    try {
      let updatedPrefs;
      if (prefs.id) {
        await base44.entities.Preferences.update(prefs.id, { recurring_blocks: next });
        updatedPrefs = { ...prefs, recurring_blocks: next };
      } else {
        const created = await base44.entities.Preferences.create({ ...DEFAULT_PREFERENCES, recurring_blocks: next });
        updatedPrefs = { ...prefs, id: created.id, recurring_blocks: next };
      }
      invalidateVolumeCache();
      setPrefs(updatedPrefs);
      toast({
        title: entry.days.length
          ? `${entry.type === 'warmup' ? 'Warmup' : 'Cooldown'} set to repeat.`
          : 'No longer repeating.',
      });
    } catch (e) {
      toast({ title: 'Could not save that — try again.', variant: 'destructive' });
    }
    setRecurTarget(null);
  };

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-secondary border-t-primary" />
      </div>
    );
  }

  const categorized = BLOCK_CATEGORIES.map((cat) => ({
    ...cat,
    items: blocks.filter((b) => categorizeBlock(b) === cat.id),
  })).filter((cat) => cat.items.length > 0);
  const visible = filter === 'all' ? categorized : categorized.filter((c) => c.id === filter);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="flex items-center gap-3 font-heading text-3xl text-foreground">
          Movement library
          <Illustration motif="starflower" color="sunset" className="h-9 w-9" />
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Mobility flows and physical-therapy routines — use them as warmups, cooldowns, or on their own.
        </p>
      </div>

      <div className="flex flex-wrap gap-2">
        {[{ id: 'all', label: 'All' }, ...categorized].map((c) => (
          <button
            key={c.id}
            type="button"
            onClick={() => setFilter(c.id)}
            className={`rounded-full px-4 py-2 text-xs font-semibold ${
              filter === c.id
                ? 'bg-primary text-primary-foreground'
                : 'border border-border bg-card text-foreground hover:bg-secondary'
            }`}
          >
            {c.label}
          </button>
        ))}
      </div>

      {visible.map((cat) => (
        <section key={cat.id} className="space-y-3">
          <div>
            <h2 className="font-heading text-xl text-foreground">{cat.label}</h2>
            <p className="text-xs text-muted-foreground">{cat.blurb}</p>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            {cat.items.map((block) => (
              <BlockCard
                key={block.id}
                block={block}
                recurring={recurringByBlock[block.block_id]}
                onRecur={setRecurTarget}
                onDoNow={(b) => navigate(`/library/block/${b.block_id}`)}
              />
            ))}
          </div>
        </section>
      ))}

      <RecurDialog
        block={recurTarget}
        entry={recurTarget ? recurringByBlock[recurTarget.block_id] : null}
        onSave={saveRecurring}
        onClose={() => setRecurTarget(null)}
      />
    </div>
  );
}