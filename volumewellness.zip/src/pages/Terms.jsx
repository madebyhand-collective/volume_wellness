import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, Scale, Activity, CircleCheck, RefreshCw, CreditCard, Bell, Ban, FileText } from 'lucide-react';
import Illustration from '@/components/Illustration';

const SECTIONS = [
  {
    icon: Activity,
    title: 'What Volume is',
    points: [
      'Volume provides general fitness, mobility, and wellness guidance adapted to your daily check-ins',
      'Content is educational and motivational — it is not medical advice, diagnosis, or treatment',
      'Volume is not a substitute for guidance from a qualified healthcare professional',
    ],
  },
  {
    icon: CircleCheck,
    title: 'Your account',
    points: [
      'You must provide accurate sign-up information and keep your credentials secure',
      'You are responsible for activity that happens through your account',
      'Accounts are for personal use; sharing one account across multiple people is not supported',
    ],
  },
  {
    icon: RefreshCw,
    title: 'Acceptable use',
    points: [
      'Use the app for its intended purpose — tracking and supporting your own training',
      'Do not attempt to access other users\u2019 data, disrupt the service, or reverse-engineer it',
      'Do not upload content that is unlawful, harmful, or infringes on others\u2019 rights',
    ],
  },
  {
    icon: CreditCard,
    title: 'Plans, features, and billing',
    points: [
      'Some features may be offered through paid membership tiers; any paid terms will be shown clearly before purchase',
      'Memberships can be canceled per the terms shown at sign-up',
      'Features may evolve — Volume may add, change, or retire features over time',
    ],
  },
  {
    icon: Bell,
    title: 'Check-ins, reminders, and reflections',
    points: [
      'Reminders and insights are prompts, not obligations — you decide what to act on',
      'Skipping check-ins or sessions may change how insights are generated, since patterns need data',
      'AI-generated insights and reflections are suggestions to consider, not professional guidance',
    ],
  },
  {
    icon: Ban,
    title: 'Fitness responsibility',
    points: [
      'Consult a healthcare professional before starting any new exercise program',
      'Stop and seek medical attention if you experience pain, dizziness, or shortness of breath',
      'You assume the risks of physical activity inherent in any training program',
    ],
  },
  {
    icon: FileText,
    title: 'Intellectual property',
    points: [
      'The Volume app, its branding, plans, and content are owned by Volume or its licensors',
      'Your personal check-in data and notes remain yours',
      'You may not copy, redistribute, or resell Volume\u2019s content without permission',
    ],
  },
  {
    icon: Scale,
    title: 'Termination and changes',
    points: [
      'You can stop using Volume and delete your account at any time',
      'Accounts that violate these terms may be suspended',
      'These terms may be updated; material changes will be posted with a new date',
    ],
  },
];

export default function Terms() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto max-w-2xl px-5 py-8">
        <div className="mb-6 flex items-center gap-3">
          <button
            type="button"
            onClick={() => navigate(-1)}
            className="rounded-full p-1.5 text-muted-foreground hover:bg-secondary"
            aria-label="Back"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <Illustration motif="volumewordmark" color="sunset" className="h-7 md:h-8 w-auto" />
        </div>

        <div className="rounded-3xl border-2 border-sage bg-card p-6 md:p-8 sticker">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-primary/10 px-3 py-1 text-xs font-bold uppercase tracking-wide text-primary">
            <Scale className="h-3.5 w-3.5" aria-hidden="true" />
            Terms
          </span>
          <h1 className="mt-3 font-heading text-3xl text-foreground md:text-4xl">
            The ground rules
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Simple, honest terms for using Volume — what it offers, what it does not, and what is
            expected in return.
          </p>
          <p className="mt-3 text-xs uppercase tracking-wide text-muted-foreground">
            Last updated: September 25, 2026
          </p>
        </div>

        <div className="mt-5 space-y-4">
          {SECTIONS.map(({ icon: Icon, title, points }) => (
            <section key={title} className="rounded-3xl border-2 border-sage bg-card p-6">
              <h2 className="flex items-center gap-2.5 font-heading text-xl text-foreground">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                  <Icon className="h-4 w-4" aria-hidden="true" />
                </span>
                {title}
              </h2>
              <ul className="mt-3 space-y-2">
                {points.map((point) => (
                  <li key={point} className="flex gap-2.5 text-sm text-foreground/80">
                    <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" aria-hidden="true" />
                    {point}
                  </li>
                ))}
              </ul>
            </section>
          ))}

          <section className="rounded-3xl border-2 border-sage bg-card p-6">
            <h2 className="font-heading text-xl text-foreground">Questions</h2>
            <p className="mt-2 text-sm text-foreground/80">
              If anything here is unclear, reach out through the app&rsquo;s support contact.
              Using Volume after a change to these terms means the updated version applies.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}