// Shared OAuth + data-sync helpers for cloud wearables (Oura, Google Health),
// used by the *Auth and sync* backend functions.

export const OURA_AUTHORIZE_URL = 'https://cloud.ouraring.com/oauth/authorize';
export const OURA_TOKEN_URL = 'https://api.ouraring.com/v1/oauth/token';
export const OURA_API_BASE = 'https://api.ouraring.com/v2/usercollection';
export const OURA_SCOPES = 'daily';

export function ouraAuthorizeUrl(clientId, redirectUri) {
  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri,
    response_type: 'code',
    scope: OURA_SCOPES,
  });
  return `${OURA_AUTHORIZE_URL}?${params.toString()}`;
}

export async function ouraTokenRequest(params) {
  const res = await fetch(OURA_TOKEN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams(params).toString(),
  });
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`Oura token request failed (${res.status}): ${text.slice(0, 200)}`);
  }
  return await res.json();
}

// Refresh the stored access token when it is expired (or about to be).
export async function ensureFreshToken(base44, conn, clientId, clientSecret) {
  const expiresAt = conn.expires_at ? new Date(conn.expires_at).getTime() : 0;
  if (expiresAt > Date.now() + 60000) return conn;
  const tokens = await ouraTokenRequest({
    grant_type: 'refresh_token',
    refresh_token: conn.refresh_token,
    client_id: clientId,
    client_secret: clientSecret,
  });
  const updated = {
    access_token: tokens.access_token,
    refresh_token: tokens.refresh_token || conn.refresh_token,
    expires_at: new Date(Date.now() + (tokens.expires_in || 86400) * 1000).toISOString(),
  };
  await base44.entities.WearableConnection.update(conn.id, updated);
  return { ...conn, ...updated };
}

async function fetchOuraDocs(accessToken, path, start, end) {
  const params = new URLSearchParams({ start, end });
  const res = await fetch(`${OURA_API_BASE}${path}?${params.toString()}`, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (!res.ok) throw new Error(`Oura ${path} request failed (${res.status})`);
  const body = await res.json();
  return body.data || [];
}

// Pull the last three days of sleep + readiness for one connection and
// upsert them into BiometricDaily. Returns the number of days written.
// `base44` must be a service-role client.
export async function syncOuraConnection(base44, conn, clientId, clientSecret) {
  const fresh = await ensureFreshToken(base44, conn, clientId, clientSecret);
  const iso = (d) => d.toISOString().slice(0, 10);
  const start = new Date(Date.now() - 2 * 86400000);
  const end = new Date(Date.now() + 1 * 86400000);
  const [sleeps, readinessDocs] = await Promise.all([
    fetchOuraDocs(fresh.access_token, '/sleep', iso(start), iso(end)),
    fetchOuraDocs(fresh.access_token, '/readiness', iso(start), iso(end)),
  ]);

  // Main sleep only — skip naps.
  const sleepByDay = new Map();
  for (const s of sleeps) {
    if (s.type && s.type !== 'long_sleep') continue;
    sleepByDay.set(s.day, s);
  }

  const nowIso = new Date().toISOString();
  const days = new Set([...sleepByDay.keys(), ...readinessDocs.map((r) => r.day)]);
  let upserted = 0;
  for (const day of days) {
    const sleep = sleepByDay.get(day) || {};
    const readiness = readinessDocs.find((r) => r.day === day) || {};
    const record = {
      date: day,
      provider: 'oura',
      readiness_score: typeof readiness.score === 'number' ? readiness.score : null,
      sleep_score: typeof sleep.score === 'number' ? sleep.score : null,
      hrv_ms: typeof sleep.average_hrv === 'number' ? sleep.average_hrv : null,
      resting_hr: typeof sleep.lowest_heart_rate === 'number' ? sleep.lowest_heart_rate : null,
      sleep_duration_hours: typeof sleep.duration === 'number' ? sleep.duration / 3600 : null,
      temperature_deviation: typeof readiness.temperature_deviation === 'number' ? readiness.temperature_deviation : null,
      last_synced_at: nowIso,
    };
    const existing = await base44.entities.BiometricDaily.filter({
      created_by_id: conn.created_by_id,
      provider: 'oura',
      date: day,
    });
    if (existing[0]) {
      await base44.entities.BiometricDaily.update(existing[0].id, record);
    } else {
      await base44.entities.BiometricDaily.create({ ...record, created_by_id: conn.created_by_id });
    }
    upserted += 1;
  }

  await base44.entities.WearableConnection.update(fresh.id, { last_synced_at: nowIso });
  return upserted;
}

// --- Google Health API (Fitbit / Pixel Watch) ---

export const GOOGLE_AUTHORIZE_URL = 'https://accounts.google.com/o/oauth2/v2/auth';
export const GOOGLE_TOKEN_URL = 'https://oauth2.googleapis.com/token';
export const GOOGLE_HEALTH_API_BASE = 'https://health.googleapis.com/v4/users/me/dataTypes';
export const GOOGLE_HEALTH_SCOPES = [
  'https://www.googleapis.com/auth/googlehealth.sleep.readonly',
  'https://www.googleapis.com/auth/googlehealth.health_metrics_and_measurements.readonly',
].join(' ');

export function googleAuthorizeUrl(clientId, redirectUri) {
  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri,
    response_type: 'code',
    access_type: 'offline',
    prompt: 'consent',
    scope: GOOGLE_HEALTH_SCOPES,
  });
  return `${GOOGLE_AUTHORIZE_URL}?${params.toString()}`;
}

export async function googleTokenRequest(params) {
  const res = await fetch(GOOGLE_TOKEN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams(params).toString(),
  });
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`Google token request failed (${res.status}): ${text.slice(0, 200)}`);
  }
  return await res.json();
}

// Refresh the stored Google access token when it is expired (or about to be).
export async function ensureFreshGoogleToken(base44, conn, clientId, clientSecret) {
  const expiresAt = conn.expires_at ? new Date(conn.expires_at).getTime() : 0;
  if (expiresAt > Date.now() + 60000) return conn;
  const tokens = await googleTokenRequest({
    grant_type: 'refresh_token',
    refresh_token: conn.refresh_token,
    client_id: clientId,
    client_secret: clientSecret,
  });
  const updated = {
    access_token: tokens.access_token,
    refresh_token: tokens.refresh_token || conn.refresh_token,
    expires_at: new Date(Date.now() + (tokens.expires_in || 3600) * 1000).toISOString(),
  };
  await base44.entities.WearableConnection.update(conn.id, updated);
  return { ...conn, ...updated };
}

async function fetchGoogleDataPoints(accessToken, dataType, filter) {
  const params = new URLSearchParams({ filter });
  const res = await fetch(`${GOOGLE_HEALTH_API_BASE}/${dataType}/dataPoints?${params.toString()}`, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (!res.ok) throw new Error(`Google Health ${dataType} request failed (${res.status})`);
  const body = await res.json();
  return body.dataPoints || [];
}

const toNumber = (v) => {
  if (v == null) return null;
  const n = typeof v === 'string' ? parseFloat(v) : Number(v);
  return Number.isFinite(n) ? n : null;
};

// Daily data points carry one union object (e.g. dp.dailyHeartRateVariability);
// field names vary slightly per type, so try known keys first.
function extractDailyValue(dp, unionKey, candidateKeys) {
  const obj = dp?.[unionKey] || {};
  for (const key of candidateKeys) {
    const n = toNumber(obj[key]);
    if (n != null) return n;
  }
  return null;
}

// Pull the last few days of sleep, HRV, resting heart rate, and sleep-skin
// temperature for one connection and upsert them into BiometricDaily.
// `base44` must be a service-role client.
export async function syncGoogleHealthConnection(base44, conn, clientId, clientSecret) {
  const fresh = await ensureFreshGoogleToken(base44, conn, clientId, clientSecret);
  const iso = (d) => d.toISOString();
  const day = (d) => d.toISOString().slice(0, 10);
  const start = new Date(Date.now() - 3 * 86400000);
  const end = new Date(Date.now() + 1 * 86400000);
  const dailyFilter = (unionKey) => `${unionKey}.date >= "${day(start)}" AND ${unionKey}.date < "${day(end)}"`;

  const [sleeps, hrvs, rhrs, temps] = await Promise.all([
    fetchGoogleDataPoints(fresh.access_token, 'sleep',
      `sleep.interval.end_time >= "${iso(start)}" AND sleep.interval.end_time < "${iso(end)}"`),
    fetchGoogleDataPoints(fresh.access_token, 'daily-heart-rate-variability', dailyFilter('dailyHeartRateVariability')),
    fetchGoogleDataPoints(fresh.access_token, 'daily-resting-heart-rate', dailyFilter('dailyRestingHeartRate')),
    fetchGoogleDataPoints(fresh.access_token, 'daily-sleep-temperature-derivations', dailyFilter('dailySleepTemperatureDerivations')),
  ]);

  // Longest sleep session per wake-up day — skips naps.
  const sleepByDay = new Map();
  for (const dp of sleeps) {
    const s = dp.sleep || {};
    const endStr = (s.interval || {}).endTime;
    if (!endStr) continue;
    const wakeDay = endStr.slice(0, 10);
    const minutesAsleep = toNumber((s.summary || {}).minutesAsleep);
    const prev = sleepByDay.get(wakeDay);
    if (prev == null || (minutesAsleep != null && minutesAsleep > prev)) sleepByDay.set(wakeDay, minutesAsleep);
  }

  const dailyByDay = new Map();
  const recordDaily = (dp, unionKey, keys, field) => {
    const date = (dp?.[unionKey] || {}).date;
    if (!date) return;
    const value = extractDailyValue(dp, unionKey, keys);
    if (value == null) return;
    if (!dailyByDay.has(date)) dailyByDay.set(date, {});
    dailyByDay.get(date)[field] = value;
  };
  for (const dp of hrvs) recordDaily(dp, 'dailyHeartRateVariability', ['averageHeartRateVariabilityMilliseconds', 'rmssdMilliseconds', 'rmssd'], 'hrv_ms');
  for (const dp of rhrs) recordDaily(dp, 'dailyRestingHeartRate', ['averageRestingHeartRateBeatsPerMinute', 'restingHeartRate', 'beatsPerMinute'], 'resting_hr');
  for (const dp of temps) recordDaily(dp, 'dailySleepTemperatureDerivations', ['skinTemperatureDerivationCelsius', 'temperatureDerivationCelsius', 'temperatureDerivation'], 'temperature_deviation');

  const nowIso = new Date().toISOString();
  const days = new Set([...sleepByDay.keys(), ...dailyByDay.keys()]);
  let upserted = 0;
  for (const date of days) {
    const minutesAsleep = sleepByDay.get(date);
    const daily = dailyByDay.get(date) || {};
    const record = {
      date,
      provider: 'google_health',
      readiness_score: null,
      sleep_score: null,
      hrv_ms: daily.hrv_ms ?? null,
      resting_hr: daily.resting_hr ?? null,
      sleep_duration_hours: minutesAsleep != null ? minutesAsleep / 60 : null,
      temperature_deviation: daily.temperature_deviation ?? null,
      last_synced_at: nowIso,
    };
    const existing = await base44.entities.BiometricDaily.filter({
      created_by_id: conn.created_by_id,
      provider: 'google_health',
      date,
    });
    if (existing[0]) {
      await base44.entities.BiometricDaily.update(existing[0].id, record);
    } else {
      await base44.entities.BiometricDaily.create({ ...record, created_by_id: conn.created_by_id });
    }
    upserted += 1;
  }

  await base44.entities.WearableConnection.update(fresh.id, { last_synced_at: nowIso });
  return upserted;
}