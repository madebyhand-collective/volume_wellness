import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';
import { secrets } from 'base44:runtime';
import { syncGoogleHealthConnection } from '../../shared/wearables.ts';

// Daily Google Health sync: refreshes tokens, pulls the last few days of
// sleep, HRV, resting heart rate, and sleep temperature for every connected
// user, and upserts BiometricDaily. Admin-only (invoked by the scheduled
// "Google Health Sync" workflow); supports { dryRun: true } to report scope
// without calling Google.
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const caller = await base44.auth.me();
    if (!caller || caller.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }
    const body = await req.json().catch(() => ({}));
    const dryRun = body.dryRun === true;

    const clientId = secrets.get('GOOGLE_HEALTH_CLIENT_ID');
    const clientSecret = secrets.get('GOOGLE_HEALTH_CLIENT_SECRET');
    const conns = await base44.asServiceRole.entities.WearableConnection.list('-created_date', 500);
    const googleConns = conns.filter((c) => c.provider === 'google_health');

    const results = [];
    if (!dryRun) {
      for (const conn of googleConns) {
        try {
          const upserted = await syncGoogleHealthConnection(base44.asServiceRole, conn, clientId, clientSecret);
          results.push({ connection: conn.id, user: conn.created_by_id, upserted, ok: true });
        } catch (error) {
          results.push({ connection: conn.id, user: conn.created_by_id, ok: false, error: error.message });
        }
      }
    }

    return Response.json({ connections: googleConns.length, dryRun, results });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}