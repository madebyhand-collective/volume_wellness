import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({})) || {};
    const cleanList = (v, max) => (Array.isArray(v) ? v.map((x) => String(x || '').slice(0, 60).trim()).filter(Boolean).slice(0, max) : []);
    const goals = cleanList(body.goals, 5);
    const workoutTypes = cleanList(body.workout_types, 5);
    const equipment = cleanList(body.equipment, 10);
    const daysPerWeek = Math.min(6, Math.max(1, Number(body.days_per_week) || 3));
    const weeks = Math.min(6, Math.max(2, Number(body.weeks) || 4));
    const sessionLength = ['under20', '20to30', '30plus'].includes(body.session_length) ? body.session_length : '20to30';
    if (!goals.length) return Response.json({ error: 'Pick at least one goal.' }, { status: 400 });
    const whyItMatters = String(body.why_it_matters || '').slice(0, 200).trim();

    // Global excluded-exercise list lives in the user's Preferences
    const prefList = await base44.entities.Preferences.list();
    const excluded = cleanList(prefList && prefList[0] && prefList[0].excluded_exercises, 50);

    const sessionLabel = sessionLength === 'under20' ? 'under 20 minutes' : sessionLength === '20to30' ? '20 to 30 minutes' : '30 minutes or more';
    const exerciseCount = sessionLength === 'under20' ? '3 to 4' : sessionLength === '20to30' ? '4 to 5' : '5 to 6';

    const llm = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt: `You are Volume's assistant coach — an expert, evidence-based strength and conditioning programmer with current knowledge of exercise selection, set and rep schemes, rest periods, and the most effective methods for reaching a given goal.

Build a complete ${weeks}-week progressive workout plan for this person.

Goals: ${goals.join(', ')}
Preferred workout types: ${workoutTypes.length ? workoutTypes.join(', ') : 'no preference — choose what best serves the goals'}
Available equipment: ${equipment.length ? equipment.join(', ') : 'bodyweight only'}
Training days per week: exactly ${daysPerWeek}
Typical session length: ${sessionLabel}
Excluded exercises (NEVER include these or close variations of them): ${excluded.length ? excluded.join(', ') : 'none'}

Programming rules:
- Every week has exactly ${daysPerWeek} days. Label each day by its focus (e.g. "Full Body A", "Lower Body + Core").
- Select only exercises the available equipment allows (bodyweight is always allowed).
- Use current exercise science for the goals: compound-first selection, goal-appropriate set/rep schemes and rest periods (strength: 4-8 reps, 2-3 min rest; muscle and stamina: 8-15 reps, 45-90s rest; circuits: short or no rest).
- Progress the plan gently across weeks with progressive overload.
- Core work only — no warmup or cooldown days; the app adds those itself.
- ${exerciseCount} exercises per day, each with a rest field like "60-90s".
- Give the plan a short friendly name (lowercase is fine) and a one-sentence warm description.

Return JSON only.`,
      response_json_schema: {
        type: 'object',
        properties: {
          name: { type: 'string' },
          description: { type: 'string' },
          difficulty: { type: 'string' },
          tags: { type: 'array', items: { type: 'string' } },
          weeks: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                week_number: { type: 'integer' },
                days: {
                  type: 'array',
                  items: {
                    type: 'object',
                    properties: {
                      label: { type: 'string' },
                      exercises: {
                        type: 'array',
                        items: {
                          type: 'object',
                          properties: {
                            name: { type: 'string' },
                            sets: { type: 'integer' },
                            reps: { type: 'string' },
                            rest: { type: 'string' },
                            section: { type: 'string' },
                          },
                          required: ['name', 'sets', 'reps'],
                        },
                      },
                    },
                    required: ['label', 'exercises'],
                  },
                },
              },
              required: ['week_number', 'days'],
            },
          },
        },
        required: ['name', 'weeks'],
      },
    });

    if (!llm || !Array.isArray(llm.weeks) || !llm.weeks.length) {
      return Response.json({ error: 'The coach could not build a plan from those answers — try again.' }, { status: 502 });
    }

    const planId = `ai-${Date.now()}`;
    const dayRecords = [];
    let weekCounter = 0;
    llm.weeks.slice(0, weeks).forEach((w) => {
      weekCounter += 1;
      (w.days || []).slice(0, 6).forEach((d, idx) => {
        const exercises = (d.exercises || []).slice(0, 8).map((ex, i) => ({
          id: `${planId}-w${weekCounter}d${idx + 1}e${i + 1}`,
          name: String(ex.name || 'Exercise').slice(0, 80),
          sets: Math.min(Math.max(Number(ex.sets) || 3, 1), 8),
          reps: String(ex.reps || '').slice(0, 30),
          rest: String(ex.rest || '').slice(0, 30),
          section: String(ex.section || '').slice(0, 40),
          video_url: '',
        }));
        if (!exercises.length) return;
        dayRecords.push({
          plan_id: planId,
          week_number: weekCounter,
          phase: 1,
          day_id: `${planId}-w${weekCounter}d${idx + 1}`,
          day_index: idx,
          label: String(d.label || `Day ${idx + 1}`).slice(0, 60),
          emoji: '',
          exercises,
        });
      });
    });

    if (!dayRecords.length) {
      return Response.json({ error: 'The coach came back with an empty plan — try again.' }, { status: 502 });
    }

    const perWeek = {};
    dayRecords.forEach((d) => { perWeek[d.week_number] = (perWeek[d.week_number] || 0) + 1; });
    const maxWeek = Math.max(...dayRecords.map((d) => d.week_number));
    const summary = await base44.entities.PlanSummary.create({
      plan_id: planId,
      name: String(llm.name || 'Your plan').slice(0, 60),
      description: String(llm.description || 'Built by your Volume coach around your goals.').slice(0, 200),
      difficulty: String(llm.difficulty || 'Personalized').slice(0, 30),
      duration: `${maxWeek} weeks`,
      days_per_week: Math.max(...Object.values(perWeek)),
      tags: cleanList(llm.tags, 5).concat(['AI plan']),
      why_it_matters: whyItMatters,
      access: 'free',
      is_custom: true,
    });

    for (let i = 0; i < dayRecords.length; i += 50) {
      await base44.entities.PlanDay.bulkCreate(dayRecords.slice(i, i + 50));
    }

    return Response.json({ plan: summary, days_created: dayRecords.length });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}