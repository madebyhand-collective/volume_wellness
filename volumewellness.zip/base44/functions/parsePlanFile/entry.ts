import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }
    const body = await req.json().catch(() => ({}));
    const { file_url, name } = body || {};
    if (!file_url || !name || !String(name).trim()) {
      return Response.json({ error: 'A file and plan name are required.' }, { status: 400 });
    }

    const extract = await base44.asServiceRole.integrations.Core.ExtractDataFromUploadedFile({
      file_url,
      json_schema: {
        type: 'object',
        properties: {
          rows: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                week: { type: 'integer' },
                phase: { type: 'integer' },
                day_label: { type: 'string' },
                day_emoji: { type: 'string' },
                exercise_name: { type: 'string' },
                sets: { type: 'integer' },
                reps: { type: 'string' },
                section: { type: 'string' },
                video_url: { type: 'string' },
              },
              required: ['week', 'day_label', 'exercise_name', 'sets', 'reps'],
            },
          },
        },
        required: ['rows'],
      },
    });

    if (extract.status !== 'success' || !extract.output || !Array.isArray(extract.output.rows)) {
      return Response.json({ error: (extract && extract.details) || 'Could not read that file.' }, { status: 400 });
    }
    const rows = extract.output.rows.slice(0, 1000);
    if (!rows.length) {
      return Response.json({ error: 'No workout rows found in that file. Expected columns: Week, Phase, Day Label, Day Emoji, Exercise Name, Sets, Reps.' }, { status: 400 });
    }

    // Only http(s) video URLs are allowed — blocks javascript:/data: scheme injection from uploaded files
    const safeVideoUrl = (u) => (/^https?:\/\//i.test(String(u || '')) ? String(u) : '');

    const planId = `custom-${Date.now()}`;
    const dayMap = new Map();
    rows.forEach((r) => {
      const week = Number(r.week) || 1;
      const key = `${week}::${r.day_label}`;
      if (!dayMap.has(key)) {
        dayMap.set(key, { week, phase: Number(r.phase) || 1, label: r.day_label, emoji: r.day_emoji || '🏋️', exercises: [] });
      }
      const day = dayMap.get(key);
      day.exercises.push({
        id: `${planId}-w${week}d${day.exercises.length + 1}e${day.exercises.length + 1}`,
        name: r.exercise_name,
        sets: Number(r.sets) || 3,
        reps: r.reps || '',
        section: r.section || '',
        video_url: safeVideoUrl(r.video_url),
      });
    });

    const weekCounts = {};
    const dayRecords = [];
    [...dayMap.values()].forEach((d) => {
      const idx = weekCounts[d.week] || 0;
      weekCounts[d.week] = idx + 1;
      dayRecords.push({
        plan_id: planId,
        week_number: d.week,
        phase: d.phase,
        day_id: `${planId}-w${d.week}d${idx + 1}`,
        day_index: idx,
        label: d.label,
        emoji: d.emoji,
        exercises: d.exercises,
      });
    });

    const maxWeek = Math.max(...dayRecords.map((d) => d.week_number));
    const maxDays = Math.max(...Object.values(weekCounts));
    const summary = await base44.entities.PlanSummary.create({
      plan_id: planId,
      name: String(name).trim().slice(0, 80),
      description: 'Your uploaded plan',
      difficulty: 'Custom',
      duration: `${maxWeek} week${maxWeek > 1 ? 's' : ''}`,
      days_per_week: maxDays,
      tags: ['Custom'],
      access: 'free',
      is_custom: true,
    });

    for (let i = 0; i < dayRecords.length; i += 50) {
      await base44.entities.PlanDay.bulkCreate(dayRecords.slice(i, i + 50));
    }

    return Response.json({ plan: summary, days_created: dayRecords.length });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}