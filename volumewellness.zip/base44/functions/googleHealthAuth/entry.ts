import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';
import { secrets } from 'base44:runtime';
import { googleAuthorizeUrl, googleTokenRequest, GOOGLE_HEALTH_SCOPES } from '../../shared/wearables.ts';

// Google Health OAuth flow (Fitbit / Pixel Watch). Visiting the endpoint
// without a code starts the flow (redirect to Google's consent screen);
// Google's callback with ?code= exchanges the code for tokens and saves the
// connection for the signed-in user.
export default async function (req) {
  const url = new URL(req.url);
  const preferencesUrl = `${url.origin}/preferences`;
  try {
    const clientId = secrets.get('GOOGLE_HEALTH_CLIENT_ID');
    const clientSecret = secrets.get('GOOGLE_HEALTH_CLIENT_SECRET');
    const redirectUri = `${url.origin}/functions/googleHealthAuth`;
    const code = url.searchParams.get('code');

    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch(() => null);
    if (!user) return Response.redirect(`${url.origin}/login`, 302);

    // Step 1: start the flow. prompt=consent ensures we get a refresh token.
    if (!code) {
      return Response.redirect(googleAuthorizeUrl(clientId, redirectUri), 302);
    }

    // Step 2: exchange the authorization code for tokens.
    const tokens = await googleTokenRequest({
      grant_type: 'authorization_code',
      code,
      client_id: clientId,
      client_secret: clientSecret,
      redirect_uri: redirectUri,
    });
    if (!tokens.refresh_token) {
      throw new Error('Google did not return a refresh token');
    }

    const payload = {
      provider: 'google_health',
      access_token: tokens.access_token,
      refresh_token: tokens.refresh_token,
      expires_at: new Date(Date.now() + (tokens.expires_in || 3600) * 1000).toISOString(),
      scopes: tokens.scope || GOOGLE_HEALTH_SCOPES,
    };
    const existing = await base44.entities.WearableConnection.filter({ provider: 'google_health' });
    if (existing[0]) {
      await base44.entities.WearableConnection.update(existing[0].id, payload);
    } else {
      await base44.entities.WearableConnection.create(payload);
    }

    return Response.redirect(`${preferencesUrl}?google=connected`, 302);
  } catch (error) {
    return Response.redirect(`${preferencesUrl}?google=error`, 302);
  }
}