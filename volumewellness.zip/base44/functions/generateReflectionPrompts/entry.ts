import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';

const dayStr = (offsetDays = 0) => {
  const d = new Date(Date.now() - offsetDays * 864e5);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }
    const since7 = dayStr(7);

    const [assessments, sessions, events] = await Promise.all([
      base44.entities.DailyAssessment.list('-created_date', 30),
      base44.entities.WorkoutSession.list('-created_date', 60),
      base44.entities.BehavioralEvent.list('-created_date', 200),
    ]);
    const weekAssessments = assessments.filter((a) => a.date && a.date >= since7);
    const weekSessions = sessions.filter((s) => s.date && s.date >= since7);
    const weekEvents = events.filter((e) => e.timestamp && e.timestamp >= `${since7}T00:00:00Z`);

    const attempts = weekSessions.filter((s) => ['completed', 'partial', 'skipped'].includes(s.status));
    const completedCount = weekSessions.filter((s) => s.status === 'completed').length;
    const deferredCount = weekSessions.filter((s) => s.status === 'deferred').length;
    const avgScore = weekAssessments.length
      ? Math.round(weekAssessments.reduce((a, x) => a + (x.volume_score_total || 0), 0) / weekAssessments.length)
      : null;
    const lifeLoads = weekAssessments.map((a) => a.self_life_load).filter(Boolean);
    const dominantLifeLoad = lifeLoads.length
      ? lifeLoads.sort((a, b) => lifeLoads.filter((x) => x === b).length - lifeLoads.filter((x) => x === a).length)[0]
      : null;
    const warmupSkips = weekEvents.filter((e) => e.event_type === 'warmup_skipped').length;
    const laterTaps = weekEvents.filter((e) => e.event_type === 'later_tap').length;
    const bestDay = weekSessions.filter((s) => s.status === 'completed' && s.post_session_mood === 'much_better').length;
    const scoresByTier = {};
    weekAssessments.forEach((a) => {
      if (a.volume_score_tier) scoresByTier[a.volume_score_tier] = (scoresByTier[a.volume_score_tier] || 0) + 1;
    });

    const summary = [
      `Check-ins completed: ${weekAssessments.length}.`,
      avgScore !== null ? `Average Volume Score: ${avgScore}.` : '',
      `Workouts completed: ${completedCount}, attempted: ${attempts.length}, deferred: ${deferredCount}.`,
      dominantLifeLoad ? `Dominant life load this week: ${dominantLifeLoad}.` : '',
      laterTaps ? `"Do it later" taps: ${laterTaps}.` : '',
      warmupSkips ? `Warmup skips: ${warmupSkips}.` : '',
      bestDay ? `Sessions that made them feel much better: ${bestDay}.` : '',
      Object.keys(scoresByTier).length ? `Tier distribution: ${Object.entries(scoresByTier).map(([k, v]) => `${k} x${v}`).join(', ')}.` : '',
    ].filter(Boolean).join(' ');

    const prompt = `You are Volume, a warm, honest, personal fitness companion app — like a knowledgeable friend who knows the user's actual life. Not clinical, not gym-bro.

Here is the past week of behavioral data for this user: ${summary}

Write two things:
1. conversational_prompt — one short, open, non-judgmental reflection question grounded in a specific detail from their week (2 sentences max).
2. ai_question — a second, different question that is specific and personal, referencing a concrete pattern from the data (2 sentences max).

Tone: warm, encouraging, curious. Never shame the user. If the week was rough, acknowledge reality and ask what got in the way. Keep each question under 40 words.`;

    const llm = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt,
      model: 'claude-sonnet-5',
      response_json_schema: {
        type: 'object',
        properties: {
          conversational_prompt: { type: 'string' },
          ai_question: { type: 'string' },
        },
        required: ['conversational_prompt', 'ai_question'],
      },
    });

    const data = typeof llm === 'string' ? { conversational_prompt: llm, ai_question: null } : llm;
    return Response.json({
      stats: {
        week_start_date: since7,
        avg_volume_score: avgScore,
        sessions_completed: completedCount,
        sessions_attempted: attempts.length,
        dominant_life_load: dominantLifeLoad,
      },
      conversational_prompt: data.conversational_prompt || null,
      ai_question: data.ai_question || null,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}