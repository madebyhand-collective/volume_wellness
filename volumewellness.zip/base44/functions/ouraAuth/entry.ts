import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';
import { secrets } from 'base44:runtime';
import { ouraAuthorizeUrl, ouraTokenRequest } from '../../shared/wearables.ts';

// Oura OAuth flow. Visiting the endpoint without a code starts the flow
// (redirect to Oura's consent screen); Oura's callback with ?code= exchanges
// the code for tokens and saves the connection for the signed-in user.
export default async function (req) {
  const url = new URL(req.url);
  const preferencesUrl = `${url.origin}/preferences`;
  try {
    const clientId = secrets.get('OURA_CLIENT_ID');
    const clientSecret = secrets.get('OURA_CLIENT_SECRET');
    const redirectUri = `${url.origin}/functions/ouraAuth`;
    const code = url.searchParams.get('code');

    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch(() => null);
    if (!user) return Response.redirect(`${url.origin}/login`, 302);

    // Step 1: start the flow.
    if (!code) {
      return Response.redirect(ouraAuthorizeUrl(clientId, redirectUri), 302);
    }

    // Step 2: exchange the authorization code for tokens.
    const tokens = await ouraTokenRequest({
      grant_type: 'authorization_code',
      code,
      client_id: clientId,
      client_secret: clientSecret,
      redirect_uri: redirectUri,
    });

    const payload = {
      provider: 'oura',
      access_token: tokens.access_token,
      refresh_token: tokens.refresh_token,
      expires_at: new Date(Date.now() + (tokens.expires_in || 86400) * 1000).toISOString(),
      scopes: tokens.scope || '',
    };
    const existing = await base44.entities.WearableConnection.filter({ provider: 'oura' });
    if (existing[0]) {
      await base44.entities.WearableConnection.update(existing[0].id, payload);
    } else {
      await base44.entities.WearableConnection.create(payload);
    }

    return Response.redirect(`${preferencesUrl}?oura=connected`, 302);
  } catch (error) {
    return Response.redirect(`${preferencesUrl}?oura=error`, 302);
  }
}