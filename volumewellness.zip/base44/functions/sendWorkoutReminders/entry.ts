import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';

const TIMEZONE = 'America/Chicago';
const APP_URL = 'https://volumewellness.base44.app/';

// Counts as "handled today" — no nudge if the user finished, cut short, or
// deliberately skipped/deferred the session.
const RESOLVED_STATUSES = ['completed', 'partial', 'skipped', 'deferred'];

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const caller = await base44.auth.me();
    if (!caller || caller.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }
    const body = await req.json().catch(() => ({}));
    const dryRun = body.dryRun === true;
    const today = new Intl.DateTimeFormat('en-CA', { timeZone: TIMEZONE }).format(new Date());

    const [users, profiles, sessions] = await Promise.all([
      base44.asServiceRole.entities.User.list('-created_date', 500),
      base44.asServiceRole.entities.Profile.list('-created_date', 500),
      base44.asServiceRole.entities.WorkoutSession.list('-created_date', 500),
    ]);

    const activePlanByUser = new Map(
      profiles.filter((p) => p.active_plan_id).map((p) => [p.created_by_id, p.active_plan_id])
    );
    const handledToday = new Set(
      sessions
        .filter((s) => s.date === today && RESOLVED_STATUSES.includes(s.status))
        .map((s) => s.created_by_id)
    );

    const recipients = [];
    for (const user of users) {
      if (!activePlanByUser.has(user.id)) continue; // no active plan to remind about
      if (handledToday.has(user.id)) continue; // already logged (or consciously skipped) today
      recipients.push(user);
    }

    let sent = 0;
    let failed = 0;
    if (!dryRun) {
      for (const user of recipients) {
        try {
          await base44.asServiceRole.integrations.Core.SendPushNotification({
            user_id: user.id,
            title: 'Your workout is still waiting',
            content:
              "Today's session hasn't been logged yet. There's still time — start it now and let today count.",
            action_label: 'Start workout',
            action_url: `${APP_URL}workout`,
          });
          sent += 1;
        } catch (e) {
          failed += 1; // no registered device (web-only user) — nothing to push to
        }
      }
    }

    return Response.json({ date: today, dryRun, recipientCount: recipients.length, sent, failed });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}