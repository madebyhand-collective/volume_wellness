import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';
import { secrets } from 'base44:runtime';
import { syncOuraConnection } from '../../shared/wearables.ts';

// Daily Oura sync: refreshes tokens, pulls the last three days of
// sleep + readiness for every connected user, and upserts BiometricDaily.
// Admin-only (invoked by the scheduled "Oura Sync" workflow); supports
// { dryRun: true } to report scope without calling Oura.
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const caller = await base44.auth.me();
    if (!caller || caller.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }
    const body = await req.json().catch(() => ({}));
    const dryRun = body.dryRun === true;

    const clientId = secrets.get('OURA_CLIENT_ID');
    const clientSecret = secrets.get('OURA_CLIENT_SECRET');
    const conns = await base44.asServiceRole.entities.WearableConnection.list('-created_date', 500);
    const ouraConns = conns.filter((c) => c.provider === 'oura');

    const results = [];
    if (!dryRun) {
      for (const conn of ouraConns) {
        try {
          const upserted = await syncOuraConnection(base44.asServiceRole, conn, clientId, clientSecret);
          results.push({ connection: conn.id, user: conn.created_by_id, upserted, ok: true });
        } catch (error) {
          results.push({ connection: conn.id, user: conn.created_by_id, ok: false, error: error.message });
        }
      }
    }

    return Response.json({ connections: ouraConns.length, dryRun, results });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}