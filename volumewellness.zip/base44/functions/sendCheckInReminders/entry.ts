import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';

const TIMEZONE = 'America/Chicago';
const APP_URL = 'https://volumewellness.base44.app/';

// Consecutive check-in days ending today (or yesterday if today isn't in yet).
// Dates are stored as YYYY-MM-DD strings, so the cursor moves at noon UTC to
// stay clear of timezone boundaries.
function countStreak(dateList, today) {
  const has = new Set(dateList);
  if (has.size === 0) return 0;
  const cursor = new Date(`${today}T12:00:00Z`);
  if (!has.has(today)) cursor.setUTCDate(cursor.getUTCDate() - 1);
  let count = 0;
  while (has.has(cursor.toISOString().slice(0, 10))) {
    count += 1;
    cursor.setUTCDate(cursor.getUTCDate() - 1);
  }
  return count;
}

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const caller = await base44.auth.me();
    if (!caller || caller.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }
    const body = await req.json().catch(() => ({}));
    const dryRun = body.dryRun === true;
    const today = new Intl.DateTimeFormat('en-CA', { timeZone: TIMEZONE }).format(new Date());

    const [users, prefs, recent] = await Promise.all([
      base44.asServiceRole.entities.User.list('-created_date', 500),
      base44.asServiceRole.entities.Preferences.list('-created_date', 500),
      base44.asServiceRole.entities.DailyAssessment.list('-created_date', 500),
    ]);

    const prefsByUser = new Map(prefs.map((p) => [p.created_by_id, p]));
    const checkedIn = new Set(recent.filter((a) => a.date === today).map((a) => a.created_by_id));
    const datesByUser = new Map();
    for (const a of recent) {
      if (!datesByUser.has(a.created_by_id)) datesByUser.set(a.created_by_id, []);
      datesByUser.get(a.created_by_id).push(a.date);
    }

    const recipients = [];
    for (const user of users) {
      const p = prefsByUser.get(user.id);
      if (!p) continue; // user never finished onboarding
      const trigger = p.assessment_trigger || 'both';
      if (trigger !== 'notification' && trigger !== 'both') continue; // opted out of email nudges
      if (checkedIn.has(user.id)) continue; // already checked in today
      recipients.push({ user, streak: countStreak(datesByUser.get(user.id) || [], today) });
    }

    let sent = 0;
    if (!dryRun) {
      for (const { user, streak } of recipients) {
        let subject;
        let firmLine;
        if (streak >= 2) {
          subject = `Your ${streak}-day streak is on the line`;
          firmLine = `Your ${streak}-day streak is on the line right now. Skip today's check-in and the count restarts at zero tomorrow.`;
        } else if (streak === 1) {
          subject = "Don't let yesterday go to waste";
          firmLine = "Yesterday counted. Today's check-in decides whether a streak starts or it stays a one-off.";
        } else {
          subject = 'The streak you want starts today';
          firmLine = "There's no streak yet, and there won't be one until today's check-in happens.";
        }
        await base44.asServiceRole.integrations.Core.SendEmail({
          to: user.email,
          subject,
          text: `${firmLine}\n\nIt takes less than a minute, and nobody else can do this one for you.\n\nCheck in now: ${APP_URL}`,
          html: `<h2>${subject}</h2><p>${firmLine}</p><p>It takes less than a minute, and nobody else can do this one for you.</p><p><a href="${APP_URL}">Check in now</a></p>`,
        });
        sent += 1;
      }
    }

    return Response.json({
      date: today,
      dryRun,
      recipientCount: recipients.length,
      sent,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}