import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';

// Webhook receiver for the Health Auto Export app (Apple Watch / Apple Health).
// Each user gets a personal URL ending in ?key=<token>; the app POSTs daily
// JSON summaries (sleep, HRV, resting heart rate) and we upsert BiometricDaily.

function num(v) {
  return typeof v === 'number' && isFinite(v) ? v : null;
}

// Tolerant parser for Health Auto Export JSON payloads.
// Handles both the automation format ({ data: { metrics: [...] } }) and a
// plain metrics array, using each metric's daily "avg".
function parseBridgePayload(body) {
  const out = { date: null, hrv_ms: null, resting_hr: null, sleep_duration_hours: null };
  if (!body || typeof body !== 'object') return out;
  const d = body.data ?? body;
  let metrics = null;
  let date = null;
  if (Array.isArray(d)) metrics = d;
  else if (Array.isArray(d.metrics)) {
    metrics = d.metrics;
    date = d.date ?? d.start_date;
  }
  if (!metrics) return out;

  let asleepSec = null;
  let awakeSec = null;
  let inBedSec = null;
  for (const m of metrics) {
    if (!m || typeof m !== 'object') continue;
    const type = String(m.type || '').toLowerCase();
    const last = Array.isArray(m.data) && m.data.length ? m.data[m.data.length - 1] : {};
    const avg = num(m.avg) ?? num(m.average) ?? num(last.avg) ?? num(last.value);
    if (avg == null) continue;
    if (type === 'heart_rate_variability' || type === 'hrv') out.hrv_ms = avg;
    else if (type === 'resting_heart_rate' || type === 'heart_rate_resting') out.resting_hr = avg;
    else if (type === 'sleep_asleep_duration') asleepSec = avg;
    else if (type === 'sleep_awake_duration') awakeSec = avg;
    else if (type === 'sleep_in_bed_duration') inBedSec = avg;
  }
  if (asleepSec != null) out.sleep_duration_hours = asleepSec / 3600;
  else if (inBedSec != null && awakeSec != null) out.sleep_duration_hours = (inBedSec - awakeSec) / 3600;

  if (typeof date === 'string' && /^\d{4}-\d{2}-\d{2}/.test(date)) out.date = date.slice(0, 10);
  else out.date = new Date().toISOString().slice(0, 10);
  return out;
}

export default async function (req) {
  try {
    if (req.method !== 'POST') return Response.json({ error: 'Use POST' }, { status: 405 });
    const url = new URL(req.url);
    const body = await req.json().catch(() => null);
    const key = url.searchParams.get('key') || (req.headers ? req.headers.get('x-api-key') : null) || (body && body.key) || null;
    if (!key) return Response.json({ error: 'Missing key' }, { status: 400 });

    const base44 = createClientFromRequest(req);
    const conns = await base44.asServiceRole.entities.WearableConnection.filter({
      provider: 'apple_health',
      access_token: key,
    });
    const conn = conns[0];
    if (!conn) return Response.json({ error: 'Unknown key' }, { status: 401 });

    const parsed = parseBridgePayload(body);
    if (parsed.hrv_ms == null && parsed.resting_hr == null && parsed.sleep_duration_hours == null) {
      return Response.json({ error: 'No usable metrics in payload' }, { status: 422 });
    }

    const nowIso = new Date().toISOString();
    const record = {
      date: parsed.date,
      provider: 'apple_health',
      readiness_score: null,
      sleep_score: null,
      hrv_ms: parsed.hrv_ms,
      resting_hr: parsed.resting_hr,
      sleep_duration_hours: parsed.sleep_duration_hours,
      temperature_deviation: null,
      last_synced_at: nowIso,
    };
    const existing = await base44.asServiceRole.entities.BiometricDaily.filter({
      created_by_id: conn.created_by_id,
      provider: 'apple_health',
      date: parsed.date,
    });
    if (existing[0]) {
      await base44.asServiceRole.entities.BiometricDaily.update(existing[0].id, record);
    } else {
      await base44.asServiceRole.entities.BiometricDaily.create({ ...record, created_by_id: conn.created_by_id });
    }
    await base44.asServiceRole.entities.WearableConnection.update(conn.id, { last_synced_at: nowIso });
    return Response.json({
      ok: true,
      date: parsed.date,
      saved: {
        hrv_ms: parsed.hrv_ms,
        resting_hr: parsed.resting_hr,
        sleep_duration_hours: parsed.sleep_duration_hours,
      },
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}