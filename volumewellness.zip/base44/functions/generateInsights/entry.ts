import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';

const dayStr = (offsetDays = 0) => {
  const d = new Date(Date.now() - offsetDays * 864e5);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

const PREF_KEY = {
  timing_pattern: 'insight_timing_patterns',
  deferral_pattern: 'insight_deferral_patterns',
  cycle_performance: 'insight_cycle_performance',
  warmup_signal: 'insight_warmup_signal',
  cooldown_skip: 'insight_cooldown_skip',
  streak_protection: 'insight_streak_protection',
  life_load_correlation: 'insight_life_load_correlation',
  positive_reinforcement: 'insight_positive_reinforcement',
};

// Every insight pairs with a concrete in-app action the user can take.
const ACTION_BY_CATEGORY = {
  timing_pattern: 'schedule_session',
  deferral_pattern: 'schedule_session',
  positive_reinforcement: 'share_what_works',
  warmup_signal: 'movement_library',
  cooldown_skip: 'movement_library',
  streak_protection: 'start_session',
  life_load_correlation: 'share_what_works',
  cycle_performance: 'view_preferences',
};

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }
    const today = dayStr(0);
    const since30 = dayStr(30);
    const since21 = dayStr(21);
    const since7 = dayStr(7);
    const since14 = dayStr(14);

    const [sessions, events, assessments, insights, prefsList] = await Promise.all([
      base44.entities.WorkoutSession.list('-created_date', 100),
      base44.entities.BehavioralEvent.list('-created_date', 200),
      base44.entities.DailyAssessment.list('-created_date', 100),
      base44.entities.Insight.list('-created_date', 50),
      base44.entities.Preferences.list().catch(() => []),
    ]);
    const prefs = (prefsList && prefsList[0]) || {};
    const enabled = (cat) => {
      const key = PREF_KEY[cat];
      return prefs[key] === undefined ? true : prefs[key] === true;
    };

    const recentSessions = sessions.filter((s) => s.date && s.date >= since30);
    const attempts = recentSessions.filter((s) => ['completed', 'partial', 'skipped'].includes(s.status));
    const completed = recentSessions.filter((s) => s.status === 'completed');
    const nowIso = new Date().toISOString();
    const candidates = [];

    // duplicate guard: skip categories with an insight generated in the last 7 days
    const recentCats = new Set(insights.filter((i) => i.generated_at && i.generated_at >= `${since7}T00:00:00Z`).map((i) => i.category));
    // accountability: categories they said weren't useful recently get muted for 2 weeks
    const mutedCats = new Set(insights.filter((i) => i.user_rating === 'not_helpful' && i.updated_date && i.updated_date >= since14).map((i) => i.category));

    // dig into what's working just as deep as what isn't: weave the user's
    // own what-works answers back into future kudos insights
    const FACTOR_LABELS = {
      lowered_the_bar: 'lowering the bar',
      scheduled_it: 'putting it on the schedule',
      first_thing: 'doing it first thing',
      plan_ready: 'having a plan ready to go',
      support: 'support from the people around you',
      mindset: 'treating movement as self-care',
    };
    const priorWhatWorks = insights.find((i) => Array.isArray(i.what_works_factors) && i.what_works_factors.length > 0);
    const factorSuffix = priorWhatWorks
      ? ` You've said that ${priorWhatWorks.what_works_factors.map((f) => FACTOR_LABELS[f] || f).join(' and ')} is what makes it happen — worth protecting.`
      : '';
    const push = (category, title, bodyText, action, confidence, windowStart) => {
      if (!enabled(category) || recentCats.has(category) || mutedCats.has(category)) return;
      candidates.push({
        category, title, body: bodyText,
        action_suggestion: action || null,
        action_type: ACTION_BY_CATEGORY[category] || null,
        data_window_start: windowStart || since30,
        data_window_end: today,
        confidence, status: 'new', generated_at: nowIso,
      });
    };

    // deferral_pattern
    const deferred = recentSessions.filter((s) => s.status === 'deferred' && s.date >= since21 && s.deferral_outcome === 'never_completed');
    if (deferred.length >= 3) {
      push('deferral_pattern',
        "When you say 'later', it usually doesn't happen",
        `The last ${deferred.length} times you deferred a workout in the past 3 weeks, it never got done. That's not a discipline problem — it's a scheduling signal.`,
        'Want to lock in your next session for a time that actually works?', 0.82);
    }

    // timing_pattern
    const timed = attempts.filter((s) => s.started_at);
    if (timed.length >= 5) {
      const inBucket = (s, lo, hi) => {
        const h = new Date(s.started_at).getHours();
        return h >= lo && h < hi;
      };
      const morning = timed.filter((s) => inBucket(s, 0, 9));
      const evening = timed.filter((s) => inBucket(s, 16, 24));
      const rate = (arr) => (arr.length ? arr.filter((s) => s.status === 'completed').length / arr.length : null);
      const mRate = rate(morning); const eRate = rate(evening);
      if (mRate !== null && eRate !== null && mRate - eRate >= 0.3) {
        push('timing_pattern',
          'Mornings are your power window',
          `Your completion rate before 9am is ${Math.round(mRate * 100)}% vs ${Math.round(eRate * 100)}% after 4pm. That's a ${Math.round((mRate - eRate) * 100)}-point gap.`,
          'Try putting your next session first thing in the morning.', 0.78);
      }
    }

    // warmup_signal
    const last5 = attempts.slice(0, 5);
    const warmupSkips = last5.filter((s) => s.warmup_skipped === true).length;
    if (last5.length >= 3 && warmupSkips >= 3) {
      push('warmup_signal',
        'Warmup skips are stacking up',
        `You've skipped your warmup in ${warmupSkips} of your last ${last5.length} sessions. For you, this pattern has preceded falling off entirely.`,
        'Try the shortest warmup option — even 3 minutes counts.', 0.66);
    }

    // cooldown_skip
    const antsySkips = attempts.filter((s) => s.cooldown_skipped === true && s.cooldown_skip_reason === 'antsy').length;
    if (antsySkips >= 2) {
      push('cooldown_skip',
        'Antsy cooldowns are a stress signal',
        `You've skipped your cooldown ${antsySkips} times because you felt antsy after finishing. Post-workout restlessness often means your nervous system is still revved.`,
        'Try 2 minutes of box breathing before you rush off — it flips the switch.', 0.61);
    }

    // streak_protection
    const lastCompletedDate = completed.length ? completed[0].date : null;
    const daysSince = lastCompletedDate ? Math.round((new Date(today) - new Date(lastCompletedDate)) / 864e5) : null;
    const movedToday = attempts.some((s) => s.date === today);
    if (lastCompletedDate && daysSince >= 2 && !movedToday) {
      push('streak_protection',
        "You haven't moved in a few days",
        `It's been ${daysSince} days since your last completed session. You don't need a full workout — momentum is the point.`,
        'A 10-minute walk counts. Start there.', 0.7);
    }

    // positive_reinforcement
    const thisWeek = attempts.filter((s) => s.date >= since7);
    if (thisWeek.length >= 3 && thisWeek.every((s) => s.status === 'completed')) {
      push('positive_reinforcement',
        'Every session this week, done',
        `You've completed all ${thisWeek.length} sessions you started this week. Consistency like this is rare — notice it.${factorSuffix}`,
        'Keep the streak alive — same time tomorrow?', 0.85);
    }

    // life_load_correlation
    const heavyDays = new Set(assessments.filter((a) => a.date && a.self_life_load === 'heavy').map((a) => a.date));
    const heavyDaySessions = attempts.filter((s) => heavyDays.has(s.date));
    const heavyCompleted = heavyDaySessions.filter((s) => s.status === 'completed' || s.status === 'partial').length;
    if (heavyDaySessions.length >= 2 && heavyCompleted >= 2) {
      push('life_load_correlation',
        'You show up on the hard days',
        `On heavy life-load days, you still moved ${heavyCompleted} of ${heavyDaySessions.length} times — even short sessions kept the streak intact on your hardest days.${factorSuffix}`,
        'On the next heavy day, aim for a 20-minute Restore session.', 0.64);
    }

    // cycle_performance
    const withPhase = assessments.filter((a) => a.cycle_phase && typeof a.volume_score_total === 'number');
    const byPhase = {};
    withPhase.forEach((a) => {
      if (!byPhase[a.cycle_phase]) byPhase[a.cycle_phase] = { sum: 0, n: 0 };
      byPhase[a.cycle_phase].sum += a.volume_score_total;
      byPhase[a.cycle_phase].n += 1;
    });
    const avg = (p) => (byPhase[p] && byPhase[p].n >= 2 ? byPhase[p].sum / byPhase[p].n : null);
    const fol = avg('follicular'); const lut = avg('luteal');
    if (fol !== null && lut !== null && fol - lut >= 8) {
      push('cycle_performance',
        'Your score dips in your luteal phase',
        `Your average Volume Score is ${Math.round(fol)} in your follicular phase vs ${Math.round(lut)} in your luteal phase. That's normal — progesterone lowers HRV and energy. Women who lean into Restore sessions here keep their streaks at higher rates.`,
        'During luteal weeks, plan Restore-tier sessions instead of pushing through.', 0.72, cycleWindowStart(withPhase));
    }

    const created = [];
    for (const c of candidates) {
      created.push(await base44.entities.Insight.create(c));
    }
    return Response.json({ created, total_created: created.length });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}

function cycleWindowStart(assessments) {
  const dates = assessments.filter((a) => a.date).map((a) => a.date).sort();
  return dates[0] || dayStr(30);
}