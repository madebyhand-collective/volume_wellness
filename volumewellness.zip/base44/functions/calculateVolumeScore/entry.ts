import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';

const LIFE_LOAD_SCORES = { light: 90, moderate: 60, heavy: 25 };
const SORENESS_SCORES = { none: 100, mild: 70, heavy: 35 };
const MOTIVATION_SCORES = { ready: 90, neutral: 60, dreading: 20 };
const STRESS_SCORES = { low: 90, moderate: 60, high: 25 };
const SLEEP_QUALITY_SCORES = { poor: 20, ok: 60, great: 90 };
const CYCLE_MODIFIERS = { follicular: 3, ovulatory: 5, luteal: -8, menstrual: -10 };
const TIERS = [
  { min: 85, tier: 'amplify', setModifier: 1, cap: 45, message: "You're firing on all cylinders. Push it today." },
  { min: 65, tier: 'baseline', setModifier: 0, cap: 45, message: "You're ready. Do the work." },
  { min: 45, tier: 'modify', setModifier: 0, cap: 30, message: "Modified session today — do the plan, listen to your body." },
  { min: 25, tier: 'restore', setModifier: -1, cap: 20, message: "Your body is asking for gentleness. A short restore session counts." },
  { min: 0, tier: 'rest', setModifier: -1, cap: 20, message: "Active rest today. A walk or breathing work is enough." },
];

const clamp = (n, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, n));
const dayStr = (offsetDays = 0) => {
  const d = new Date(Date.now() - offsetDays * 864e5);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

function pickBlock(blocks, type, tier, timeAvailable, lifeLoad, soreness, cyclePhase, cap) {
  const candidates = blocks.filter(
    (b) => b.type === type && b.access_tier === 'free'
      && Array.isArray(b.recommend_volume_tiers) && b.recommend_volume_tiers.includes(tier)
      && Array.isArray(b.time_available) && b.time_available.includes(timeAvailable)
  );
  const pool = candidates.length ? candidates : blocks.filter((b) => b.type === type && b.access_tier === 'free');
  if (!pool.length) return null;
  const scored = pool.map((b) => {
    let s = 0;
    if (Array.isArray(b.recommend_life_load) && b.recommend_life_load.includes(lifeLoad)) s += 2;
    if (Array.isArray(b.recommend_soreness) && b.recommend_soreness.includes(soreness)) s += 2;
    if (cyclePhase && Array.isArray(b.recommend_cycle_phases) && b.recommend_cycle_phases.includes(cyclePhase)) s += 1;
    if (cap <= 20 && b.duration_minutes <= 8) s += 2;
    if (cap <= 20 && b.duration_minutes > 10) s -= 2;
    return { b, s };
  });
  scored.sort((x, y) => y.s - x.s || x.b.duration_minutes - y.b.duration_minutes);
  return scored[0].b;
}

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }
    const body = await req.json().catch(() => ({}));
    const { soreness, time_available, life_load, motivation, stress, energy, sleep_quality, mood, cycle_phase, date } = body || {};
    const required = { soreness, time_available, life_load, motivation, stress, energy, sleep_quality };
    for (const [k, v] of Object.entries(required)) {
      if (v === undefined || v === null || v === '') {
        return Response.json({ error: `Missing answer: ${k}` }, { status: 400 });
      }
    }

    let prefs = {};
    try {
      const list = await base44.entities.Preferences.list();
      if (list && list[0]) prefs = list[0];
    } catch (e) { /* defaults */ }
    const wBody = typeof prefs.weight_body_signal === 'number' ? prefs.weight_body_signal : 0.4;
    const wLife = typeof prefs.weight_life_load === 'number' ? prefs.weight_life_load : 0.3;
    const wMental = typeof prefs.weight_mental_readiness === 'number' ? prefs.weight_mental_readiness : 0.2;
    const wMomentum = typeof prefs.weight_behavioral_momentum === 'number' ? prefs.weight_behavioral_momentum : 0.1;

    // Component 1 — Body Signal (self-report only in this build; wearables not connected)
    const signals = [
      { w: 40, s: clamp(((Number(energy) - 1) / 4) * 100) },
      { w: 25, s: SLEEP_QUALITY_SCORES[sleep_quality] },
    ];
    const wSum = signals.reduce((a, x) => a + x.w, 0);
    const bodySignal = wSum ? signals.reduce((a, x) => a + x.w * x.s, 0) / wSum : 50;

    // Component 2 — Life Load
    const lifeLoadScore = LIFE_LOAD_SCORES[life_load] * 0.65 + SORENESS_SCORES[soreness] * 0.35;

    // Component 3 — Mental Readiness
    const mentalScore = MOTIVATION_SCORES[motivation] * 0.65 + STRESS_SCORES[stress] * 0.35;

    // Component 4 — Behavioral Momentum (last 14 days of sessions)
    let momentum = 50;
    try {
      const sessions = await base44.entities.WorkoutSession.list('-created_date', 100);
      const since = dayStr(14);
      const window = sessions.filter((s) => s.date && s.date >= since);
      const attempts = window.filter((s) => ['completed', 'partial', 'skipped'].includes(s.status));
      if (attempts.length > 0) {
        const completed = attempts.filter((s) => s.status === 'completed').length;
        const partial = attempts.filter((s) => s.status === 'partial').length;
        let m = ((completed + partial * 0.5) / attempts.length) * 80;
        const neverDeferred = window.filter((s) => s.status === 'deferred' && s.deferral_outcome === 'never_completed').length;
        m -= Math.min(30, neverDeferred * 8);
        const recentTwo = attempts.slice(0, 2);
        m += recentTwo.filter((s) => s.status === 'completed').length * 5;
        momentum = clamp(m);
      }
    } catch (e) { /* default 50 */ }

    let total = bodySignal * wBody + lifeLoadScore * wLife + mentalScore * wMental + momentum * wMomentum;

    // Cycle modifier
    let cycleModifier = 0;
    let phaseApplied = null;
    const cycleOn = prefs.cycle_tracking_enabled === true
      && prefs.cycle_tracking_override !== true
      && cycle_phase && CYCLE_MODIFIERS[cycle_phase] !== undefined;
    if (cycleOn) {
      const cw = typeof prefs.cycle_tracking_weight === 'number' ? prefs.cycle_tracking_weight : 1.0;
      cycleModifier = CYCLE_MODIFIERS[cycle_phase] * cw;
      phaseApplied = cycle_phase;
      total += cycleModifier;
    }

    // Caps: motivation -> stress -> time
    if (motivation === 'neutral') total = Math.min(total, 85);
    if (motivation === 'dreading') total = Math.min(total, 60);
    if (stress === 'moderate') total = Math.min(total, 80);
    if (stress === 'high') total = Math.min(total, 55);
    if (time_available === 'under20') total = Math.min(total, 35);
    if (time_available === '20to30') total = Math.min(total, 70);

    const score = Math.round(clamp(total));

    // Feedback loop: "not helpful" ratings on recent insights adjust future
    // tier recommendations. If the nudges felt pushy, stop recommending push
    // days for a while — the readiness score itself stays honest, only the
    // recommended tier softens.
    let tierScore = score;
    let feedbackNote = null;
    try {
      const flagged = await base44.entities.Insight.list('-updated_date', 50);
      const since14d = dayStr(14);
      const reasonCounts = {};
      flagged
        .filter((i) => i.user_rating === 'not_helpful' && i.updated_date && i.updated_date >= since14d)
        .forEach((i) => { if (i.rating_reason) reasonCounts[i.rating_reason] = (reasonCounts[i.rating_reason] || 0) + 1; });
      if ((reasonCounts.too_pushy || 0) >= 1) {
        tierScore = Math.min(tierScore, 65);
        feedbackNote = 'Recommendations have felt like a lot lately — easing off on the push for now.';
      }
    } catch (e) { /* feedback is optional */ }

    const t = TIERS.find((x) => tierScore >= x.min);

    const blocks = await base44.entities.SessionBlock.list();

    // Recurring user-picked blocks win on their days; otherwise defer to style preferences.
    const dow = new Date(`${date || dayStr(0)}T12:00:00`).getDay();
    const recurring = Array.isArray(prefs.recurring_blocks) ? prefs.recurring_blocks.filter(Boolean) : [];
    const styleTagFor = (style) => (style === 'mobility' ? 'mobility' : style === 'physical_therapy' ? 'physical therapy' : null);
    const pickWithPrefs = (type, style) => {
      const rec = recurring.find((r) => r && r.type === type && Array.isArray(r.days) && r.days.includes(dow));
      if (rec) {
        const recBlock = blocks.find((b) => b.block_id === rec.block_id);
        if (recBlock) return recBlock;
      }
      const tag = styleTagFor(style);
      if (!tag) return pickBlock(blocks, type, t.tier, time_available, life_load, soreness, phaseApplied, t.cap);
      const preferred = pickBlock(
        blocks.filter((b) => Array.isArray(b.tags) && b.tags.includes(tag)),
        type, t.tier, time_available, life_load, soreness, phaseApplied, t.cap
      );
      return preferred || pickBlock(blocks, type, t.tier, time_available, life_load, soreness, phaseApplied, t.cap);
    };
    const warmup = pickWithPrefs('warmup', prefs.warmup_style);
    const cooldown = pickWithPrefs('cooldown', prefs.cooldown_style);

    let secondary = null;
    if (time_available === 'under20') secondary = 'Tight on time today — the session is capped at 20 minutes.';
    else if (stress === 'high') secondary = 'High stress noted. Keep it steady and let the movement help.';
    else if (soreness === 'heavy') secondary = 'Heavy soreness noted — extra mobility built into your warmup.';
    if (feedbackNote) secondary = `${secondary ? `${secondary} ` : ''}${feedbackNote}`;

    const record = await base44.entities.DailyAssessment.create({
      date: date || dayStr(0),
      trigger_source: 'in_app',
      biometric_source: 'none',
      biometric_coverage: 'none',
      self_soreness: soreness,
      self_time_available: time_available,
      self_life_load: life_load,
      self_motivation: motivation,
      self_stress: stress,
      self_energy: Number(energy),
      self_sleep_quality: sleep_quality,
      self_mood: mood || null,
      cycle_phase: phaseApplied,
      cycle_influence_applied: !!phaseApplied,
      volume_score_total: score,
      volume_score_tier: t.tier,
      vs_body_signal: Math.round(bodySignal),
      vs_life_load: Math.round(lifeLoadScore),
      vs_mental_readiness: Math.round(mentalScore),
      vs_behavioral_momentum: Math.round(momentum),
      cycle_modifier: Math.round(cycleModifier * 10) / 10,
      rec_warmup_block_id: warmup ? warmup.block_id : null,
      rec_warmup_intensity: warmup ? warmup.intensity_level : 'low',
      rec_set_modifier: t.setModifier,
      rec_cooldown_block_id: cooldown ? cooldown.block_id : null,
      rec_session_length_cap: t.cap,
      rec_primary_message: t.message,
      rec_secondary_message: secondary,
    });

    return Response.json({ assessment: record });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}