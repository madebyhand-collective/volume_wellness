import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';

const TIMEZONE = 'America/Chicago';
const APP_URL = 'https://volumewellness.base44.app/';

// Volume weeks run Sunday -> Saturday. Returns the most recent Sunday as YYYY-MM-DD,
// anchored at noon UTC to stay clear of timezone boundaries.
function weekStartOf(now) {
  const today = new Intl.DateTimeFormat('en-CA', { timeZone: TIMEZONE }).format(now);
  const cursor = new Date(`${today}T12:00:00Z`);
  cursor.setUTCDate(cursor.getUTCDate() - cursor.getUTCDay());
  return cursor.toISOString().slice(0, 10);
}

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const caller = await base44.auth.me();
    if (!caller || caller.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }
    const body = await req.json().catch(() => ({}));
    const dryRun = body.dryRun === true;
    const weekStart = weekStartOf(new Date());

    const [users, prefs, reflections] = await Promise.all([
      base44.asServiceRole.entities.User.list('-created_date', 500),
      base44.asServiceRole.entities.Preferences.list('-created_date', 500),
      base44.asServiceRole.entities.WeeklyReflection.list('-created_date', 500),
    ]);

    const prefsByUser = new Map(prefs.map((p) => [p.created_by_id, p]));
    const doneThisWeek = new Set(
      reflections.filter((r) => r.week_start_date === weekStart).map((r) => r.created_by_id)
    );

    const recipients = [];
    for (const user of users) {
      const p = prefsByUser.get(user.id);
      if (!p) continue; // never finished onboarding
      if ((p.weekly_reflection_day ?? 0) !== 0) continue; // reflection day isn't Sunday
      if (doneThisWeek.has(user.id)) continue; // already reflected this week
      recipients.push(user);
    }

    let sent = 0;
    let failed = 0;
    if (!dryRun) {
      for (const user of recipients) {
        try {
          await base44.asServiceRole.integrations.Core.SendPushNotification({
            user_id: user.id,
            title: 'Time for your weekly reflection',
            content:
              'Ten quiet minutes to look back at the week — what worked, what didn\u2019t, and one change worth trying next week.',
            action_label: 'Reflect',
            action_url: `${APP_URL}reflection`,
          });
          sent += 1;
        } catch (e) {
          failed += 1; // no registered device (web-only user) — nothing to push to
        }
      }
    }

    return Response.json({ weekStart, dryRun, recipientCount: recipients.length, sent, failed });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}